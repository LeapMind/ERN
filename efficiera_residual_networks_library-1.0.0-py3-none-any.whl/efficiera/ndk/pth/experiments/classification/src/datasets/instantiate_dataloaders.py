from __future__ import annotations

from logging import getLogger

import hydra
from omegaconf import DictConfig
import torch
from torch.utils.data import DataLoader
from torchvision import transforms

from efficiera.ndk.pth.experiments.classification.src.datasets.datasets import get_dataset

_logger = getLogger(__name__)


def instantiate_dataloaders(
    cfg: DictConfig,
) -> tuple[DataLoader[tuple[torch.Tensor, torch.Tensor]], DataLoader[tuple[torch.Tensor, torch.Tensor]]]:
    if "tencrop_evaluation" in cfg.pl_module:
        if cfg.pl_module.tencrop_evaluation and cfg.dataloader.pin_memory:
            _logger.warning(
                "To avoid RuntimeError, `dataloader.pin_memory` should be set to `False` when `TenCrop` is enabled."
            )

    augmentor = hydra.utils.instantiate(cfg.augmentor, _convert_="all")
    pre_processor = hydra.utils.instantiate(cfg.pre_processor, _convert_="all")
    pre_processor_val = hydra.utils.instantiate(cfg.get("pre_processor_val", []), _convert_="all")

    train_dataset = get_dataset(cfg.dataset, transform=transforms.Compose(augmentor + pre_processor), train=True)
    val_dataset = get_dataset(cfg.dataset, transform=transforms.Compose(pre_processor_val + pre_processor), train=False)

    train_dataloader = hydra.utils.instantiate(cfg.dataloader, dataset=train_dataset, _convert_="all")
    val_dataloader = hydra.utils.instantiate(cfg.dataloader, dataset=val_dataset, shuffle=False, _convert_="all")
    return train_dataloader, val_dataloader

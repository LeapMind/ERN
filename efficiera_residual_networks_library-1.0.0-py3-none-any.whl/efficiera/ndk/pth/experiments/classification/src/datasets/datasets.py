from __future__ import annotations

import logging
from pathlib import Path

import hydra
from omegaconf import DictConfig
import torch
from torch.utils.data import Dataset
from torchvision.datasets import CIFAR10, CIFAR100, FakeData, ImageFolder
from torchvision import transforms

_logger = logging.getLogger(__name__)

DATASETS_NUM_CLASSES: dict[type[Dataset[tuple[torch.Tensor, torch.Tensor]]], int] = {
    CIFAR10: 10,
    CIFAR100: 100,
    ImageFolder: 1000,
}


def get_dataset(
    dataset_cfg: DictConfig,
    transform: transforms.Compose,
    train: bool,
) -> Dataset[tuple[torch.Tensor, torch.Tensor]]:
    """Construct and return dataset class from dataset parameters
    Args:
        dataset_cfg (DictConfig): A dataset config
        transform (transforms.Compose): List of Transformation for training data that takes in an PIL image and returns a transformed version
        train (bool): If `yes` return training dataset, otherwise return validation dataset
    Returns:
        (torch.utils.data.Dataset): A dataset
    """  # NOQA: E501
    dataset_type = hydra.utils.get_class(dataset_cfg._target_)
    if dataset_type == ImageFolder:  # ImageNet
        # We use `ImageFolder` instead of `torchvision.datasets.ImageNet` because our dataset has already extracted
        root = Path(dataset_cfg.root)
        if train:
            split = dataset_cfg.traindir
        else:
            split = dataset_cfg.valdir
        _logger.info(f"{split} data transform: " + str(transform))
        return hydra.utils.instantiate(dataset_cfg.target, root=(root / split), transform=transform, _convert_="all")
    elif dataset_type in DATASETS_NUM_CLASSES:
        return hydra.utils.instantiate(dataset_cfg, train=train, transform=transform, _convert_="all")
    elif dataset_type == FakeData:
        return hydra.utils.instantiate(dataset_cfg, transform=transform, _convert_="all")
    _logger.error(f'"{dataset_cfg._target_}" dataset is not available.', stack_info=True)
    raise ValueError(f'"{dataset_cfg._target_}" dataset is not available.')


def get_dataset_numclasses(dataset_cfg: DictConfig) -> int:
    """Return number of classes of the dataset
    Args:
        dataset_cfg (DictConfig): A dataset config
    Returns:
        (int): A dataset class numbers
    """
    dataset_type = hydra.utils.get_class(dataset_cfg._target_)
    if dataset_type in DATASETS_NUM_CLASSES:
        return DATASETS_NUM_CLASSES[dataset_type]
    elif dataset_type == FakeData:
        return dataset_cfg.num_classes
    _logger.error(f'"{dataset_cfg._target_}" dataset is not available.', stack_info=True)
    raise ValueError(f'"{dataset_cfg._target_}" dataset is not available.')


def get_dataset_classlabels(dataset_cfg: DictConfig) -> list[str]:
    """Return list of class labels of the dataset
    Args:
        dataset_cfg (DictConfig): A dataset config
    Returns:
        (list[str]): A list of class labels
    """
    dataset_type = hydra.utils.get_class(dataset_cfg._target_)
    if dataset_type == ImageFolder:
        with open(Path(dataset_cfg.root) / "imagenet_classes.txt") as f:
            return f.read().splitlines()
    elif dataset_type == CIFAR10:
        return ["airplane", "automobile", "bird", "cat", "deer", "dog", "frog", "horse", "ship", "truck"]
    elif dataset_type == CIFAR100:
        return [
            "apple",
            "aquarium_fish",
            "baby",
            "bear",
            "beaver",
            "bed",
            "bee",
            "beetle",
            "bicycle",
            "bottle",
            "bowl",
            "boy",
            "bridge",
            "bus",
            "butterfly",
            "camel",
            "can",
            "castle",
            "caterpillar",
            "cattle",
            "chair",
            "chimpanzee",
            "clock",
            "cloud",
            "cockroach",
            "couch",
            "crab",
            "crocodile",
            "cup",
            "dinosaur",
            "dolphin",
            "elephant",
            "flatfish",
            "forest",
            "fox",
            "girl",
            "hamster",
            "house",
            "kangaroo",
            "keyboard",
            "lamp",
            "lawn_mower",
            "leopard",
            "lion",
            "lizard",
            "lobster",
            "man",
            "maple_tree",
            "qmotorcycle",
            "mountain",
            "mouse",
            "mushroom",
            "oak_tree",
            "orange",
            "orchid",
            "otter",
            "palm_tree",
            "pear",
            "pickup_truck",
            "pine_tree",
            "plain",
            "plate",
            "poppy",
            "porcupine",
            "possum",
            "rabbit",
            "raccoon",
            "ray",
            "road",
            "rocket",
            "rose",
            "sea",
            "seal",
            "shark",
            "shrew",
            "skunk",
            "skyscraper",
            "snail",
            "snake",
            "spider",
            "squirrel",
            "streetcar",
            "sunflower",
            "sweet_pepper",
            "table",
            "tank",
            "telephone",
            "television",
            "tiger",
            "tractor",
            "train",
            "trout",
            "tulip",
            "turtle",
            "wardrobe",
            "whale",
            "willow_tree",
            "wolf",
            "woman",
            "worm",
        ]
    elif dataset_type == FakeData:
        return [str(i) for i in range(get_dataset_numclasses(dataset_cfg))]
    _logger.error(f'"{dataset_cfg._target_}" dataset is not available.', stack_info=True)
    raise ValueError(f'"{dataset_cfg._target_}" dataset is not available.')

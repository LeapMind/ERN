from __future__ import annotations

from logging import getLogger

import hydra
from omegaconf import DictConfig
import pytorch_lightning as pl

from efficiera.ndk.pth.experiments.classification.src.datasets.datasets import get_dataset_numclasses

logger = getLogger(__name__)


def instantiate_model(cfg: DictConfig) -> pl.LightningModule:
    return hydra.utils.instantiate(
        cfg.pl_module,
        network=hydra.utils.instantiate(
            cfg.network,
            num_classes=get_dataset_numclasses(cfg.dataset),
            weight_quantizer=hydra.utils.instantiate(cfg.get("weight_quantizer", None), _convert_="all"),
            activation_quantizer=hydra.utils.instantiate(cfg.get("activation_quantizer", None), _convert_="all"),
        ),
        weight_regularizers=list(hydra.utils.instantiate(cfg.get("weight_regularizers", {}), _convert_="all").values()),
        quantization_regularizers=list(
            hydra.utils.instantiate(cfg.get("quantization_regularizers", {}), _convert_="all").values()
        ),
        _recursive_=False,
        _convert_="none",
    )

from __future__ import annotations

from collections.abc import Callable
import logging
from typing import Any

import hydra
import numpy as np
from omegaconf import DictConfig
import pytorch_lightning as pl
import torch
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torchmetrics
from torchvision.transforms import Compose, Lambda, TenCrop

from efficiera.ndk.pth.experiments.base.src.quantization_regularizers.quantization_regularizer import (
    QuantizationRegularizer,
)
from efficiera.ndk.pth.experiments.base.src.regularizers.sparsification import SparsificationRegularizer
from efficiera.ndk.pth.experiments.base.src.utils.weight_change_metric import WeightChangeMetric

_logger = logging.getLogger(__name__)


def mixup_data(
    x: torch.Tensor, y: torch.Tensor, alpha: float = 1.0
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, float]:
    """Mixup data in a mini-batch to use mixup data augmentation

    Args:
        x (torch.Tensor): Input data
        y (torch.Tensor): Label data
        alpha (float, optional): A parameter of beta distribution. Defaults to 1.0

    Returns:
        tuple[torch.Tensor, torch.Tensor, torch.Tensor, float]: Mixed data
    """
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1

    batch_size = x.size()[0]
    index = torch.randperm(batch_size)

    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam


def mixup_criterion(
    criterion: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    pred: torch.Tensor,
    y_a: torch.Tensor,
    y_b: torch.Tensor,
    lam: float,
) -> torch.Tensor:
    """Calculate loss from inference results and mixed-up data

    Args:
        criterion (Callable): A loss function
        pred (torch.Tensor): Results of inference
        y_a (torch.Tensor): A label A
        y_b (torch.Tensor): A label B
        lam (float): A weight value

    Returns:
        torch.Tensor: A value of loss
    """
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)


def cutmix_data(
    x: torch.Tensor, y: torch.Tensor, alpha: float = 1.0
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, float]:
    """Cutmix data in a mini-batch to use mixup data augmentation

    Args:
        x (torch.Tensor): Input data
        y (torch.Tensor): Label data
        alpha (float, optional): A parameter of beta distribution. Defaults to ``1.0``.

    Returns:
        tuple[torch.Tensor, torch.Tensor, torch.Tensor, float]: Mixed data
    """
    batch_size, _, h, w = x.size()
    mix_indice = torch.randperm(batch_size)
    y_a = y
    y_b = y[mix_indice]

    x1, y1, x2, y2 = _cutmix_random_bbox(w, h, np.random.beta(alpha, alpha))
    x[:, :, y1:y2, x1:x2] = x[mix_indice, :, y1:y2, x1:x2]

    y_a_pixel_ratio = 1.0 - ((x2 - x1) * (y2 - y1) / (w * h))
    return x, y_a, y_b, y_a_pixel_ratio


def _cutmix_random_bbox(w: int, h: int, lam: float) -> tuple[int, int, int, int]:
    ratio = np.sqrt(1.0 - lam)
    box_w = np.int32(w * ratio)
    box_h = np.int32(h * ratio)

    cx = np.random.randint(w)
    cy = np.random.randint(h)

    bbox_x1 = np.clip(cx - box_w // 2, 0, w)
    bbox_y1 = np.clip(cy - box_h // 2, 0, h)
    bbox_x2 = np.clip(cx + box_w // 2, 0, w)
    bbox_y2 = np.clip(cy + box_h // 2, 0, h)

    return bbox_x1, bbox_y1, bbox_x2, bbox_y2


def cutmix_criterion(
    criterion: Callable[[torch.Tensor, torch.Tensor], torch.Tensor],
    pred: torch.Tensor,
    y_a: torch.Tensor,
    y_b: torch.Tensor,
    y_a_pixel_ratio: float,
) -> torch.Tensor:
    """Calculate loss from inference results and mixed-up data

    Args:
        criterion (Callable): A loss function
        pred (torch.Tensor): Results of inference
        y_a (torch.Tensor): A label A
        y_b (torch.Tensor): A label B
        y_a_pixel_ratio (float): A pixel ratio value

    Returns:
        torch.Tensor: A value of loss
    """
    return criterion(pred, y_a) * y_a_pixel_ratio + criterion(pred, y_b) * (1.0 - y_a_pixel_ratio)


class Classifier(pl.LightningModule):
    """Pytorch lightning module for classification task
    Args:
        network (nn.Module): A network
        learning_rate (float): A learning rate
        optimizer_cfg: (DictConfig): An optimizer config
        scheduler_cfg: (DictConfig): A scheduler config
        use_mixup (bool, optional): A flag to enable mixup data in a mini-batch to use mixup data augmentation.
          Defaults to ``False``.
        mixup_alpha (float, optional): Alpha parameter for mixup data augmentation. Defaults to ``1.0``.
        use_cutmix (bool, optional): A flag to enable cutmix data augmentation. Defaults to ``False``.
        cutmix_alpha (float, optional): Alpha parameter for cutmix data augmentation. Defaults to ``1.0``.
        weight_regularizers (List[nn.Module], optional): Weight Regularizer module. Defaults to ``None``.
        quantization_regularizers (List[QuantiationRegularizer], optional): Quantization Regularizer module.
          Default to ``None``.
        tencrop_evaluation (bool, optional): If True, the evaluation is done with the tencrop test-time augmentation.
          With tencrop evaluation, it is recommended to set `pin_memory=False` to DataLoader due to the increase of
          memory usage during the augmentation. Defaults to ``False``. Otherwise, Runtime Error may occur.
        tencrop_size (int, optional): The width/height size of the cropped images. Defaults to ``320``.
          The preprocess operations before tencrop should transform the images larger than this value.
    """

    def __init__(
        self,
        network: nn.Module,
        learning_rate: float,
        optimizer_cfg: DictConfig,
        scheduler_cfg: DictConfig,
        use_mixup: bool = False,
        mixup_alpha: float = 1.0,
        use_cutmix: bool = False,
        cutmix_alpha: float = 1.0,
        weight_regularizers: list[nn.Module] | None = None,
        quantization_regularizers: list[QuantizationRegularizer] | None = None,
        tencrop_evaluation: bool = False,
        tencrop_size: int = 320,
    ) -> None:
        super().__init__()
        self.learning_rate = learning_rate
        self.optimizer_cfg = optimizer_cfg
        self.scheduler_cfg = scheduler_cfg
        self.network = network
        self.accuracy_top1 = torchmetrics.Accuracy(top_k=1)
        self.accuracy_top5 = torchmetrics.Accuracy(top_k=5)
        self.use_mixup = use_mixup
        self.mixup_alpha = mixup_alpha
        self.use_cutmix = use_cutmix
        self.cutmix_alpha = cutmix_alpha
        self.weight_regularizers = weight_regularizers
        self.weight_change_metric = WeightChangeMetric(network)
        self.quantization_regularizers = quantization_regularizers
        self.tencrop_evaluation = tencrop_evaluation
        self.tencrop_size = tencrop_size

    def forward(
        self, x: torch.Tensor
    ) -> torch.Tensor:  # (error: Signature of "forward" incompatible with supertype "LightningModule")  # NOQA: E501
        # [TODO] Remove type ignore after this issue solve.
        #  https://github.com/PyTorchLightning/pytorch-lightning/issues/5023
        return self.network(x)

    def training_step(
        self, batch: list[torch.Tensor], batch_idx: int
    ) -> torch.Tensor:  # (error: Signature of "training_step" incompatible with supertype "LightningModule")  # NOQA: E501
        # [TODO] Remove type ignore after this issue solve.
        #  https://github.com/PyTorchLightning/pytorch-lightning/issues/5023
        x, y = batch

        if self.use_mixup:
            inputs, y_a, y_b, lam = mixup_data(x, y, self.mixup_alpha)
            inputs, y_a, y_b = map(Variable, (inputs, y_a, y_b))

            y_hat = self.network(inputs)
            loss = mixup_criterion(F.cross_entropy, y_hat, y_a, y_b, lam)
        elif self.use_cutmix:
            inputs, y_a, y_b, y_a_pixel_ratio = cutmix_data(x, y, self.cutmix_alpha)
            inputs, y_a, y_b = map(Variable, (inputs, y_a, y_b))

            y_hat = self.network(inputs)
            loss = cutmix_criterion(F.cross_entropy, y_hat, y_a, y_b, y_a_pixel_ratio)
        else:
            y_hat = self.network(x)
            loss = F.cross_entropy(y_hat, y)

        if self.weight_regularizers:
            for weight_regularizer in self.weight_regularizers:
                if isinstance(weight_regularizer, SparsificationRegularizer):
                    loss += weight_regularizer(self.network, loss)
                else:
                    loss += weight_regularizer(self.network)

        if self.quantization_regularizers:
            for quantization_regularizer in self.quantization_regularizers:
                loss += quantization_regularizer.loss

        self.log("train_loss", loss, on_epoch=True)
        return loss

    def on_train_batch_start(self, batch: list[torch.Tensor], batch_idx: int) -> None:
        if self.quantization_regularizers:
            for quantization_regularizer in self.quantization_regularizers:
                quantization_regularizer.on_train_batch_start(self.trainer, self, batch, batch_idx)

    def on_train_batch_end(self, outputs: list[torch.Tensor], batch: list[torch.Tensor], batch_idx: int) -> None:
        if self.quantization_regularizers:
            for quantization_regularizer in self.quantization_regularizers:
                quantization_regularizer.on_train_batch_end(self.trainer, self, outputs, batch, batch_idx)

    def on_validation_epoch_start(self) -> None:
        if self.tencrop_evaluation:
            _logger.warning(
                "With TenCrop evaluation, `pin_memory=False` should be set to DataLoader to avoid Runtime Error."
            )
            self.tencrop_transform = Compose(
                [
                    TenCrop(self.tencrop_size),
                    Lambda(lambda crops: torch.stack([crop for crop in crops])),
                ]
            )

    def validation_step(
        self, batch: list[torch.Tensor], batch_idx: int
    ) -> None:  # (error: Signature of "validation_step" incompatible with supertype "LightningModule")  # NOQA: E501
        # [TODO] Remove type ignore after this issue solve.
        #  https://github.com/PyTorchLightning/pytorch-lightning/issues/5023
        x, y = batch
        if self.tencrop_evaluation:
            x = self.tencrop_transform(x)
            ncrops, batch_size, channel, height, width = x.size()
            tencrop_y_hat = self.network(x.view(-1, channel, height, width))
            y_hat = tencrop_y_hat.view(ncrops, batch_size, -1).mean(0)  # logits are averaged over crops
        else:
            y_hat = self.network(x)
        # The input for cross entropy is expected to contain raw, unnormalized scores for each class.
        loss = F.cross_entropy(y_hat, y)
        self.log("val_loss", loss, on_step=True, prog_bar=True)

        # Softmax is needed here to fix ValueError: Probabilities in preds must sum up to 1 accross the C dimension.
        predicted_probs = F.softmax(y_hat, dim=1)
        self.accuracy_top1(predicted_probs, y)
        self.accuracy_top5(predicted_probs, y)
        self.log("val_acc_top1", self.accuracy_top1, on_step=False, on_epoch=True, prog_bar=True)
        self.log("val_acc_top5", self.accuracy_top5, on_step=False, on_epoch=True, prog_bar=True)

    def get_network_params(self, weight_decay: float) -> list[dict[str, Any]]:
        decay, no_decay = [], []
        for name, param in self.network.named_parameters():
            if not param.requires_grad:
                continue  # frozen weights
            if len(param.shape) == 1 or name.endswith(".bias") or "pixel_embedding" in name or "bineal" in name:
                no_decay.append(param)
            else:
                decay.append(param)
        return [{"params": no_decay, "weight_decay": 0.0}, {"params": decay, "weight_decay": weight_decay}]

    def validation_epoch_end(self, validation_step_outputs: list[None]) -> None:
        weight_flip = self.weight_change_metric.compute()
        for key, value in weight_flip.items():
            self.log(f"quantized_weight_change/{key}", value, on_step=False, on_epoch=True)
        self.weight_change_metric.update()

    def configure_optimizers(self) -> tuple[list[torch.optim.Optimizer], list[torch.optim.lr_scheduler._LRScheduler]]:
        network_params = self.get_network_params(self.optimizer_cfg.weight_decay)
        optimizer = hydra.utils.instantiate(
            self.optimizer_cfg, params=network_params, lr=self.learning_rate, _convert_="all"
        )
        scheduler = hydra.utils.instantiate(self.scheduler_cfg, optimizer=optimizer, _convert_="all")
        return [optimizer], [scheduler]

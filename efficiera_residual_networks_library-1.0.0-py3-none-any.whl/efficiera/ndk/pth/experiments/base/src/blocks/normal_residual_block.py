from __future__ import annotations

from typing import ClassVar, Optional, Type

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.activation_quantizers.binary_activation import BinaryActivation
from efficiera.ndk.pth.experiments.base.src.layers.quantizable_conv2d_for_binealnet import (
    QuantizableConv2dForBiNealNet,
)
from efficiera.ndk.pth.experiments.base.src.weight_quantizers.binary_learning_parameter_scaling import (
    BinaryLearningParameterScaling,
)


class NormalResidualBlock(nn.Module):
    """Residual connection block used in ResNet.
    This block is normal ResNet block. That is, convolution is followed by batch normalization and activations
    In order to make the calculation possible in Efficiera,
    the weight quantizer and the activation quantizer cannot be selected.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        stride (int, optional): Value of stride. Defaults to ``1``.
        bn_momentum (float, optional): Momentum value for the batch normalization. Defaults to ``0.1``.
        alpha_dim (int, optional): Dimension of the scaling alpha parameter. Defaults to ``1``.
        weight_quantizer (Type[BinaryLearningParameterScaling], optional): Weight quantizer for the convolution. Defaults to ``BinaryLearningParameterScaling``.
        activation_quantizer (Type[BinaryActivation], optional): Activation quantizer. Defaults to ``BinaryActivation``.
    """  # NOQA: E501

    expansion: ClassVar[int] = 1

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        bn_momentum: float = 0.1,
        alpha_dim: int = 1,
        weight_quantizer: Optional[Type[BinaryLearningParameterScaling]] = BinaryLearningParameterScaling,
        activation_quantizer: Optional[Type[BinaryActivation]] = BinaryActivation,
    ):
        super().__init__()
        if weight_quantizer is None:
            self.downsample = None
            if stride != 1 or in_channels != self.expansion * out_channels:
                self.downsample = nn.Sequential(
                    QuantizableConv2dForBiNealNet(
                        in_channels=in_channels,
                        out_channels=self.expansion * out_channels,
                        kernel_size=1,
                        weight_quantizer=weight_quantizer,
                        alpha_dim=alpha_dim,
                        stride=stride,
                        bias=False,
                        disable_post_scale=False,
                    ),
                    nn.BatchNorm2d(self.expansion * out_channels, momentum=bn_momentum),
                )

        else:
            # The skip connection is always equipped with a binary convolution, regardless of whether the layer downsamples or not. # NOQA: E501
            # ref: BiNealNet <https://arxiv.org/abs/2202.03716>
            self.downsample = nn.Sequential(
                QuantizableConv2dForBiNealNet(
                    in_channels=in_channels,
                    out_channels=self.expansion * out_channels,
                    kernel_size=1,
                    weight_quantizer=weight_quantizer,
                    alpha_dim=alpha_dim,
                    stride=stride,
                    bias=False,
                    disable_post_scale=False,
                ),
                nn.BatchNorm2d(self.expansion * out_channels, momentum=bn_momentum),
            )

        self.conv1 = QuantizableConv2dForBiNealNet(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=3,
            weight_quantizer=weight_quantizer,
            alpha_dim=alpha_dim,
            stride=stride,
            padding=1,
            bias=False,
            disable_post_scale=False,
        )
        self.bn1 = nn.BatchNorm2d(out_channels, momentum=bn_momentum)
        self.act1 = (
            activation_quantizer(out_channels, disable_post_scale=False)
            if activation_quantizer is not None
            else nn.ReLU(inplace=True)
        )
        self.conv2 = QuantizableConv2dForBiNealNet(
            in_channels=out_channels,
            out_channels=self.expansion * out_channels,
            kernel_size=3,
            weight_quantizer=weight_quantizer,
            alpha_dim=alpha_dim,
            padding=1,
            bias=False,
            disable_post_scale=False,
        )
        self.bn2 = nn.BatchNorm2d(out_channels, momentum=bn_momentum)
        self.act2 = (
            activation_quantizer(self.expansion * out_channels, disable_post_scale=False)
            if activation_quantizer is not None
            else nn.ReLU(inplace=True)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.act1(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample:
            identity = self.downsample(x)

        out += identity
        out = self.act2(out)

        return out

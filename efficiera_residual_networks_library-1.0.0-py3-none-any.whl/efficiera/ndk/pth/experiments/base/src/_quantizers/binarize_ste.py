from typing import Any

import torch

from efficiera.ndk.pth.experiments.base.src._quantizers.binarize import binarize


class Binalize_STE(torch.autograd.Function):
    """Straight-through Estimator(STE) for binarize(). (torch.autograd.Function)

    `op_type` is ``SignFunction``.
    """

    @staticmethod
    def symbolic(g: Any, x: torch.Tensor) -> Any:
        return g.op("lm::SignFunction", x)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \mathbf{Y} & = \text{sign}\big(\mathbf{W}\big) &\\
            \end{align}

        Args:
            w (torch.Tensor): Input tensor in NCHW format to be quantized in this quantizer or
                        weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.

        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        return binarize(w)

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> torch.Tensor:
        return grad_output

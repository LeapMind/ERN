import torch


def binarize(x: torch.Tensor) -> torch.Tensor:
    """This is custom sign function for quantizer. The different from torch.sign(x) is sign of 0 is 1 instead of 0.

    Args:
        x (torch.Tensor): Input tensor.

    Returns:
        torch.tensor: A new tensor with the custom signs of the elements of input.
    """
    return torch.where(x >= 0, 1.0, -1.0)

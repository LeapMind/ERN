import torch


def round_half_up(x: torch.Tensor) -> torch.Tensor:
    """This is custom round function for quantizer. The diffetent from torch.round(x) is round of 0.5 is 1 instead of 0.

    Args:
        x (torch.Tensor): Input tensor.
    Returns:
        torch.Tensor: A new tensor with the custom round of the elements of input.
    """
    return torch.floor(x + 0.5)

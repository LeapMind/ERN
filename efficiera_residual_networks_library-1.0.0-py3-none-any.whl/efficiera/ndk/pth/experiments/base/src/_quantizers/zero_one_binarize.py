import torch


def zero_one_binarize(x: torch.Tensor) -> torch.Tensor:
    """This is custom heviside step function for quantizer. When input is 0, returns 1.

    Args:
        x (torch.Tensor): Input Tensor.

    Returns:
        torch.Tensor: A new tensor with heaviside function of the elements of input.
    """
    return torch.where(x >= 0.0, 1.0, 0.0)

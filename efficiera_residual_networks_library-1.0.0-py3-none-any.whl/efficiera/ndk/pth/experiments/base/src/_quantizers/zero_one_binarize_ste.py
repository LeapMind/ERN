from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.zero_one_binarize import zero_one_binarize


class ZeroOneBinarizeFunctionSTE(torch.autograd.Function):
    """ZeroOne Binarize function with STE. (torch.autograd.Function)

    This quantization is a weight quantizer, which is used to get 0 or 1 weight as intermediate weight.

    `op_type` is ``ZeroOneBinarize``.
    """

    @staticmethod
    def symbolic(g: Any, w: Any) -> Any:
        return g.op("lm::ZeroOneBinarize", w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor) -> torch.Tensor:
        return zero_one_binarize(w)

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> torch.Tensor:
        """Multiply 0.5 in order for gradient value to be consistent with the case of STE using -1, 1 weight.

        Because [-1, 1] can be moved to [0, 1] by multiplying 0.5 and adding 0.5,
        gradient should be multiplied by 0.5
        """
        return 0.5 * grad_output


class ZeroOneBinarizeSTE(nn.Module):
    r"""ZeroOne Binarize function with STE.
    This quantization returns 0/1 binary weights.

    This class is used in GeneralDomainScaling quantizer in
    `Binary domain generalization for sparsifying binary neural networks`_

    .. _Binary domain generalization for sparsifying binary neural networks:
        https://arxiv.org/pdf/2306.13515.pdf
    """

    def __init__(self) -> None:
        super().__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return ZeroOneBinarizeFunctionSTE.apply(x)

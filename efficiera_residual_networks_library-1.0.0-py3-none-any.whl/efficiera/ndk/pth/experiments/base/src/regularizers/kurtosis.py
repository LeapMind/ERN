# ------------------------------------------------------------------------------
# Portions of this code are from
# https://github.com/BlueAnon/BD-BNN/blob/a09ca80/kurtosis.py
# Licensed under the MIT License.
# ------------------------------------------------------------------------------


import torch
import torch.nn as nn


class _KurtosisWeight:
    def __init__(
        self,
        weight_tensor: torch.Tensor,
        kurtosis_target: float = 1.8,
    ) -> None:
        self.weight_tensor = weight_tensor
        self.kurtosis_target = kurtosis_target

    def kurtosis_calc(self) -> torch.Tensor:
        mean_output = torch.mean(self.weight_tensor)
        std_output = torch.std(self.weight_tensor)
        kurtosis_val = torch.mean((((self.weight_tensor - mean_output) / std_output) ** 4))
        kurtosis_loss = torch.mean((kurtosis_val - self.kurtosis_target) ** 2)
        return kurtosis_loss


class KurtosisRegularizer(nn.Module):
    """Kurtosis regularization of weights.

    Reference:
        .. [1] `Bi-Modal Distributed Binarized Neural Networks <https://arxiv.org/abs/2204.02004>`_
    """

    def __init__(self, kurtosis_target: float = 1.8) -> None:
        self.kurtosis_target = kurtosis_target

    def __call__(self, model: nn.Module) -> torch.Tensor:
        """Calculate Kurtosis loss.

        Return:
            torch.Tensor: Kurtosis loss value.
        """

        kurt_values = []
        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue  # frozen weights
            if len(param.shape) == 1 or name.endswith(".bias") or "pixel_embedding" in name:
                continue
            kurtosis = _KurtosisWeight(param, kurtosis_target=self.kurtosis_target)
            kurt_values.append(kurtosis.kurtosis_calc())
        kurtosis_loss = torch.mean(torch.stack(kurt_values))
        return kurtosis_loss

import torch
import torch.nn as nn
import torch.nn.functional as F

from efficiera.ndk.pth.experiments.base.src._quantizers.zero_one_binarize_ste import ZeroOneBinarizeFunctionSTE


class SparsificationRegularizer(nn.Module):
    r"""Sparsification regularizer, which regularizes network weights to have few positive weights.

    This function is adopted in `Binary domain generalization for sparsifying binary neural networks`_.
    The difference from the original implementation is that it can hold positive loss value
        even when expected_connection >= 0.5.

    Args:
        expected_connection (float): An expected ratio of weight with positive value. Defaults to ``0.05``.
            expected connection must be in the interval of [0, 1).
        gamma (float): A hyperparameter to balance the loss. Defaults to ``0.05``.
            gamma must be in the interval of [0, 1).

    .. _Binary domain generalization for sparsifying binary neural networks:
        https://arxiv.org/pdf/2306.13515.pdf
    """

    def __init__(self, expected_connection: float = 0.05, gamma: float = 0.05) -> None:
        if not (0 <= expected_connection <= 1):
            raise ValueError(f"expected connection must be in the interval of [0, 1], but got {expected_connection}.")
        if not (0 <= gamma < 1):
            raise ValueError(f"gamma must be in the interval of [0, 1), but got {gamma}.")
        self.expected_connection = expected_connection
        self.gamma = gamma

    def __call__(self, model: nn.Module, train_loss: torch.Tensor) -> torch.Tensor:
        """Calculate sparsification regularizer balanced with classification loss.

        Args:
            model (nn.Module): The model which is to be regularized to have few positive weights.
            train_loss (torch.Tensor): The train loss. It is used to calculate the coefficient of sparsification loss.

        Returns:
            torch.Tensor: The sparsification loss whose value is balanced with classification loss.
        """
        sp_loss = self.calc_sparsification_loss(model)
        coef = self.calc_balance_coef(sp_loss, train_loss)
        return coef * sp_loss

    def calc_sparsification_loss(self, model: nn.Module) -> torch.Tensor:
        """Calculate Sparsification loss.

        Args:
            model (nn.Module): The model to be regularized.

        Returns:
            torch.Tensor: The sparsification loss.
        """
        try:
            device = next(model.parameters()).device
        except StopIteration:
            device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
        total_1s = torch.tensor(0.0, device=device)
        total_params = 0
        for module in model.modules():
            if isinstance(module, nn.Conv2d):
                total_1s += torch.sum(ZeroOneBinarizeFunctionSTE.apply(module.weight))
                total_params += torch.numel(module.weight)

        sp_loss = F.relu(total_1s / total_params - self.expected_connection)
        return sp_loss

    def calc_balance_coef(self, sp_loss: torch.Tensor, train_loss: torch.Tensor) -> float:
        """Calculate the coefficient of sparsification loss to balance with classification loss.

        Args:
            sp_loss (torch.Tensor): The tensor of sparsification loss.
            train_loss (torch.Tensor): The train loss.

        Returns:
            float: The coefficient of sparsification loss.
        """
        if self.gamma == 0:
            return 0.0
        elif sp_loss <= 1e-4:
            return 0.0
        with torch.no_grad():
            delta = self.gamma * train_loss.item() / (sp_loss.item() * (1 - self.gamma))
        return delta

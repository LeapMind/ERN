import torch

from efficiera.ndk.pth.experiments.base.src.quantization_regularizers.activation_quantization_regularizer import (
    ActivationQuantizationRegularizer,
)
from efficiera.ndk.pth.experiments.base.src.quantization_regularizers.bin import bin_regularize


class BinActivationQuantizationRegularizer(ActivationQuantizationRegularizer):
    def __init__(self, lambda_factor: float) -> None:
        super().__init__()
        self.lambda_factor = lambda_factor

    def _regularize(self, input: torch.Tensor, output: torch.Tensor) -> torch.Tensor:
        return bin_regularize(input, output, lambda_factor=self.lambda_factor)

import torch
import torch.nn.functional as F


def bin_regularize(input: torch.Tensor, output: torch.Tensor, lambda_factor: float) -> torch.Tensor:
    loss = torch.tensor(0.0)
    input = torch.flatten(input)
    output = torch.flatten(output.detach())
    bin_outputs, inverse_indices = torch.unique(output, sorted=True, return_inverse=True)
    for i, _ in enumerate(bin_outputs):
        bin_inputs = input[inverse_indices == i]
        bin_output = output[inverse_indices == i]
        loss += F.mse_loss(torch.mean(bin_inputs), torch.mean(bin_output))
        if bin_inputs.size() != (1,):
            loss += torch.var(bin_inputs)
    return loss * lambda_factor

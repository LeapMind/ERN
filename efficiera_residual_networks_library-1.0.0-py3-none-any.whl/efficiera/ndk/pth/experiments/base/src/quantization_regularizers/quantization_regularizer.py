from __future__ import annotations

from abc import ABC, abstractmethod

import pytorch_lightning as pl
import torch
import torch.nn as nn


class QuantizationRegularizer(ABC):
    def __init__(self) -> None:
        self._hook_handles: list[torch.utils.hooks.RemovableHandle] | None = None
        self._loss: torch.Tensor | None = None

    @property
    def loss(self) -> torch.Tensor:
        if self._loss is None:
            raise ValueError
        return self._loss

    @abstractmethod
    def _register_hook(self, pl_module: nn.Module) -> list[torch.utils.hooks.RemovableHandle]:
        raise NotImplementedError

    @abstractmethod
    def _regularize(self, input: torch.Tensor, output: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError

    def _hook(self, module: nn.Module, inputs: tuple[torch.Tensor, ...], output: torch.Tensor) -> None:
        if self._loss is None:
            raise ValueError
        if len(inputs) != 1:
            raise ValueError
        if "ChannelWise" in type(module).__name__:
            for channel_wise_input, channel_wise_output in zip(inputs[0], output):
                self._loss += self._regularize(channel_wise_input, channel_wise_output)
        else:
            self._loss += self._regularize(inputs[0], output)

    def on_train_batch_start(
        self, trainer: pl.Trainer, pl_module: nn.Module, batch: list[torch.Tensor], batch_idx: int
    ) -> None:
        if self._hook_handles is not None:
            raise ValueError
        if self._loss is not None:
            raise ValueError
        self._hook_handles = self._register_hook(pl_module)
        self._loss = torch.tensor(0.0)

    def on_train_batch_end(
        self,
        trainer: pl.Trainer,
        pl_module: pl.LightningModule,
        outputs: list[torch.Tensor],
        batch: list[torch.Tensor],
        batch_idx: int,
    ) -> None:
        self._loss = None
        if self._hook_handles:
            for hook_handle in self._hook_handles:
                hook_handle.remove()
        self._hook_handles = None

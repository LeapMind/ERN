import torch

from efficiera.ndk.pth.experiments.base.src.quantization_regularizers.bin import bin_regularize
from efficiera.ndk.pth.experiments.base.src.quantization_regularizers.weight_quantization_regularizer import (
    WeightQuantizationRegularizer,
)


class BinWeightQuantizationRegularizer(WeightQuantizationRegularizer):
    def __init__(self, lambda_factor: float) -> None:
        super().__init__()
        self.lambda_factor = lambda_factor

    def _regularize(self, input: torch.Tensor, output: torch.Tensor) -> torch.Tensor:
        return bin_regularize(input, output, lambda_factor=self.lambda_factor)

from __future__ import annotations

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.quantization_regularizers.quantization_regularizer import (
    QuantizationRegularizer,
)


class WeightQuantizationRegularizer(QuantizationRegularizer):
    def _register_hook(self, network: nn.Module) -> list[torch.utils.hooks.RemovableHandle]:
        hook_handles: list[torch.utils.hooks.RemovableHandle] = []
        for module in network.modules():
            if hasattr(module, "weight_quantizer") and isinstance(module.weight_quantizer, nn.Module):
                hook_handles.append(module.weight_quantizer.register_forward_hook(self._hook))
        return hook_handles

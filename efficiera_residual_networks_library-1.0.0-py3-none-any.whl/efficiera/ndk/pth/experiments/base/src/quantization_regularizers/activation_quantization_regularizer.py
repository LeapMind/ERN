from __future__ import annotations

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.quantization_regularizers.quantization_regularizer import (
    QuantizationRegularizer,
)


class ActivationQuantizationRegularizer(QuantizationRegularizer):
    def _register_hook(self, pl_module: nn.Module) -> list[torch.utils.hooks.RemovableHandle]:
        hook_handles: list[torch.utils.hooks.RemovableHandle] = []
        for module in pl_module.modules():
            if type(module).__name__.endswith("Quantization"):
                hook_handles.append(module.register_forward_hook(self._hook))
        return hook_handles

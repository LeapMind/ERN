from __future__ import annotations

import logging
from typing import Any, Callable, Optional

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.fused_modules.conv_bn_act import ConvBnAct
from efficiera.ndk.pth.layers import QuantizableConv2d, QuantizedConv2dBlock
from efficiera.ndk.pth.operators import PixelEmbeddingV3, SpaceToDepth
from efficiera.ndk.pth.quantizers import BinaryMeanScaling, LearnedStepSizeQuantization

_logger = logging.getLogger(__name__)


class LMNetV1(nn.Module):
    """LMNetV1 Network

    Args:
        num_classes (int): Number of classes in the input image
        quantize (bool, optional): If ``True``, the network is quantized. Defaults to ``True``
        in_channels (int, optional): Number of channels in the input image. Defaults to ``3``
        apply_pixel_embedding (bool, optional): Flag to enable / disable PixelEmbedding. Defaults to ``True``
        block (Type[QuantizedConv2dBlock]): Class of the block.
        last_conv (Type[QuantizableConv2d]): Class of the last convolution.
        weight_quantizer (Callable[[], nn.Module] | None, optional): The weight quantizer to use.
            Defaults to ``BinaryMeanScaling``.
        activation_quantizer (Callable[..., nn.Module] | None, optional): The activation quantizer to use.
            Defaults to ``LearnedStepSizeQuantization``.
    """

    def __init__(
        self,
        block: type[QuantizedConv2dBlock | ConvBnAct],
        num_classes: int,
        in_channels: int = 3,
        apply_pixel_embedding: bool = True,
        last_conv: type[QuantizableConv2d] = QuantizableConv2d,
        weight_quantizer: Optional[Callable[..., nn.Module]] = BinaryMeanScaling,
        activation_quantizer: Optional[Callable[..., nn.Module]] = LearnedStepSizeQuantization,
        bn_momentum: float = 0.1,
    ) -> None:
        super().__init__()
        self.apply_pixel_embedding = apply_pixel_embedding
        self.pixel_embedding: Any = None
        if self.apply_pixel_embedding:
            out_channels = 30
            self.pixel_embedding = PixelEmbeddingV3(in_channels=in_channels, expansion=out_channels // in_channels)

        def get_block_kwargs() -> dict[str, Any]:
            return {
                "weight_quantizer": weight_quantizer() if weight_quantizer is not None else None,
                "activation": activation_quantizer() if activation_quantizer is not None else torch.nn.ReLU(),
                "bn_momentum": bn_momentum,
            }

        in_channels = out_channels if self.apply_pixel_embedding else in_channels
        self.block1 = block(in_channels, 32, 3, **get_block_kwargs())
        self.block2 = block(32, 64, 3, **get_block_kwargs())
        self.block3 = block(256, 128, 3, **get_block_kwargs())
        self.block4 = block(128, 64, 3, **get_block_kwargs())
        self.block5 = block(256, 128, 3, **get_block_kwargs())
        self.block6 = block(512, 64, 3, **get_block_kwargs())
        self.last_conv = last_conv(
            64, num_classes, 1, weight_quantizer() if weight_quantizer is not None else None, bias=False
        )
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.flatten = nn.Flatten()

        self.features = nn.Sequential(
            self.block1,
            self.block2,
            SpaceToDepth(2),
            self.block3,
            self.block4,
            SpaceToDepth(2),
            self.block5,
            SpaceToDepth(2),
            self.block6,
            self.last_conv,
            self.avg_pool,
            self.flatten,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.apply_pixel_embedding:
            x = self.pixel_embedding(x)
        else:
            x = x.float()

        x = self.features(x)
        return x


def lmnetv1(num_classes: int, **kwargs: Any) -> LMNetV1:
    """Helper function to generate the network structure of LMNetV1.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMNetV1: A nn.Module with the structure of LMPreActResNet18
    """
    return LMNetV1(QuantizedConv2dBlock, num_classes, **kwargs)


def lmnetv1_fused(num_classes: int, **kwargs: Any) -> LMNetV1:
    """Helper function to generate the network structure of LMNetV1 with simulated inference.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMNetV1: A nn.Module with the structure of LMNetV1
    """
    return LMNetV1(ConvBnAct, num_classes, **kwargs)

from __future__ import annotations

from typing import Callable, List, Optional

import torch
import torch.nn as nn

from efficiera.ndk.pth.layers import QuantizableConv2d, QuantizedConv2dBlock
from efficiera.ndk.pth.operators import PixelEmbeddingV3
from efficiera.ndk.pth.quantizers import IntegerQuantizer


class MobileNetV1(nn.Module):
    """
    MobileNet V1 main class

    Args:
        num_classes (int, optional): Number of classes. Defaults to ``1000``.
        tiny (bool, optional): Flag whether to use a network structure with small input size. Defaults to ``False``.
        apply_pixel_embedding (bool, optional): If ``True``, add a pixel embedding layer before the first conv.
            Defaults to ``False``.
        pixel_embedding_bit (int, optional): The number of bits of the pixel embedding. Defaults to ``8``.
        width_mult (float, optional): Width multiplier - adjusts number of channels in each layer by this amount.
            Defaults to ``1.0``.
        max_channels (int | None, optional): Max channels. Defaults to ``1024``.
        norm_act_after_dw (bool): Whether to place the batch normalization layer and the activation layer
            after the depthwise convolution. Defaults to ``True``.
        weight_quantizer (Callable[[], nn.Module] | None, optional): The weight quantizer to use.
            Defaults to ``None``.
        activation_quantizer (Callable[..., nn.Module] | None, optional): The activation quantizer to use.
            Defaults to ``None``.
        bn_momentum (float, optional): Momentum of the batch normalization. Defaults to ``0.1``.
    """

    def __init__(
        self,
        num_classes: int = 1000,
        tiny: bool = False,
        apply_pixel_embedding: bool = False,
        pixel_embedding_bit: int = 8,
        width_mult: float = 1.0,
        max_channels: Optional[int] = 1024,
        norm_act_after_dw: bool = True,
        weight_quantizer: Optional[Callable[..., nn.Module]] = None,
        activation_quantizer: Optional[Callable[..., nn.Module]] = None,
        bn_momentum: float = 0.1,
    ) -> None:
        super().__init__()

        self.max_channels = max_channels
        self.norm_act_after_dw = norm_act_after_dw
        self.weight_quantizer = weight_quantizer
        self.activation_quantizer = activation_quantizer
        self.bn_momentum = bn_momentum

        in_channels = 3
        self.pixel_embedding: PixelEmbeddingV3 | None = None
        if apply_pixel_embedding:
            self.pixel_embedding = PixelEmbeddingV3(in_channels=3, expansion=10, k=pixel_embedding_bit)
            in_channels = 30

        model_params = [
            # in_channels, out_channels, stride
            [in_channels, 32, 2 if not tiny else 1],
            [32, 64, 1],
            [64, 128, 2 if not tiny else 1],
            [128, 128, 1],
            [128, 256, 2],
            [256, 256, 1],
            [256, 512, 2],
            [512, 512, 1],
            [512, 512, 1],
            [512, 512, 1],
            [512, 512, 1],
            [512, 512, 1],
            [512, 1024, 2],
            [1024, 1024, 1],
        ]

        features: List[nn.Module] = []
        for in_ch, out_ch, stride in model_params:
            out_ch = self._adjust_channels(int(out_ch * width_mult))
            if features:
                in_ch = self._adjust_channels(int(in_ch * width_mult))
                features.append(self._conv_dw(in_ch, out_ch, stride))
            else:
                features.append(self._conv_bn(in_ch, out_ch, stride))

        self.features = nn.Sequential(*features)

        last_channels = self._adjust_channels(int(model_params[-1][1] * width_mult))
        self.classifier = nn.Linear(last_channels, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.pixel_embedding:
            x = self.pixel_embedding(x)
        else:
            x = x.float()

        x = self.features(x)
        x = nn.functional.adaptive_avg_pool2d(x, (1, 1))  # original: nn.AvgPool2d(7)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

    def _adjust_channels(self, channels: int) -> int:
        if self.max_channels is not None:
            return min(channels, self.max_channels)
        return channels

    def _conv_bn(self, in_channels: int, out_channels: int, stride: int) -> nn.Module:
        return QuantizedConv2dBlock(
            in_channels,
            out_channels,
            3,
            stride=stride,
            padding=1,
            weight_quantizer=self._wq(),
            activation=self._activation(),
            bn_momentum=self.bn_momentum,
        )

    def _conv_dw(self, in_channels: int, out_channels: int, stride: int) -> nn.Module:
        layers: List[nn.Module] = []
        layers.append(
            # dw
            QuantizableConv2d(
                in_channels,
                in_channels,
                3,
                stride=stride,
                padding=1,
                groups=in_channels,
                weight_quantizer=self._wq_dw(),
                bias=False,
            )
        )

        if self.norm_act_after_dw:
            layers.extend(
                [
                    nn.BatchNorm2d(in_channels),
                    self._activation(),
                ]
            )
        elif self.weight_quantizer is not None:
            layers.append(IntegerQuantizer())

        layers.append(
            # pw
            QuantizedConv2dBlock(
                in_channels,
                out_channels,
                1,
                stride=1,
                padding=0,
                weight_quantizer=self._wq(),
                activation=self._activation(),
                bn_momentum=self.bn_momentum,
            )
        )
        return nn.Sequential(*layers)

    def _wq(self) -> nn.Module | None:
        if self.weight_quantizer is not None:
            return self.weight_quantizer()
        return None

    def _wq_dw(self) -> nn.Module | None:
        # Apply 7-bit weight quantizers to the depthwise convolution layers
        if self.weight_quantizer is not None:
            return IntegerQuantizer(k=7, symmetric=True, max_value=4)
        return None

    def _activation(self) -> nn.Module:
        layers: list[nn.Module] = [nn.ReLU(inplace=True)]
        if self.activation_quantizer is not None:
            layers.append(self.activation_quantizer())
        return nn.Sequential(*layers)

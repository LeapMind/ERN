# ------------------------------------------------------------------------------
# Portions of this code are from
# https://github.com/pytorch/vision/blob/deba056/torchvision/models/mobilenetv2.py
# Licensed under the BSD-3-Clause License.
# ------------------------------------------------------------------------------

from __future__ import annotations

from typing import Callable, List, Optional

import torch
import torch.nn as nn

from efficiera.ndk.pth.layers import QuantizableConv2d, QuantizedConv2dBlock
from efficiera.ndk.pth.quantizers import IntegerQuantizer


class InvertedResidual(nn.Module):
    """Inverted residual block used in the MobileNetV2.

    Args:
        in_channels (int): Number of channels of the input.
        out_channels (int): Number of channels produced by the block.
        stride (int): Value of stride.
        expand_ratio (int): Ratio between the channels of input and intermediate feature map.
        norm_layer (Callable[..., nn.Module], optional): Normalization layer. Defaults to ``nn.BatchNorm2d``.
        weight_quantizer (Callable[[], nn.Module], optional): Weight quantizer for the convolution. Defaults to ``None``.
        activation_quantizer (Callable[..., nn.Module], optional): Activation quantizer. Defaults to ``None``.
        bn_momentum (float, optional): Momentum value for the batch normalization. Defaults to ``0.1``.
    """  # NOQA: E501

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int,
        expand_ratio: int,
        norm_layer: Callable[..., nn.Module] = nn.BatchNorm2d,
        weight_quantizer: Optional[Callable[..., nn.Module]] = None,
        activation_quantizer: Optional[Callable[..., nn.Module]] = None,
        bn_momentum: float = 0.1,
    ) -> None:
        super().__init__()
        self.stride = stride
        if stride not in [1, 2]:
            raise ValueError(f"stride should be 1 or 2 insted of {stride}")

        hidden_dim = int(round(in_channels * expand_ratio))
        self.use_res_connect = self.stride == 1 and in_channels == out_channels

        self.weight_quantizer = weight_quantizer
        self.activation_quantizer = activation_quantizer

        layers: List[nn.Module] = []
        if expand_ratio != 1:
            # pw
            layers.append(
                QuantizedConv2dBlock(
                    in_channels,
                    hidden_dim,
                    kernel_size=1,
                    padding=0,
                    weight_quantizer=self._wq(),
                    activation=self._activation(),
                    bn_momentum=bn_momentum,
                )
            )
        layers.extend(
            [
                # dw
                QuantizedConv2dBlock(
                    hidden_dim,
                    hidden_dim,
                    kernel_size=3,
                    stride=stride,
                    padding=1,
                    groups=hidden_dim,
                    weight_quantizer=self._wq_dw(),
                    activation=self._activation(),
                    bn_momentum=bn_momentum,
                ),
                # pw-linear
                QuantizableConv2d(
                    hidden_dim,
                    out_channels,
                    1,
                    stride=1,
                    padding=0,
                    bias=False,
                    weight_quantizer=self._wq(),
                ),
                norm_layer(out_channels),
            ]
        )
        if self.weight_quantizer is not None:
            layers.append(IntegerQuantizer(symmetric=True, max_value=8))

        self.conv = nn.Sequential(*layers)
        self.skip_add = nn.quantized.FloatFunctional()
        self.out_channels = out_channels
        self._is_cn = stride > 1

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.use_res_connect:
            return self.skip_add.add(x, self.conv(x))
        else:
            return self.conv(x)

    def _wq(self) -> nn.Module | None:
        if self.weight_quantizer is not None:
            return self.weight_quantizer()
        return None

    def _wq_dw(self) -> nn.Module | None:
        # Apply 7-bit weight quantizers to the depthwise convolution layers
        if self.weight_quantizer is not None:
            return IntegerQuantizer(k=7, symmetric=True, max_value=2)
        return None

    def _activation(self) -> nn.Module | None:
        layers: list[nn.Module] = [nn.ReLU(inplace=True)]
        if self.activation_quantizer is not None:
            layers.append(self.activation_quantizer())
        return nn.Sequential(*layers)


class MobileNetV2(nn.Module):
    """
    MobileNet V2 main class

    Args:
        num_classes (int, optional): Number of classes. Defaults to ``1000``.
        tiny (bool, optional): Flag whether to use a network structure with small input size. Defaults to ``False``.
        width_mult (float, optional): Width multiplier - adjusts number of channels in each layer by this amount.
            Defaults to ``1.0``.
        inverted_residual_setting (List[List[int]] | None, optional): Network structure. Defaults to ``None``.
        round_nearest (int, optional): Round the number of channels in each layer to be a multiple of this number.
            Set to 1 to turn off rounding. Defaults to ``8``.
        block (Callable[..., nn.Module], optional): Module specifying inverted residual building block for mobilenet.
            Defaults to ``InvertedResidual``.
        norm_layer (Callable[..., nn.Module], optional): Module specifying the normalization layer to use.
            Defaults to ``nn.BatchNorm2d``.
        dropout (float, optional): The droupout probability. Defaults to ``0.2``.
        weight_quantizer (Callable[[], nn.Module] | None, optional): The weight quantizer to use.
            Defaults to ``None``.
        activation_quantizer (Callable[..., nn.Module] | None, optional): The activation quantizer to use.
            Defaults to ``None``.
        bn_momentum (float, optional): Momentum of the batch normalization. Defaults to ``0.1``.
    """

    def __init__(
        self,
        num_classes: int = 1000,
        tiny: bool = False,
        width_mult: float = 1.0,
        inverted_residual_setting: Optional[List[List[int]]] = None,
        round_nearest: int = 8,
        block: Callable[..., nn.Module] = InvertedResidual,
        norm_layer: Callable[..., nn.Module] = nn.BatchNorm2d,
        dropout: float = 0.2,
        weight_quantizer: Optional[Callable[..., nn.Module]] = None,
        activation_quantizer: Optional[Callable[..., nn.Module]] = None,
        bn_momentum: float = 0.1,
    ) -> None:
        super().__init__()

        input_channel = 32
        last_channel = 1280

        self.weight_quantizer = weight_quantizer
        self.activation_quantizer = activation_quantizer

        if inverted_residual_setting is None:
            inverted_residual_setting = [
                # t, c, n, s
                [1, 16, 1, 1],
                [6, 24, 2, 2 if not tiny else 1],
                [6, 32, 3, 2],
                [6, 64, 4, 2],
                [6, 96, 3, 1],
                [6, 160, 3, 2],
                [6, 320, 1, 1],
            ]

        # only check the first element, assuming user knows t, c, n, s are required
        if len(inverted_residual_setting) == 0 or len(inverted_residual_setting[0]) != 4:
            raise ValueError(
                f"inverted_residual_setting should be non-empty or a 4-element list, got {inverted_residual_setting}"
            )

        # building first layer
        input_channel = _make_divisible(input_channel * width_mult, round_nearest)
        self.last_channel = _make_divisible(last_channel * max(1.0, width_mult), round_nearest)
        features: List[nn.Module] = [
            QuantizedConv2dBlock(
                3,
                input_channel,
                kernel_size=3,
                stride=2 if not tiny else 1,
                padding=1,
                weight_quantizer=self._wq(),
                activation=self._activation(),
                bn_momentum=bn_momentum,
            )
        ]
        # building inverted residual blocks
        for t, c, n, s in inverted_residual_setting:
            output_channel = _make_divisible(c * width_mult, round_nearest)
            for i in range(n):
                stride = s if i == 0 else 1
                features.append(
                    block(
                        input_channel,
                        output_channel,
                        stride,
                        expand_ratio=t,
                        norm_layer=norm_layer,
                        weight_quantizer=weight_quantizer,
                        activation_quantizer=activation_quantizer,
                        bn_momentum=bn_momentum,
                    )
                )
                input_channel = output_channel
        # building last several layers
        features.append(
            QuantizedConv2dBlock(
                input_channel,
                self.last_channel,
                kernel_size=1,
                weight_quantizer=self._wq(),
                activation=self._activation(),
                bn_momentum=bn_momentum,
            )
        )
        # make it nn.Sequential
        self.features = nn.Sequential(*features)

        # building classifier
        self.classifier = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(self.last_channel, num_classes),
        )

        # weight initialization
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def _wq(self) -> nn.Module | None:
        if self.weight_quantizer is not None:
            return self.weight_quantizer()
        return None

    def _activation(self) -> nn.Module | None:
        layers: list[nn.Module] = [nn.ReLU(inplace=True)]
        if self.activation_quantizer is not None:
            layers.append(self.activation_quantizer())
        return nn.Sequential(*layers)

    def _forward_impl(self, x: torch.Tensor) -> torch.Tensor:
        # This exists since TorchScript doesn't support inheritance, so the superclass method
        # (this one) needs to have a name other than `forward` that can be accessed in a subclass
        x = self.features(x)
        # Cannot use "squeeze" as batch-size can be 1
        x = nn.functional.adaptive_avg_pool2d(x, (1, 1))
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.float()
        return self._forward_impl(x)


def _make_divisible(v: float, divisor: int, min_value: Optional[int] = None) -> int:
    """
    This function is taken from the original tf repo.
    It ensures that all layers have a channel number that is divisible by 8
    It can be seen here:
    https://github.com/tensorflow/models/blob/master/research/slim/nets/mobilenet/mobilenet.py

    Args:
        v (float): Number of channels to be made divisible by the divisor value
        divisor (int): Divisor value
        min_value (int | None, optional): Minimum value of the output
    Returns:
        int: Number of channels that are divisible by the divisor value
    """
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    # Make sure that round down does not go down by more than 10%.
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v

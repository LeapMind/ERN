from __future__ import annotations

import logging
from typing import Any, Optional, Type

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.activation_quantizers.binary_activation import BinaryActivation
from efficiera.ndk.pth.experiments.base.src.blocks.bineal_block import BiNealBlock
from efficiera.ndk.pth.experiments.base.src.blocks.normal_residual_block import NormalResidualBlock
from efficiera.ndk.pth.experiments.base.src.layers.quantizable_conv2d_for_binealnet import (
    QuantizableConv2dForBiNealNet,
)
from efficiera.ndk.pth.experiments.base.src.weight_quantizers.binary_learning_parameter_scaling import (
    BinaryLearningParameterScaling,
)
from efficiera.ndk.pth.layers import Block
from efficiera.ndk.pth.operators import PixelEmbeddingV3

_logger = logging.getLogger(__name__)


class LMNormalResNet(nn.Module):
    """LMNormalResNet.
    The following changes have been made to this network from the original ResNet.

    * Using 7x7 (64ch) stem, which is the structure of Normal ResNet from `Identity Mappings in Deep Residual Networks`_.
    * If the ``tiny`` flag is set to ``True``, the first layer will be 3x3 conv instead of 7x7 stride2 conv as in ResNet20,
      and the next maxpool will be skipped.

    Args:
        block (type[Block]): Class of residual block.
        num_blocks (list[int]): Number of blocks per stage.
        channels (list[int]): Output channel size of conv per stage.
        strides (list[int]): Stride value of the block per stage.
        num_classes (int): Number of classes in the input image.
        tiny (bool, optional): Flag whether to use a network structure with small input size. Defaults to ``False``.
        apply_pixel_embedding (bool, optional): If ``True``, add a pixel embedding layer before the first conv. Defaults to ``True``.
        alpha_dim (int): Dimension of the scaling alpha parameter. Defaults to ``1``.
        bn_momentum (float, optional): Momentum of the batch normalization. Defaults to ``0.1``.
        weight_quantizer (Type[BinaryLearningParameterScaling], optional): The weight quantizer to use. Defaults to ``BinaryLearningParameterScaling``.
        activation_quantizer (Type[BinaryActivation], optional): The activation quantizer to use. Defaults to ``BinaryActivation``.

    .. _Identity Mappings in Deep Residual Networks:
        https://arxiv.org/abs/1603.05027
    """  # NOQA: E501

    def __init__(
        self,
        block: type[Block],
        num_blocks: list[int],
        channels: list[int],
        strides: list[int],
        num_classes: int,
        tiny: bool = False,
        apply_pixel_embedding: bool = True,
        alpha_dim: int = 1,
        bn_momentum: float = 0.1,
        weight_quantizer: Optional[Type[BinaryLearningParameterScaling]] = BinaryLearningParameterScaling,
        activation_quantizer: Optional[Type[BinaryActivation]] = BinaryActivation,
    ) -> None:

        super().__init__()
        self._ch = 64
        self.pixel_embedding: PixelEmbeddingV3 | None = None
        self.alpha_dim = alpha_dim
        self.weight_quantizer = weight_quantizer
        self.activation_quantizer = activation_quantizer
        in_channels = 3

        if apply_pixel_embedding:
            self.pixel_embedding = PixelEmbeddingV3(in_channels=3, expansion=10)
            in_channels = 30

        if tiny:
            # If tiny, using kernel_size=3 to avoid downsampling.
            self.stem = nn.Sequential(
                QuantizableConv2dForBiNealNet(
                    in_channels,
                    self._ch,
                    3,
                    # At the first conv, not binarized the weight parameters.
                    weight_quantizer=None,
                    alpha_dim=alpha_dim,
                    padding=1,
                    bias=False,
                ),
                nn.BatchNorm2d(self._ch, momentum=bn_momentum),
                activation_quantizer(self._ch, disable_post_scale=False)
                if activation_quantizer is not None
                else nn.ReLU(inplace=True),
            )
            self.maxpool = nn.Sequential()
        else:
            # In this module, convolution of padding=3 is performed to bring the architecture closer to the original ResNet18. # NOQA: E501
            # https://github.com/akamaster/pytorch_resnet_cifar10/blob/master/resnet.py
            self.stem = nn.Sequential(
                QuantizableConv2dForBiNealNet(
                    in_channels,
                    self._ch,
                    7,
                    # At the first conv, not binarized the weight parameters.
                    weight_quantizer=None,
                    alpha_dim=alpha_dim,
                    stride=2,
                    padding=3,
                    bias=False,
                ),
                nn.BatchNorm2d(self._ch, momentum=bn_momentum),
                activation_quantizer(self._ch, disable_post_scale=False)
                if activation_quantizer is not None
                else nn.ReLU(inplace=True),
            )
            self.maxpool = nn.Sequential(nn.MaxPool2d(kernel_size=3, stride=2, padding=1))

        blocks = [self._make_layer(block, c, n, s, bn_momentum) for c, n, s in zip(channels, num_blocks, strides)]
        self.features = nn.Sequential(*blocks)

        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.flatten = nn.Flatten()
        # In this module, to get closer to the original ResNet18, make a linear layer at the end.
        self.fc = nn.Linear(self._ch, num_classes)

        for m in self.modules():
            # Initialization of convolution weight parameters is done separately by QuantizableConv2dForBiNealNet.
            if isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, val=1)
                nn.init.zeros_(m.bias)

    def _make_layer(
        self,
        block: type[Block],
        out_channels: int,
        num_blocks: int,
        stride: int = 1,
        bn_momentum: float = 0.1,
    ) -> nn.Sequential:
        layers = []
        for i in range(num_blocks):
            layers.append(
                block(
                    self._ch,
                    out_channels,
                    stride if i == 0 else 1,
                    bn_momentum,
                    self.alpha_dim,
                    self.weight_quantizer,
                    self.activation_quantizer,
                )
            )

            self._ch = out_channels * block.expansion

        return nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.pixel_embedding:
            x = self.pixel_embedding(x)
        else:
            x = x.float()

        out = self.stem(x)
        out = self.maxpool(out)

        out = self.features(out)

        out = self.avg_pool(out)
        out = self.flatten(out)
        out = self.fc(out)

        return out


def _lm_normal_resnet18(block: type[Block], num_calsses: int, m: float, tiny: bool, **kwargs: Any) -> LMNormalResNet:
    original_channels = [64, 128, 256, 512]
    channels = [int(c * m) for c in original_channels]
    return LMNormalResNet(
        block=block,
        num_blocks=[2, 2, 2, 2],
        channels=channels,
        strides=[1, 2, 2, 2],
        num_classes=num_calsses,
        tiny=tiny,
        **kwargs,
    )


def lm_normal_resnet18(num_classes: int = 1000, m: float = 1.0, **kwargs: Any) -> LMNormalResNet:
    """Helper function to generate the network structure of LMNormalResNet18.

    Args:
        num_classes (int, optional): Number of classes. Defaults to ``1000``.
        m (float, optional): channel multiplier. Defaults to ``1.0``.

    Returns:
        LMNormalResNet18: A nn.Module with the structure of LMNormalResNet18
    """
    return _lm_normal_resnet18(NormalResidualBlock, num_classes, m, False, **kwargs)


def lm_normal_resnet18_tiny(num_classes: int = 10, m: float = 1.0, **kwargs: Any) -> LMNormalResNet:
    """Helper function to generate the network structure of LMNormalResNet18Tiny.

    Args:
        num_classes (int, optional): Number of classes. Defaults to ``10``.
        m (float, optional): channel multiplier. Defaults to ``1.0``.

    Returns:
        LMNormalResNet18Tiny: A nn.Module with the structure of LMNormalResNet18Tiny
    """
    return _lm_normal_resnet18(NormalResidualBlock, num_classes, m, True, **kwargs)


def lm_binealnet18(num_classes: int = 1000, m: float = 1.5, **kwargs: Any) -> LMNormalResNet:
    """Helper function to generate the network structure of LMBiNealNet18.

    Args:
        num_classes (int, optional): Number of classes. Defaults to ``1000``.
        m (float, optional): channel multiplier. Defaults to ``1.5``.

    Returns:
        LMBiNealNet18: A nn.Module with the structure of LMBiNealNet18
    """
    return _lm_normal_resnet18(BiNealBlock, num_classes, m, False, **kwargs)


def lm_binealnet18_tiny(num_classes: int = 10, m: float = 1.5, **kwargs: Any) -> LMNormalResNet:
    """Helper function to generate the network structure of LMBiNealNet18Tiny.

    Args:
        num_classes (int, optional): Number of classes. Defaults to ``10``.
        m (float, optional): channel multiplier. Defaults to ``1.5``.

    Returns:
        LMBiNealNet18Tiny: A nn.Module with the structure of LMBiNealNet18Tiny
    """
    return _lm_normal_resnet18(BiNealBlock, num_classes, m, True, **kwargs)

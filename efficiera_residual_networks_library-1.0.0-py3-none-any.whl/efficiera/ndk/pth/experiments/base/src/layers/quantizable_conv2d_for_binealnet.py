from __future__ import annotations

from typing import Any, Type

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.weight_quantizers.binary_learning_parameter_scaling import (
    BinaryLearningParameterScaling,
)


class QuantizableConv2dForBiNealNet(nn.Conv2d):
    """Quantized convolution 2d for BiNealNet.
    This quantization creates a convolution 2d layer with a quantized weight.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (int | tuple[int, int]): Size of the convolving kernel.
        weight_quantizer (Type[BinaryLearningParameterScaling] | None, optional): A quantizer for weight of convolution2d layer. Defaults to ``BinaryLearningParameterScaling``.
        alpha_dim (int, optional): Dimension of the scaling alpha parameter. Defaults to ``1``.
        disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``

    """  # NOQA: E501

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        weight_quantizer: Type[BinaryLearningParameterScaling] | None = BinaryLearningParameterScaling,
        alpha_dim: int = 1,
        disable_post_scale: bool = False,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        super().__init__(in_channels, out_channels, kernel_size, *args, **kwargs)
        # Initilaize weight to calculate mean in the weight quantizer initalization.
        nn.init.kaiming_normal_(self.weight, mode="fan_out", nonlinearity="relu")
        self.weight_quantizer = (
            weight_quantizer(in_channels, out_channels, kernel_size, alpha_dim, self.weight, disable_post_scale)
            if weight_quantizer
            else None
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.weight_quantizer:
            w = self.weight_quantizer(self.weight)
        else:
            w = self.weight

        return nn.functional.conv2d(x, w, self.bias, self.stride, self.padding, self.dilation, self.groups)

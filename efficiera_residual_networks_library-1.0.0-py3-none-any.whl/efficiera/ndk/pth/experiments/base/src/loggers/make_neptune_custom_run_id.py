from __future__ import annotations

from pathlib import Path
import uuid


def make_neptune_custom_run_id(input_custom_run_id_path: str | Path, output_custom_run_id_path: str | Path) -> str:
    custom_run_id = None
    input_custom_run_id_path = Path(input_custom_run_id_path)
    if input_custom_run_id_path.exists():
        custom_run_id = input_custom_run_id_path.read_text()
    else:
        custom_run_id = uuid.uuid4().hex
    output_custom_run_id_path = Path(output_custom_run_id_path)
    output_custom_run_id_path.parent.mkdir(parents=True, exist_ok=True)
    output_custom_run_id_path.write_text(custom_run_id)
    return custom_run_id

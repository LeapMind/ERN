from __future__ import annotations

from logging import getLogger
from typing import Callable

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.fused_modules.conv_bn import ConvBn

_logger = getLogger(__name__)


class ConvBnAct(ConvBn):
    """
    This block of three layers (convolution, batch normalization, and activation)
    simulates quantized inference on the Efficiera V3 for QAT.
    In the forward pass, weight quantizer scale and batch normalization parameters are folded.
    The folded scale is multiplied with the result of the binary convolution.
    In the backward pass, gradients are calculated as usual.
    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (int | tuple[int, int]): Size of the convolving kernel.
        stride (int | tuple[int, int]): Stride of the convolution. Defaults to ``1``
        padding (int | tuple[int, int]): Zero-padding added to both sides of the input. Defaults to ``1``
        groups (int): Number of blocked connections from input channels to output channels. Defaults to ``1``
        weight_quantizer (nn.Module | None, optional): A quantizer for weight of convolution2d layer.
            Defaults to ``None``
        weight_initializer (Callable[[torch.Tensor], None], optional): Initializer for the convolution layer weight. Defaults to ``None``
        activation (Callable[[torch.Tensor], torch.Tensor], optional): Activation function to use. Defaults to ``None``
        bn_momentum (float, optional): Momentum value for the batch normalization. Defaults to ``0.1``
        bias (bool, optional): If ``True``, add bias to convolution. Defaults to ``False``
    """  # NOQA: E501

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        stride: int | tuple[int, int] = 1,
        padding: int | tuple[int, int] = 1,
        groups: int = 1,
        weight_quantizer: nn.Module | None = None,
        weight_initializer: Callable[[torch.Tensor], None] | None = None,
        activation: Callable[[torch.Tensor], torch.Tensor] | None = None,
        bn_momentum: float = 0.1,
        bias: bool = False,
    ) -> None:
        # To make the same constructor's signature as QuantizedConv2dBlock,
        # None is allowed for weight_quantizer in the argument list.
        # However, if wq is None, the folding of wq scale and bn cannot be performed.
        if weight_quantizer is None:
            _logger.error("weight_quantizer should not be None")
            raise ValueError("weight_quantizer should not be None")

        super().__init__(
            in_channels,
            out_channels,
            kernel_size,
            weight_quantizer=weight_quantizer,
            stride=stride,
            padding=padding,
            groups=groups,
            weight_initializer=weight_initializer,
            bn_momentum=bn_momentum,
            bias=bias,
        )
        self.activation = activation

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = ConvBn.forward(self, x)
        if self.activation:
            x = self.activation(x)
        return x

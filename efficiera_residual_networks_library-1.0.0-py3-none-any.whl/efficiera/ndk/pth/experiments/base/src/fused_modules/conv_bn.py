from __future__ import annotations

from logging import getLogger
from typing import Callable

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.binarize import binarize

_logger = getLogger(__name__)


class ConvBn(nn.Module):
    """
    This block of two layers (convolution, batch normalization)
    simulates quantized inference on the Efficiera V3 for QAT.
    In the forward pass, weight quantizer scale and batch normalization parameters are folded.
    The folded scale is multiplied with the result of the binary convolution.
    In the backward pass, gradients are calculated as usual.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (int | tuple[int, int]): Size of the convolving kernel.
        weight_quantizer (nn.Module): A quantizer for weight of convolution2d layer.
        stride (int | tuple[int, int]): Stride of the convolution. Defaults to ``1``
        padding (int | tuple[int, int]): Zero-padding added to both sides of the input. Defaults to ``1``
        groups (int): Number of blocked connections from input channels to output channels. Defaults to ``1``
        weight_initializer (Callable[[torch.Tensor], None], optional): Initializer for the convolution layer weight. Defaults to ``None``
        bn_momentum (float, optional): Momentum value for the batch normalization. Defaults to ``0.1``
        bias (bool, optional): If ``True``, add bias to convolution. Defaults to ``False``
    """  # NOQA: E501

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        weight_quantizer: nn.Module,
        stride: int | tuple[int, int] = 1,
        padding: int | tuple[int, int] = 1,
        groups: int = 1,
        weight_initializer: Callable[[torch.Tensor], None] | None = None,
        bn_momentum: float = 0.1,
        bias: bool = False,
    ) -> None:
        super().__init__()

        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size,
            stride=stride,
            padding=padding,
            groups=groups,
            bias=bias,
        )
        self.weight_quantizer = weight_quantizer

        if weight_initializer:
            weight_initializer(self.conv.weight)

        self.bn = nn.BatchNorm2d(out_channels, momentum=bn_momentum)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # folding wq scale and bn parameters/statistics
        # ref: https://github.com/pytorch/pytorch/blob/67d9790/torch/ao/nn/intrinsic/qat/modules/conv_fused.py#L128

        # construct graph for backward
        conv_out = nn.functional.conv2d(
            x,
            self.weight_quantizer(self.conv.weight),
            bias=self.conv.bias,
            stride=self.conv.stride,
            padding=self.conv.padding,
            dilation=self.conv.dilation,
            groups=self.conv.groups,
        )
        x_backward = self.bn(conv_out)
        # make x_backward not contribute to the return value
        with torch.no_grad():
            x_backward.zero_()

        # compute forward value from here to the end
        x_forward = nn.functional.conv2d(
            x,
            binarize(self.conv.weight),
            bias=None,
            stride=self.conv.stride,
            padding=self.conv.padding,
            dilation=self.conv.dilation,
            groups=self.conv.groups,
        )

        bias_shape = [1] * len(self.conv.weight.shape)
        bias_shape[1] = -1

        if self.bn.training:
            # use batch statistics in train mode
            avg_dims = [0] + list(range(2, len(self.conv.weight.shape)))
            batch_mean = conv_out.mean(avg_dims)
            batch_var = torch.square(conv_out - batch_mean.reshape(bias_shape)).mean(avg_dims)
            batch_std = torch.sqrt(batch_var + self.bn.eps)
            fused_mean = batch_mean - (self.conv.bias if self.conv.bias is not None else 0)
            fused_std = batch_std
        else:
            assert self.bn.running_var is not None
            assert self.bn.running_mean is not None
            # use bn statistics in eval mode
            running_std = torch.sqrt(self.bn.running_var + self.bn.eps)
            fused_mean = self.bn.running_mean - (self.conv.bias if self.conv.bias is not None else 0)
            fused_std = running_std

        fused_scale = self.bn.weight / fused_std * self.weight_quantizer.scale(self.conv.weight)
        x_forward = x_forward * fused_scale.reshape(1, self.conv.out_channels, 1, 1)

        fused_bias = self.bn.bias - self.bn.weight * fused_mean / fused_std
        x_forward += fused_bias.reshape(bias_shape)

        return x_forward.detach() + x_backward

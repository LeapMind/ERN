from __future__ import annotations

import torch
import torch.nn as nn


def calc_kernel_sparsity_ratio(network: nn.Module) -> tuple[float, float]:
    """Calculate the ratio of kernel with all-0 / one-hot weight when weights are quantized to 0/1.

    Args:
        network (nn.Module): A network which has nn.Conv2d module.

    Returns:
        tuple[float, float]: the ratio of all-0 kernel, the ratio of one-hot kernel.
    """
    total_zero_kernel, total_onehot_kernel, total_kernel = 0, 0, 0
    for module in network.modules():
        if isinstance(module, nn.Conv2d):
            count_zero_kernel, count_onehot_kernel, count_kernel = _count_sparse_kernel_conv2d(conv=module)
            total_onehot_kernel += count_onehot_kernel
            total_zero_kernel += count_zero_kernel
            total_kernel += count_kernel
    if total_kernel == 0:
        raise ValueError("Network must have at least one nn.Conv2d module.")
    return total_zero_kernel / total_kernel, total_onehot_kernel / total_kernel


def _count_sparse_kernel_conv2d(conv: nn.Conv2d) -> tuple[int, int, int]:
    """Calculate the number of all-0 kernels, one-hot kernels, and kernels in nn.Conv2d module.

    Args:
        conv (nn.Conv2d): nn.Conv2d module.

    Returns:
        tuple[int, int, int]: Tuple of the number of all-0 kernels, the number of one-hot kernels, the number of kernels
    """
    weight = conv.weight
    count_zero_kernel = 0
    count_onehot_kernel = 0

    num_out_channels, num_in_channels = weight.shape[0], weight.shape[1]
    for out_channel in range(num_out_channels):
        for in_channel in range(num_in_channels):
            kernel = weight[out_channel, in_channel]
            num_one = (kernel >= 0).sum()
            if num_one == 0:
                count_zero_kernel += 1
            if num_one == 1:
                count_onehot_kernel += 1

    count_kernel = num_out_channels * num_in_channels
    return count_zero_kernel, count_onehot_kernel, count_kernel


def calc_param_sparsity_ratio(network: nn.Module) -> float:
    """Calculate the sparsity of the network (the ratio of 0-weight to whole weight) when weights are quantized to 0/1.

    Args:
        network (nn.Module): Network.

    Returns:
        float: The ratio of 0-weight to whole weight when weights are quantized to 0/1.
    """
    total_0s = 0
    total_params = 0
    with torch.no_grad():
        for module in network.modules():
            if isinstance(module, nn.Conv2d):
                total_0s += torch.sum((module.weight < 0))
                total_params += torch.numel(module.weight)
    if total_params == 0:
        raise ValueError("Network must have at least one nn.Conv2d module.")
    return total_0s / total_params

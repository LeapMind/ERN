from __future__ import annotations

import torch
import torch.nn as nn

from efficiera.ndk.pth.layers import QuantizableConv2d


class WeightChangeMetric:
    """
    Class to calculate the ratio of parameters whose quantized values changed for each weight.

    Args:
        model (torch.nn.Module): Model.
    """

    def __init__(self, model: nn.Module) -> None:
        self.model = model
        self.quantized_weights: dict[str, torch.Tensor] = {}
        self.quantized_weights_prev: dict[str, torch.Tensor] = {}
        self._store_current_weights()
        self.update()

    def _store_current_weights(self) -> None:
        for name, module in self.model.named_modules():
            if not isinstance(module, QuantizableConv2d):
                continue
            if not isinstance(module.weight_quantizer, nn.Module):
                continue
            self.quantized_weights[name] = module.weight_quantizer(module.weight.detach()).cpu()

    def update(self) -> None:
        """Update internal state.

        Note:
            Assumed to be called at the end of the epoch, after the metric calculation.
        """
        if self.quantized_weights:
            self.quantized_weights_prev = {k: v for k, v in self.quantized_weights.items()}
        self.quantized_weights.clear()

    def compute(self) -> dict[str, torch.Tensor]:
        """Calculate ratio of quantized value changed parameters for each weight.

        Returns:
            dict[str, torch.Tensor]: Ratio of quantized value changed parameters for each weight.
        """
        result = {}
        num_change_total = torch.tensor(0)
        num_params_total = torch.tensor(0)
        self._store_current_weights()
        for key, current in self.quantized_weights.items():
            prev = self.quantized_weights_prev[key]
            num_change = torch.sum(current * prev < 0)  # TODO: make compatible with w2
            num_params = torch.numel(current)
            result[f"{key}"] = num_change / num_params
            num_change_total += num_change
            num_params_total += num_params

        result["total"] = num_change_total / num_params_total if num_params_total > 0 else torch.tensor([0.0])
        return result

from __future__ import annotations

import logging
from typing import Type, TypeVar

import pytorch_lightning as pl
from pytorch_lightning.loggers.logger import Logger

try:
    from neptune.new.integrations.pytorch_lightning import NeptuneLogger
except ImportError:
    NeptuneLogger = None

_LoggerT = TypeVar("_LoggerT", bound=Logger)
_logger = logging.getLogger(__name__)


def _get_logger(trainer: pl.Trainer, target: Type[_LoggerT]) -> _LoggerT | None:
    """A helper function to get a logger in the trainer.

    Args:
        trainer: The trainer.
        target: The logger class to get.

    Returns:
        The logger if available, None otherwise.
    """
    for pl_logger in trainer.loggers:
        if isinstance(pl_logger, target):
            return pl_logger
    return None


def get_neptune_logger(trainer: pl.Trainer) -> NeptuneLogger | None:
    """A helper function to get a Neptune logger in the trainer.

    Args:
        trainer: The trainer.

    Returns:
        The Neptune logger if available, None otherwise.
    """
    if NeptuneLogger is None:
        return None

    return _get_logger(trainer, NeptuneLogger)

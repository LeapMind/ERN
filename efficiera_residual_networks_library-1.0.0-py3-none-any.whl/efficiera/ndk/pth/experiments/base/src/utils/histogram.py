from __future__ import annotations

from collections.abc import Callable
from collections import defaultdict
from logging import getLogger
from pathlib import Path
from typing import Type

import matplotlib.pyplot as plt
import pytorch_lightning as pl
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torch.utils.hooks import RemovableHandle

from efficiera.ndk.pth.experiments.base.src.activation_quantizers.binary_activation import BinaryActivation
from efficiera.ndk.pth.experiments.base.src.utils._get_neptune_logger import get_neptune_logger
from efficiera.ndk.pth.experiments.base.src.weight_quantizers.binary_channel_wise_mean_scaling import (
    BinaryChannelWiseMeanScaling as BinaryChannelWiseMeanScaling_exp,
)
from efficiera.ndk.pth.experiments.base.src.weight_quantizers.binary_learning_parameter_scaling import (
    BinaryLearningParameterScaling,
)
from efficiera.ndk.pth.quantizers import (
    BinaryChannelWiseMeanScaling,
    BinaryMeanScaling,
    BinaryPower2Scaling,
    HalfWaveGaussianQuantization,
    IntegerQuantizer,
    IntervalEWGSBinaryWeightScaling,
    IntervalEWGSQuantization,
    LearnedStepSizeBinaryWeightScaling,
    LearnedStepSizeQuantization,
)

_logger = getLogger(__name__)


class HistogramPlotter:
    """Class to plot and save histograms of the model's intermediate values.

    Args:
        accumulate_layer_data (bool, optional): Whether to accumulate a full batch data to for layer inputs/outputs histogram.
            Defaults to ``False`` (Use only first mini batch).
    """  # NOQA: E501

    def __init__(self, accumulate_layer_data: bool = False) -> None:
        self.accumulate_layer_data = accumulate_layer_data
        self._clear_intermediate_data()

    def _clear_intermediate_data(self) -> None:
        # Parameters (mainly for quantized weights)
        self.param_dict: dict[str, torch.Tensor] = {}

        # Layer inputs/outputs (mainly for activation)
        self.layer_input_dict: dict[str, list[torch.Tensor]] = defaultdict(list)
        self.layer_output_dict: dict[str, list[torch.Tensor]] = defaultdict(list)

    def _get_parameter_hook(self, name: str) -> Callable[[nn.Module, torch.Tensor, torch.Tensor], None]:
        def hook(network: nn.Module, input: torch.Tensor, output: torch.Tensor) -> None:
            output_data = output.cpu().detach()
            # output data is same for every batch
            self.param_dict[name] = output_data

        return hook

    def _get_layer_hook(self, name: str) -> Callable[[nn.Module, torch.Tensor, torch.Tensor], None]:
        def hook(network: nn.Module, input: torch.Tensor, output: torch.Tensor) -> None:
            input_data = input[0].cpu().detach()
            output_data = output.cpu().detach()
            # create list of input/output data for each batch
            self.layer_input_dict[name].append(input_data)
            self.layer_output_dict[name].append(output_data)

        return hook

    def _get_bn_hook(self, name: str) -> Callable[[nn.Module, torch.Tensor, torch.Tensor], None]:
        def hook(network: nn.Module, input: torch.Tensor, output: torch.Tensor) -> None:
            assert isinstance(network, nn.BatchNorm2d)
            assert network.running_mean is not None
            assert network.running_var is not None
            weight = network.weight.cpu().detach()
            bias = network.bias.cpu().detach()
            running_mean = network.running_mean.cpu().detach()
            running_var = network.running_var.cpu().detach()
            self.param_dict[f"{name}.weight"] = weight
            self.param_dict[f"{name}.bias"] = bias
            self.param_dict[f"{name}.running_mean"] = running_mean
            self.param_dict[f"{name}.running_var"] = running_var

        return hook

    def _add_hooks(self, model: nn.Module) -> list[RemovableHandle]:
        module_to_hook: dict[
            Type[nn.Module], Callable[[str], Callable[[nn.Module, torch.Tensor, torch.Tensor], None]]
        ] = {
            # Quantized weight
            BinaryMeanScaling: self._get_parameter_hook,
            BinaryChannelWiseMeanScaling: self._get_parameter_hook,
            BinaryPower2Scaling: self._get_parameter_hook,
            BinaryLearningParameterScaling: self._get_parameter_hook,
            LearnedStepSizeBinaryWeightScaling: self._get_parameter_hook,
            IntervalEWGSBinaryWeightScaling: self._get_parameter_hook,
            BinaryChannelWiseMeanScaling_exp: self._get_parameter_hook,
            # Activation
            HalfWaveGaussianQuantization: self._get_layer_hook,
            LearnedStepSizeQuantization: self._get_layer_hook,
            BinaryActivation: self._get_layer_hook,
            IntervalEWGSQuantization: self._get_layer_hook,
            # FIXME: Make Weight quantizer support for IQ. IQ is now assume to be activation quantizer only.
            IntegerQuantizer: self._get_layer_hook,
            # BatchNorm
            nn.BatchNorm2d: self._get_bn_hook,
        }

        hooks = []
        for name, module in model.named_modules(remove_duplicate=False):
            for module_class, get_hook in module_to_hook.items():
                if isinstance(module, module_class):
                    hooks.append(module.register_forward_hook(get_hook(name)))
        return hooks

    def _remove_hooks(self, hooks: list[RemovableHandle]) -> None:
        for hook in hooks:
            hook.remove()

    def _plot_and_save_histogram(
        self, data: torch.Tensor, title: str, bins: int, output_dir: Path, filename: str
    ) -> None:
        xmin, xmax = torch.min(data).numpy(), torch.max(data).numpy()
        annotation_text = "min={:.3f}\nmax={:.3f}".format(xmin, xmax)
        fig = plt.figure()
        ax = fig.add_subplot(1, 1, 1)
        ax.set_title(title)
        ax.hist(torch.flatten(data).numpy(), bins=bins)
        plt.text(
            0.95,
            0.95,
            annotation_text,
            ha="right",
            va="top",
            transform=ax.transAxes,
            bbox=dict(facecolor="none", edgecolor="black", boxstyle="round"),
        )
        fig.savefig(str(output_dir / f"{filename}.png"))
        plt.close()

    def _plot_parameter_histogram(self, output_dir: Path, bins: int) -> None:
        for name in self.param_dict:
            self._plot_and_save_histogram(self.param_dict[name], name, bins, output_dir, name)

    def _plot_layer_input_histogram(self, output_dir: Path, bins: int) -> None:
        for name in self.layer_input_dict:
            self._plot_and_save_histogram(
                torch.cat([torch.flatten(i) for i in self.layer_input_dict[name]]),
                f"{name} input",
                bins,
                output_dir,
                f"{name}_input",
            )

    def _plot_layer_output_histogram(self, output_dir: Path, bins: int) -> None:
        for name in self.layer_output_dict:
            self._plot_and_save_histogram(
                torch.cat([torch.flatten(i) for i in self.layer_output_dict[name]]),
                f"{name} output",
                bins,
                output_dir,
                f"{name}_output",
            )

    def _plot_float_weights_histogram(self, model: nn.Module, output_dir: Path, bins: int) -> None:
        for name, params in model.named_parameters():
            if "conv" not in name:
                continue
            self._plot_and_save_histogram(params.cpu().detach(), f"{name} float", bins, output_dir, f"{name}_float")

    def plot_histogram(
        self,
        trainer: pl.Trainer,
        model: nn.Module,
        dataloaders: DataLoader[tuple[torch.Tensor, torch.Tensor]],
        path: str | Path = Path("./hist"),
        bins: int = 30,
    ) -> None:
        """Save histogram of quantized weights, activation inputs/outputs

        Args:
            trainer (pl.Trainer): Trainer.
            model (torch.nn.Module): Model.
            dataloaders (torch.utils.data.DataLoader): Dataloader of validation set.
            path (Path, optional): Output directory for histograms. Defaults to ``Path("./hist")`` which is ``$PWD/hist``.
            bins (int, optional): The number of bins of histograms. Defaults to 30.
        """  # NOQA: E501
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        _logger.info(f"storing histogram plots to the directory {path.resolve()}")

        model.cpu()
        model.eval()

        self._clear_intermediate_data()
        hooks = self._add_hooks(model)
        if self.accumulate_layer_data:
            trainer.validate(model=model, dataloaders=dataloaders)
        else:
            with torch.no_grad():
                images, _ = next(iter(dataloaders))
                model(images)
        self._remove_hooks(hooks)

        # Plot quantized weights
        self._plot_parameter_histogram(path, bins)

        # Plot float weights
        self._plot_float_weights_histogram(model, path, bins)

        # Plot layer inputs/outputs
        self._plot_layer_input_histogram(path, bins)
        self._plot_layer_output_histogram(path, bins)

        # Upload histgram images to the Neptune
        neptune_logger = get_neptune_logger(trainer)
        if neptune_logger is not None:
            for image_path in path.iterdir():
                path_str = str(image_path)
                neptune_logger.experiment[path_str].upload(path_str)

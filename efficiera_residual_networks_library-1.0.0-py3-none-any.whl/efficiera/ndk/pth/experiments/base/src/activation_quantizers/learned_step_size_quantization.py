from __future__ import annotations

from collections.abc import Callable
from logging import getLogger
import math
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.round_half_up import round_half_up

_logger = getLogger(__name__)


class _LearnedStepSizeQuantizationFunctionWithBeta(torch.autograd.Function):
    """Learned step size quantizer (LSQ) (Linear mid tread half quantizer V2). (torch.autograd.Function)
    This quantization creates a learned step size quantizer.

    LSQ obtain maximum value for quantization function by learning.
    LSQ learns the step size of the weight and activation quantizers (each layer has a different step size).
    By doing this, it can reduce the accuracy gap between quantized and float precision models.

    This quantization method is Learned step size quantizaztion (LSQ) [1]_ activation quantization variant,
    the difference from LSQ is obtain an initial value of `max value` for quantize function from HWGQ.

    `op_type` is ``LinearMidTreadHalfV2``.

    Reference:
        .. [1] `LEARNED STEP SIZE QUANTIZATION <https://arxiv.org/abs/1902.08153>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(
        g: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        beta1: float | list[float],
        beta2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
    ) -> Any:
        min_val = g.constant(min_val, [0], "int")
        max_val = g.constant(max_val, [0], "int")

        if disable_post_scale:
            scale2 = g.constant(1.0, [1], "float")
            beta2 = g.constant(0.0, [1], "float")

        return g.op("lm::LinearMidTreadHalfV2", x, min_val, max_val, scale1, scale2, beta1, beta2)

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        beta1: float | list[float],
        beta2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
    ) -> torch.Tensor:
        r"""Forward.
        .. math::
            \mathbf{h} & = (\mathbf{x} + \mathbf{\beta_1}) * \mathbf{\scale_1} \\
            \mathbf{h} & = \text{round}\big(\text{clip}\big(\mathbf{h}, min\_value, max\_value\big)\big) \\
            \mathbf{h} & = \mathbf{h} \times (\mathbf{\scale_2} + \mathbf{\beta_2})

        Args:
            x: input tensor
            min_val (int): minimum clipping value
            max_val (int): maximum clipping value
            scale1 (float | list[float]): pre quantized scale factor. For vector of list[float], size = channel size
            scale2 (float | list[float]): post quantized scale factor. For vector of list[float], size = channel size
            beta1 (float | list[float]): pre quantized shift factor. For vector of list[float], size = channel size
            beta2 (float | list[float]): post quantized shift factor. For vector of list[float], size = channel size
            count_features (Callable[[torch.Tensor], int]): function return number of features in a layer.
        Returns:
            torch.Tensor: The output tensor from quantized activation function.
        """  # NOQA: E501
        ctx.save_for_backward(x, scale1, scale2, beta1, beta2)
        ctx.other = min_val, max_val, count_features, disable_post_scale

        h = torch.clamp((x + beta1) * scale1, min_val, max_val)
        h = round_half_up(h)

        if disable_post_scale:
            return h

        h = h * scale2 + beta2
        return h

    @staticmethod
    def backward(
        ctx: Any, grad_output: torch.Tensor
    ) -> tuple[torch.Tensor, None, None, None, torch.Tensor, None, None, None, None]:
        x, scale1, scale2, beta1, beta2 = ctx.saved_tensors
        min_val, max_val, count_features, disable_post_scale = ctx.other

        x_beta_scale = (x + beta1) * scale1

        grad_input = grad_output.clone()

        if disable_post_scale:
            grad_input = grad_input * scale1

        grad_input = torch.where(
            (x_beta_scale >= min_val) & (x_beta_scale <= max_val),
            grad_input,
            torch.tensor(0.0, dtype=grad_input.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )

        if disable_post_scale:
            grad_scale2 = -(x_beta_scale * scale1)
            grad_scale2 = torch.where(
                (x_beta_scale >= min_val) & (x_beta_scale <= max_val),
                grad_scale2,
                torch.tensor(0.0, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
            )
        else:
            # Calculate mid area
            grad_scale2 = -x_beta_scale + round_half_up(x_beta_scale)
            # Replace value on negative and positive area
            grad_scale2 = torch.where(
                x_beta_scale >= min_val,
                grad_scale2,
                torch.tensor(min_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
            )
            grad_scale2 = torch.where(
                x_beta_scale <= max_val,
                grad_scale2,
                torch.tensor(max_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
            )

        grad_scale_factor = grad_output.new_tensor(1.0 / math.sqrt(max_val * count_features(x)))
        grad_scale2 = (grad_scale2 * grad_output).sum().unsqueeze(dim=0) * grad_scale_factor

        # Using grad_scale2 instead because this is more efficient and also more numerically stable. (#5605)
        return grad_input, None, None, None, grad_scale2, None, None, None, None


class _LearnedStepSizeQuantizationFunctionWithBetaAndEWGS(torch.autograd.Function):
    """Learned step size quantizer function with EWGS. (torch.autograd.Function)
    The difference from _LearnedStepSizeQuantizationFunctionWithBeta is only an EWGS [1]_ gradient approximation in backward function.
    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(
        g: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        beta1: float | list[float],
        beta2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
        delta: float,
    ) -> Any:
        return _LearnedStepSizeQuantizationFunctionWithBeta.symbolic(
            g, x, min_val, max_val, scale1, scale2, beta1, beta2, count_features, disable_post_scale
        )

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        beta1: float | list[float],
        beta2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
        delta: float,
    ) -> torch.Tensor:
        q = _LearnedStepSizeQuantizationFunctionWithBeta.forward(
            ctx, x, min_val, max_val, scale1, scale2, beta1, beta2, count_features, disable_post_scale
        )
        ctx.ewgs = x - q, delta
        return q

    @staticmethod
    def backward(
        ctx: Any, grad_output: torch.Tensor
    ) -> tuple[torch.Tensor, None, None, None, torch.Tensor, None, None, None, None, None]:
        q_err, delta = ctx.ewgs
        grad_input, _, _, _, grad_scale2, *_ = _LearnedStepSizeQuantizationFunctionWithBeta.backward(ctx, grad_output)
        scaled = grad_input * (1 + delta * torch.sign(grad_input) * q_err)
        return (
            scaled,
            None,
            None,
            None,
            grad_scale2,
            None,
            None,
            None,
            None,
            None,
        )


class _LearnedStepSizeQuantizationFunction(torch.autograd.Function):
    """Fast Learned step size quantizer (FastLSQ) function (Linear mid tread half quantizer V2). (torch.autograd.Function)
    This quantization creates an accelerated learned step size quantizer which drop beta, which always equals to 0, from the calculation.

    LSQ obtain maximum value for quantization function by learning.
    LSQ learns the step size of the weight and activation quantizers (each layer has a different step size).
    By doing this, it can reduce the accuracy gap between quantized and float precision models.

    This quantization method is Learned step size quantizaztion (LSQ) [1]_ activation quantization variant,
    the difference from LSQ is obtain an initial value of `max value` for quantize function from HWGQ.

    `op_type` is ``LinearMidTreadHalfV2``.

    Reference:
        .. [1] `LEARNED STEP SIZE QUANTIZATION <https://arxiv.org/abs/1902.08153>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(
        g: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
    ) -> Any:
        min_val = g.constant(min_val, [0], "int")
        max_val = g.constant(max_val, [0], "int")
        beta1 = g.constant(0.0, [1], "float")
        beta2 = g.constant(0.0, [1], "float")

        if disable_post_scale:
            scale2 = g.constant(1.0, [1], "float")

        return g.op("lm::LinearMidTreadHalfV2", x, min_val, max_val, scale1, scale2, beta1, beta2)

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
    ) -> torch.Tensor:
        r"""Forward.
        .. math::
            \mathbf{h} & = (\mathbf{x} + \mathbf{\beta_1}) * \mathbf{\scale_1} \\
            \mathbf{h} & = \text{round}\big(\text{clip}\big(\mathbf{h}, min\_value, max\_value\big)\big) \\
            \mathbf{y} & = \mathbf{h} \times (\mathbf{\scale_2} + \mathbf{\beta_2})

        Args:
            x: input tensor
            y :output tensor
            min_val (int): minimum clipping value
            max_val (int): maximum clipping value
            scale1 (float | list[float]): pre quantized scale factor. For vector of list[float], size = channel size
            scale2 (float | list[float]): post quantized scale factor. For vector of list[float], size = channel size
            count_features (Callable[[torch.Tensor], int]): function return number of features in a layer.
        Returns:
            torch.Tensor: The output tensor from quantized activation function.
        """  # NOQA: E501
        ctx.save_for_backward(x, scale1, scale2)
        ctx.other = min_val, max_val, count_features, disable_post_scale

        h = torch.clamp(x * scale1, min_val, max_val)
        h = round_half_up(h)

        if disable_post_scale:
            return h

        h = h * scale2
        return h

    @staticmethod
    def backward(
        ctx: Any, grad_output: torch.Tensor
    ) -> tuple[torch.Tensor, None, None, None, torch.Tensor, None, None]:
        x, scale1, scale2 = ctx.saved_tensors
        min_val, max_val, count_features, disable_post_scale = ctx.other

        x_scale = x * scale1

        grad_input = grad_output.clone()

        if disable_post_scale:
            grad_input = grad_input * scale1

        grad_input = torch.where(
            (x_scale >= min_val) & (x_scale <= max_val),
            grad_input,
            torch.tensor(0.0, dtype=grad_input.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )

        if disable_post_scale:
            grad_scale2 = -(x_scale * scale1)
            grad_scale2 = torch.where(
                (x_scale >= min_val) & (x_scale <= max_val),
                grad_scale2,
                torch.tensor(0.0, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
            )
        else:
            # Calculate mid area
            grad_scale2 = -x_scale + round_half_up(x_scale)
            # Replace value on negative and positive area
            grad_scale2 = torch.where(
                x_scale >= min_val,
                grad_scale2,
                torch.tensor(min_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
            )
            grad_scale2 = torch.where(
                x_scale <= max_val,
                grad_scale2,
                torch.tensor(max_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
            )

        grad_scale_factor = grad_output.new_tensor(1.0 / math.sqrt(max_val * count_features(x)))
        grad_scale2 = (grad_scale2 * grad_output).sum().unsqueeze(dim=0) * grad_scale_factor

        # Using grad_scale2 instead because this is more efficient and also more numerically stable. (#5605)
        return grad_input, None, None, None, grad_scale2, None, None


class _LearnedStepSizeQuantizationFunctionWithEWGS(torch.autograd.Function):
    """Fast Learned step size quantizer function with EWGS. (torch.autograd.Function)
    The difference from _LearnedStepSizeQuantizationFunction is only an EWGS [1]_ gradient approximation in backward function.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(
        g: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
        delta: float,
    ) -> Any:
        return _LearnedStepSizeQuantizationFunction.symbolic(
            g, x, min_val, max_val, scale1, scale2, count_features, disable_post_scale
        )

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        disable_post_scale: bool,
        delta: float,
    ) -> torch.Tensor:
        q = _LearnedStepSizeQuantizationFunction.forward(
            ctx, x, min_val, max_val, scale1, scale2, count_features, disable_post_scale
        )
        ctx.ewgs = x - q, delta
        return q

    @staticmethod
    def backward(
        ctx: Any, grad_output: torch.Tensor
    ) -> tuple[torch.Tensor, None, None, None, torch.Tensor, None, None, None]:
        q_err, delta = ctx.ewgs
        grad_input, _, _, _, grad_scale2, *_ = _LearnedStepSizeQuantizationFunction.backward(ctx, grad_output)
        scaled = grad_input * (1 + delta * torch.sign(grad_input) * q_err)
        return scaled, None, None, None, grad_scale2, None, None, None


class LearnedStepSizeQuantization(nn.Module):
    r"""Learned step size quantizer (LSQ) (Linear mid tread half quantizer V2).
    This quantization creates a learned step size quantizer.

    Args:
        x (torch.Tensor): Input tensor in NCHW format to be quantized in this activation.
        num_ch (int, optional): Currently unused, but reserved parameter for future updates on channel-wise LSQ. Defaults to ``None``
        k (int, optional): bit-width of the precision of activation function. Defaults to ``2``
        symmetric (bool, optional): If ``True``, set min_value = -max_value. Defaults to ``False``
        max_value (int, optional): Upper bound of value to clip. Defaults to ``None`` -- self.max_value = 2^k-1
        features (str, optional): Determines how to compute :math:`N_F` in the scaling factor for the step size gradient.
            Allowed values are "C", "CHW", and "NCHW". Defaults to ``"NCHW"``
        ignored_beta (bool, optional): If ``True``, accelerate LSQ by dropped beta from calculation. Defaults to ``True``
        disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation

    Returns:
        torch.Tensor: The output tensor from quantized activation function.

    Note:
        In the LSQ paper, gradient scale :math:`g = \frac{1.0}{\sqrt{N_F * Q_P}}` where :math:`Q_P` is max_value (3 by default).
        The `features` option determines how to compute :math:`N_F`.

        * `features="C"`: :math:`N_F` is the number of channels in the activation.
        * `features="CHW"`: :math:`N_F` is the size of activations in the layer.
        * `features="NCHW"`: :math:`N_F` is the total elements in the layer in the current batch. N is the batch size.

        The NDK scaling is similar to "CHW".
        Currently, "NCHW" is a default setting because it seems to perform slightly better than "C".
        Depending on the models, "CHW" and "C" may be worth trying if the gradients for scales look too small.
    """  # NOQA: E501, W605

    def __init__(
        self,
        num_ch: int | None = None,
        k: int = 2,
        symmetric: bool = False,
        max_value: int | None = None,
        features: str = "NCHW",
        ignored_beta: bool = True,
        disable_post_scale: bool = False,
        delta: float = 0,
    ):
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        self.k = k
        self.max_value = max_value if max_value is not None else int(2**self.k - 1)
        self.min_value = -self.max_value if symmetric else 0
        self.scale = nn.Parameter(torch.Tensor(1).fill_(0.0))
        self.beta = nn.Parameter(torch.Tensor(1).fill_(0.0), requires_grad=False) if not ignored_beta else None

        get_count_features = {
            "C": lambda x: x.size(1),
            "CHW": lambda x: x[0].numel(),
            "NCHW": lambda x: x.numel(),
        }
        assert features in ("C", "CHW", "NCHW")
        self.count_features = get_count_features[features]
        self.disable_post_scale = disable_post_scale
        self.delta = delta

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        scale1 = 1.0 / (1.85 / self.max_value + self.scale)
        scale2 = 1.85 / self.max_value + self.scale
        if self.beta is None:
            if self.delta == 0:  # Switch to STE
                return _LearnedStepSizeQuantizationFunction.apply(
                    x, self.min_value, self.max_value, scale1, scale2, self.count_features, self.disable_post_scale
                )
            return _LearnedStepSizeQuantizationFunctionWithEWGS.apply(
                x,
                self.min_value,
                self.max_value,
                scale1,
                scale2,
                self.count_features,
                self.disable_post_scale,
                self.delta,
            )
        beta1 = self.beta
        beta2 = -1.0 * self.beta
        if self.delta == 0:  # Switch to STE
            return _LearnedStepSizeQuantizationFunctionWithBeta.apply(
                x,
                self.min_value,
                self.max_value,
                scale1,
                scale2,
                beta1,
                beta2,
                self.count_features,
                self.disable_post_scale,
            )
        return _LearnedStepSizeQuantizationFunctionWithBetaAndEWGS.apply(
            x,
            self.min_value,
            self.max_value,
            scale1,
            scale2,
            beta1,
            beta2,
            self.count_features,
            self.disable_post_scale,
            self.delta,
        )

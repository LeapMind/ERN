from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F

from efficiera.ndk.pth.experiments.base.src._quantizers.binarize_ste import Binalize_STE

_logger = getLogger(__name__)


class _ReLUSTE(torch.autograd.Function):
    """Straight-through Estimator(STE) for ReLU. (torch.autograd.Function)

    `op_type` is ``ReLUSTEFunction``.
    """  # NOQA: E501

    @staticmethod
    def symbolic(g: Any, x: torch.Tensor) -> Any:
        return g.op("lm::ReLUSTEFunction", x)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \mathbf{Y} & = \text{ReLU}\big(\mathbf{x}\big) &\\
            \end{align}

        Args:
            x (torch.Tensor): input tensor.

        Returns:
            torch.tensor: output tensor by ReLU.
        """
        return F.relu(x)

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> torch.Tensor:
        """Calculate the gradient using STE"""
        return grad_output


class _ClippedSlopePReLU(nn.Module):
    """
    A modified PReLU function that clips the negative slope value to zero before applying PReLU.

    Args:
        num_params (int): Number of negative slope parameters.
        init (float, optional): Initial value of negative slope. Defaults to ``0.25``.
    """

    def __init__(self, num_params: int, init: float = 0.25) -> None:
        super().__init__()
        self.slope = nn.Parameter(torch.Tensor(num_params).fill_(init))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # This is a hack to clip the negative slope to zero.
        slope = _ReLUSTE.apply(self.slope)
        return F.prelu(x, slope)


class _BiNealNetHtanh(torch.autograd.Function):
    r"""Hard hyperbolic tangent function for BiNealNet. (torch.autograd.Function)
    This function creates a variant of hard hyperbolic tangent that is used in BiNealNet [1]_.
    The difference from ``torch.nn.Hardtanh`` is only an gradient approximation in backward function.
    In the back propagation, the gradient is calculated using the following equation:
    .. math::
        \begin{align}
            F(a_r) = \left \{ \begin{array}{ll}-1 & (a_r \lt -1) \\\\ 2a_r + {a_r}^2 & (-1 \leq a_r \lt 0) \\\\ 2a_r - {a_r}^2 & (0 \leq a_r \lt 1) \\\\ 1 & (\text{otherwise}) \end{array} \right
        \end{align}
    This functional form was proposed in Bi-RealNet [2]_.
    In Bi-RealNet, the above equation was proposed to approximate the back propagation of the sign function.
    In BiNealNet, instead of calculating the gradient of the sign function with STE, and calculating the back propagation of Htanh with the above equation,
    and combining STE sign with this variant Htanh, BiNealNet is supposed to perform the same calculation as Bi-RealNet.
    Combining this variant Htanh function with the sign function whose gradient is calculated by STE like below:
    .. math::
        \begin{align}
            \text{Sign}\big(\text{Htanh} \big(x \big) \big) &\\
        \end{align}
    The threshold function of BiNealNet and the those of Bi-RealNet are considered to perform the same operation both forward and backward path.
    `op_type` is ``BiNealNetHtanh``.
    Reference:
        .. [1] `Binary Neural Networks as a general-propose compute paradigm for on-device computer vision
        <https://arxiv.org/abs/2202.03716>`_
        .. [2] `Bi-Real Net: Enhancing the Performance of 1-bit CNNs With Improved Representational Capability and Advanced Training Algorithm
        <https://arxiv.org/abs/1808.00278>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(g: Any, x: torch.Tensor) -> Any:
        return g.op("lm::BiNealNetHtanh", x)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor) -> torch.Tensor:
        r"""Forward.
        Args:
            x (torch.Tensor): input feature map of (B, C, H, W) of shape.
        Returns:
            torch.tensor: Htanh output.
        """
        ctx.save_for_backward(x)
        return F.hardtanh(x)

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> torch.Tensor:
        r"""Backward.
        .. math::
            \begin{align}
                F(a_r) = \left \{ \beg}{ll}-1 & (a_r \lt -1) \\\\ 2a_r + {a_r}^2 & (-1 \leq a_r \lt 0) \\\\ 2a_r - {a_r}^2 & (0 \leq a_r \lt 1) \\\\ 1 & (\text{otherwise}) \end{array} \right &\\
            \end{align}
        Args:
            grad_output (torch.Tensor): gradient from previous layer.
        Returns:
            torch.tensor: gradient of input tensor.
        """  # NOQA: E501
        (x,) = ctx.saved_tensors
        return torch.where(x > 0, 2 - 2 * x, 2 + 2 * x) * (x.abs() <= 1).to(x.dtype) * grad_output


class BinaryActivation(nn.Module):
    """Binary activation quantizer of BiNealNet [1]_.
    Args:
        out_channels (int): Number of output channels.
        prelu_init_negative_slope (float): Initial negative slope value of ClippedPReLU. Defaults to ``0.25`` that is the same as ``torch.nn.PReLU``.
        disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``.

    Reference:
        .. [1] `Binary Neural Networks as a general-propose compute paradigm for on-device computer vision
        <https://arxiv.org/abs/2202.03716>`_
    """  # NOQA: E501

    def __init__(
        self,
        out_channels: int,
        prelu_init_negative_slope: float = 0.25,
        disable_post_scale: bool = False,
    ) -> None:
        super().__init__()
        # These parameters are channel-wise parameters
        self.bineal_tau = nn.Parameter(torch.ones(1, out_channels, 1, 1))
        self.bineal_bias0 = nn.Parameter(torch.zeros(1, out_channels, 1, 1))
        self.bineal_bias1 = nn.Parameter(torch.zeros(1, out_channels, 1, 1))

        self.bineal_prelu = _ClippedSlopePReLU(out_channels, prelu_init_negative_slope)

        self.disable_post_scale = disable_post_scale
        if disable_post_scale:
            return
        # The post scaler kappa is a scalar parameter
        self.bineal_kappa = nn.Parameter(torch.ones(1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.bineal_prelu(self.bineal_tau * x + self.bineal_bias0)
        x = _BiNealNetHtanh.apply(x + self.bineal_bias1)
        if self.disable_post_scale:
            return Binalize_STE.apply(x)
        return self.bineal_kappa * Binalize_STE.apply(x)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(disable_post_scale={self.disable_post_scale})"

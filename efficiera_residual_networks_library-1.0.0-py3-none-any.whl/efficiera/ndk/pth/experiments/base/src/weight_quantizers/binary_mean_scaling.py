from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.binarize import binarize

_logger = getLogger(__name__)


class _BinaryMeanScalingFunction(torch.autograd.Function):
    """Binary mean scaling quantizer. (torch.autograd.Function)
    This quantization creates a binary mean scaling quantizer.

    This method is DoReFa-Net [2]_ weight quantization.

    `op_type` is ``BinaryMeanScalingQuantizer``.

    Reference:
        .. [2] `DoReFa-Net: Training Low Bitwidth Convolutional Neural Networks with Low Bitwidth Gradients
        <https://arxiv.org/abs/1606.06160>`_
    """

    @staticmethod
    def symbolic(g: Any, w: torch.Tensor) -> Any:
        return g.op("lm::BinaryMeanScalingQuantizer", w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \bar{x} & = \frac{1}{N}||\mathbf{X}||_{\ell1}
                & \text{$\bar{x}$ is a scalar} \\
                & & \text{$N$ is number of elements in all channels of $\mathbf{X}$}\\
                \mathbf{Y} & = \text{sign}\big(\mathbf{X}\big) \cdot \bar{x} &\\
            \end{align}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        scaling_factor = w.abs().mean()
        return binarize(w) * scaling_factor

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> torch.Tensor:
        return grad_output


class BinaryMeanScaling(nn.Module):
    """Binary mean scaling quantizer.
    This quantization creates a binary mean scaling quantizer.

    This method is `DoReFa-Net`_ weight quantization.

    .. _DoReFa-Net:
        https://arxiv.org/abs/1606.06160
    """

    def __init__(self) -> None:
        super().__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _BinaryMeanScalingFunction.apply(x)

    def scale(self, x: torch.Tensor) -> torch.Tensor:
        return x.abs().mean()

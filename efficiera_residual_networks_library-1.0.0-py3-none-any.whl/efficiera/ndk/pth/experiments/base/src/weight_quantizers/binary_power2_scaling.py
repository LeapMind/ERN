from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.binarize import binarize

_logger = getLogger(__name__)


class _BinaryPower2ScalingFunction(torch.autograd.Function):
    """Binary power2 scaling quantizer. (torch.autograd.Function)
    This quantization is a weight quantizer, that addressed floating point scaling factor, e.g.,
    Binary channel wise mean scaling quantizer. If this scaling factor is represented by a power of 2,
    then it does not need to use floating-point number operations, thus it can run more efficient while
    accuracy is almost unchanged.

    `op_type` is ``BinaryPower2ScalingQuantizer``.
    """

    @staticmethod
    def symbolic(g: Any, w: torch.Tensor, p: int) -> Any:
        p = g.constant(p, [0], "int")
        return g.op("lm::BinaryPower2ScalingQuantizer", w, p)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, p: int) -> torch.Tensor:
        r"""Forward.

        .. math::
            \mathbf{Y} & = \text{sign}\big(\mathbf{W}\big) \times \frac{1}{p}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
            p (int): Scaling factor, must be a power of 2. Defaults to ``32``
        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        return binarize(w) * (1.0 / p)

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None]:
        return grad_output, None


class BinaryPower2Scaling(nn.Module):
    """Binary power2 scaling quantizer.
    This quantization is a weight quantizer, that addressed floating point scaling factor, e.g.,
    Binary channel wise mean scaling quantizer. If this scaling factor is represented by a power of 2,
    then it does not need to use floating-point number operations, thus it can run more efficient while
    accuracy is almost unchanged.

    Args:
        p (int, optional): Scaling factor, must be a power of 2. Defaults to ``32``
    """

    def __init__(self, p: int = 32) -> None:
        super().__init__()
        assert p & (p - 1) == 0
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _BinaryPower2ScalingFunction.apply(x, self.p)

    def scale(self, x: torch.Tensor) -> torch.Tensor:
        return torch.tensor(1 / self.p, device=x.device, dtype=x.dtype)

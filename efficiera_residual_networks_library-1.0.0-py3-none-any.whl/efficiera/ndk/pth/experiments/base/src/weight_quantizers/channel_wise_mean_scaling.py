from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.weight_quantizers._weight_quantize import weight_quantize

_logger = getLogger(__name__)


class _ChannelWiseMeanScalingFunction(torch.autograd.Function):
    """Channel wise mean scaling quantizer. (torch.autograd.Function)
    This quantization creates a channel wise mean scaling quantizer.

    This method quantizes channel-wise k-bit representation of the weight, and multiplies channel-wise mean of absolute
    value of the weight.

    This method is varient of XNOR-Net [1]_ weight quantization, the difference from XNOR-Net [1]_ is
    backward function.

    Reference:
        .. [1] `XNOR-Net: ImageNet Classification Using Binary Convolutional Neural Networks
        <https://arxiv.org/abs/1603.05279>`_
    """

    @staticmethod
    def symbolic(g: Any, w: torch.Tensor, k: int) -> Any:
        k = g.constant(k, [0], "int")
        return g.op("lm::ChannelWiseMeanScalingQuantizer", w, k)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, k: int) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \bar{\mathbf{w}} & = \frac{1}{n}||\mathbf{W}||_{\ell1}
                & \text{$\bar{\mathbf{w}}$ is a $c$-channels vector} \\
                & & \text{$n$ is number of elements in each channel of $\mathbf{W}$} \\\\
                quantize_{k}\left(\mathbf{W}\right) & = \frac{1}{2^k-1}round\left(\left(2^k-1\right)\mathbf{W}\right)\\
                \mathbf{Y} & = \left(2~quantize_{k}\left(\frac{tanh(\mathbf{W}}{2~max(\left|tanh(\mathbf{W})\right|)}+\frac{1}{2}\right)-1\right) \cdot \bar{\mathbf{w}} &\\
            \end{align}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
            k (int): bit-width of the precision of weight quantizer.
        Returns:
            torch.Tensor: The quantized weight.
        """  # NOQA: E501
        wq = weight_quantize(w, k, dim=(1, 2, 3))
        scaling_factor = w.abs().mean(dim=(1, 2, 3), keepdim=True)
        return wq * scaling_factor

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> tuple[torch.Tensor, None]:
        return grad_output, None


class ChannelWiseMeanScaling(nn.Module):
    """Channel wise mean scaling quantizer.
    This quantization creates a channel wise mean scaling quantizer.

    This method is varient of `XNOR-Net`_ weight quantization, the difference from `XNOR-Net`_ is
    backward function.

    .. _XNOR-Net:
        https://arxiv.org/abs/1603.05279

    Args:
        k (int): bit-width of the precision of weight quantizer.
    """

    def __init__(self, k: int) -> None:
        super().__init__()
        self.k = k

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _ChannelWiseMeanScalingFunction.apply(x, self.k)

from __future__ import annotations

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.round_half_up import round_half_up


def weight_quantize(w: torch.Tensor, k: int, dim: tuple[int, ...]) -> torch.Tensor:
    r"""Quantize w to 2**k-1 divisions between -1.0 and +1.0.
    If k = 1, then [-1.0, +1.0].
    If k = 2, then [-1.0, -1/3, +1/3, +1.0].

    .. math::
        \begin{align}
            quantize_{k}\left(\mathbf{W}\right) & = \frac{1}{2^k-1}round\left(\left(2^k-1\right)\mathbf{W}\right) \\
            \mathbf{Y} & = 2~quantize_{k}\left(\frac{tanh(\mathbf{W}}{2~max(\left|tanh(\mathbf{W})\right|)}+\frac{1}{2}\right)-1 \\
        \end{align}

    Reference:
        .. [2] `DoReFa-Net: Training Low Bitwidth Convolutional Neural Networks with Low Bitwidth Gradients
        <https://arxiv.org/abs/1606.06160>`_
    Args:
        w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        k (int): bit-width of the precision of weight quantizer.
        dim (tuple[int, ...]): Specify a dimension to be quantized. In particular, specify (1, 2, 3) for channel-size,
            (0, 1, 2, 3) for all dimensions together.
    Returns:
        torch.Tensor: The quantized weight.
    """  # NOQA: E501
    tanh_factor = torch.tanh(w)
    wq = tanh_factor / (torch.amax(torch.abs(tanh_factor), dim=dim, keepdim=True) * 2) + 0.5
    # HACK: Forward compatibility Resolve IndexError: Argument passed to at() was not in the map.
    k_parameter = nn.Parameter(torch.Tensor(1).fill_(k), requires_grad=False)
    factor = 2**k_parameter - 1
    wq = round_half_up(wq * factor) / factor
    wq = wq * 2 - 1
    return wq

from __future__ import annotations

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.zero_one_binarize_ste import ZeroOneBinarizeSTE


class GeneralDomainScaling(nn.Module):
    r"""GeneralDomainScaling quantizer which returns learnable binary weight.
    This quantization method is adopted in `Binary domain generalization for sparsifying binary neural networks`_

    Args:
        alpha (float, optional): Weight is transformed to alpha if it is smaller than 0.
                                    Note that alpha is learnable parameter.
                                    Defaults to ``0``.
        beta (float, optional): Weight is transformed to beta if it is larger than or equal to 0.
                                    Note that beta is learnable parameter and its value can be changed.
                                    Defaults to ``1``.

    Returns:
        torch.Tensor: A new tensor with value alpha or beta.
    .. _Binary domain generalization for sparsifying binary neural networks:
        https://arxiv.org/pdf/2306.13515.pdf
    """

    def __init__(self, alpha: float = 0.0, beta: float = 1.0) -> None:
        super().__init__()
        self.zero_one_binarizer = ZeroOneBinarizeSTE()
        self.alpha = nn.Parameter(torch.tensor(alpha))
        self.beta = nn.Parameter(torch.tensor(beta))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.zero_one_binarizer(x) * (self.beta - self.alpha) + self.alpha

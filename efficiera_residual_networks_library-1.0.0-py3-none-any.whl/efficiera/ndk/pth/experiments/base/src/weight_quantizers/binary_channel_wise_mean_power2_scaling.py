from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.weight_quantizers._weight_quantize import weight_quantize

_logger = getLogger(__name__)


class _BinaryChannelWiseMeanPower2ScalingFunction(torch.autograd.Function):
    """Binary channel-wise mean power 2 scaling quantizer. (torch.autograd.Function)
    This quantization creates a variant of binary channel wise mean scaling quantizer.
    The scaling factors for each channel (mean of absolute value) are quantized to the nearest power of two instead.
    """

    @staticmethod
    def symbolic(g: Any, w: torch.Tensor) -> Any:
        return g.op("lm::BinaryChannelWisePower2MeanScalingQuantizer", w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \bar{\mathbf{w}} & = \frac{1}{n}||\mathbf{W}||_{\ell1}
                & \text{$\bar{\mathbf{w}}$ is a $c$-channels vector} \\
                & & \text{$n$ is number of elements in each channel of $\mathbf{W}$} \\\\
                \mathbf{SF} & = 2 ^ {round(log_2(\bar{\mathbf{w}}))}\\
                \mathbf{Y} & = \text{sign}\big(\mathbf{W}\big) \times \mathbf{SF} &\\
            \end{align}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        Returns:
            torch.Tensor: The quantized weight.
        """  # NOQA: E501
        wq = weight_quantize(w, 1, dim=(1, 2, 3))
        w_bar = w.abs().mean(dim=(1, 2, 3), keepdim=True)
        scaling_factor = torch.exp2(torch.round(torch.log2(w_bar)))
        return wq * scaling_factor

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> tuple[torch.Tensor, None]:
        return grad_output, None


class BinaryChannelWiseMeanPower2Scaling(nn.Module):
    """Binary channel-wise mean power 2 scaling quantizer. (torch.autograd.Function)
    This quantization creates a variant of binary channel wise mean scaling quantizer.
    The scaling factors for each channel (mean of absolute value) are quantized to the nearest power of two instead.
    """

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _BinaryChannelWiseMeanPower2ScalingFunction.apply(x)

from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.binarize import binarize
from efficiera.ndk.pth.experiments.base.src._quantizers.binarize_ste import Binalize_STE

_logger = getLogger(__name__)


class _ScaledSignFunction(torch.autograd.Function):
    """Scaled sign function for quantizer. (torch.autograd.Function)
    Quantizer that applies an arbitrary scaling factor after applying the sign function.
    The scaling factor lambda can be given any value. (Both learnable and unlearnable.)
    In back propagation, the sign function approximates the gradient using STE

    This method is a varient of BiNealNet [1]_ weight quantization.

    `op_type` is ``ScaledSignFunction``.

    Reference:
        .. [1] `Binary Neural Networks as a general-propose compute paradigm for on-device computer vision
        <https://arxiv.org/abs/2202.03716>`_
    """

    @staticmethod
    def symbolic(g: Any, w: torch.Tensor, lambda_: torch.Tensor) -> Any:
        return g.op("lm::ScaledSignFunction", w, lambda_)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, lambda_: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \mathbf{Y} & = \text{sign}\big(\mathbf{W}\big) \times \lambda &\\
            \end{align}

        Args:
            w (torch.Tensor): The input to be quantized, weight normally.
            lambda_ (torch.Tensor): Scaling factor.

        Returns:
            torch.tensor: The quantized weight.
        """
        ctx.save_for_backward(w, lambda_)
        return binarize(w) * lambda_

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> tuple[torch.Tensor, torch.Tensor]:
        w, lambda_ = ctx.saved_tensors
        return grad_output * lambda_, grad_output * binarize(w)


class BinaryLearningParameterScaling(nn.Module):
    """Binary learning parameter scaling quantizer.
    This quantization creates a binary learining parameter scaling quantizer.

    This method is weight quantizer of BiNealNet [1]_.

    Args:
        in_channels (int): Number of input channels. When ``alph_dim=1``, in_channels is not used
        out_channels (int): Number of output channels.
        kernel_size (int | tuple[int, int]): Size of the convolving kernel.
        alpha_dim (Literal[1, 2, 4], optional): Dimension of parameter alpha. Defaults to ``1``.
        weight (torch.Tensor, optional): Input tensor in NCHW format to be quantized in this quantizer or
                            weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
                            Defaults to ``None``.
        disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``.

    Reference:
        .. [1] `Binary Neural Networks as a general-propose compute paradigm for on-device computer vision
        <https://arxiv.org/abs/2202.03716>`_
    """  # NOQA: E501

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        alpha_dim: int = 1,
        weight: torch.Tensor | None = None,
        disable_post_scale: bool = False,
    ) -> None:
        super().__init__()
        self.alpha_dim = alpha_dim
        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size)
        alpha_handler = {
            1: nn.Parameter(torch.ones(out_channels, 1, 1, 1)),
            2: nn.Parameter(torch.ones(out_channels, in_channels, 1, 1)),
            4: nn.Parameter(torch.ones(out_channels, in_channels, kernel_size[0], kernel_size[1])),
        }
        try:
            self.bineal_alpha = alpha_handler[alpha_dim]
        except KeyError:
            _logger.error(f"alpha_dim must be 1, 2, or 4, but {alpha_dim} is given.")
            raise ValueError(f"alpha_dim must be 1, 2, or 4, but {alpha_dim} is given.")

        self.disable_post_scale = disable_post_scale
        if disable_post_scale:
            return

        if weight is not None:
            self.bineal_lambda = nn.Parameter(weight.abs().mean(dim=(1, 2, 3), keepdim=True).detach().clone())
        else:
            self.bineal_lambda = nn.Parameter(torch.randn(out_channels, 1, 1, 1))

    def forward(self, w: torch.Tensor) -> torch.Tensor:
        w = torch.tanh(self.bineal_alpha * w)
        if self.disable_post_scale:
            return Binalize_STE.apply(w)
        return _ScaledSignFunction.apply(w, self.bineal_lambda)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(alpha_dim={self.alpha_dim}, disable_post_scale={self.disable_post_scale})"

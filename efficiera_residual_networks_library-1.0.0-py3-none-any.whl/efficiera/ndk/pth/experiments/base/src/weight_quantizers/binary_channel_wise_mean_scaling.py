from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src._quantizers.binarize import binarize

_logger = getLogger(__name__)


class _BinaryChannelWiseMeanScalingFunction(torch.autograd.Function):
    """Binary channel wise mean scaling quantizer. (torch.autograd.Function)
    This quantization creates a binary channel wise mean scaling quantizer.

    This method is varient of XNOR-Net [1]_ weight quantization, the difference from XNOR-Net [1]_ is
    backward function.

    `op_type` is ``BinaryChannelWiseMeanScalingQuantizer``.

    Reference:
        .. [1] `XNOR-Net: ImageNet Classification Using Binary Convolutional Neural Networks
        <https://arxiv.org/abs/1603.05279>`_
    """

    @staticmethod
    def symbolic(g: Any, w: torch.Tensor) -> Any:
        return g.op("lm::BinaryChannelWiseMeanScalingQuantizer", w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \bar{\mathbf{w}} & = \frac{1}{n}||\mathbf{W}||_{\ell1}
                & \text{$\bar{\mathbf{w}}$ is a $c$-channels vector} \\
                & & \text{$n$ is number of elements in each channel of $\mathbf{W}$} \\\\
                \mathbf{Y} & = \text{sign}\big(\mathbf{W}\big) \times \bar{\mathbf{w}} &\\
            \end{align}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        scaling_factor = w.abs().mean(dim=(1, 2, 3), keepdim=True)
        return binarize(w) * scaling_factor

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> torch.Tensor:
        return grad_output


class BinaryChannelWiseMeanScaling(nn.Module):
    """Binary channel wise mean scaling quantizer.
    This quantization creates a binary channel wise mean scaling quantizer.

    This method is varient of `XNOR-Net`_ weight quantization, the difference from `XNOR-Net`_ is
    backward function.

    .. _XNOR-Net:
        https://arxiv.org/abs/1603.05279
    """

    def __init__(self) -> None:
        super().__init__()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _BinaryChannelWiseMeanScalingFunction.apply(x)

    def scale(self, x: torch.Tensor) -> torch.Tensor:
        return x.abs().mean(dim=(1, 2, 3))

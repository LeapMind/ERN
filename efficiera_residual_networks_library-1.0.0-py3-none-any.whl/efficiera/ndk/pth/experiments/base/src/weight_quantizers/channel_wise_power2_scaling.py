from __future__ import annotations

from logging import getLogger
from typing import Any

import torch
import torch.nn as nn

from efficiera.ndk.pth.experiments.base.src.weight_quantizers._weight_quantize import weight_quantize

_logger = getLogger(__name__)


class _ChannelWisePower2ScalingFunction(torch.autograd.Function):
    """Channel wise power2 scaling quantizer. (torch.autograd.Function)
    This quantization is a weight quantizer, that addressed floating point scaling factor, e.g.,
    Channel wise mean scaling quantizer. If this scaling factor is represented by a power of 2,
    then it does not need to use floating-point number operations, thus it can run more efficient while
    accuracy is almost unchanged.
    """

    @staticmethod
    def symbolic(g: Any, w: torch.Tensor, k: int, p: int) -> Any:
        k = g.constant(k, [0], "int")
        p = g.constant(p, [0], "int")
        return g.op("lm::ChannelWisePower2ScalingQuantizer", w, k, p)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, k: int, p: int) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                quantize_{k}\left(\mathbf{W}\right) & = \frac{1}{2^k-1}round\left(\left(2^k-1\right)\mathbf{W}\right)\\
                \mathbf{Y} & = \left(2~quantize_{k}\left(\frac{tanh(\mathbf{W}}{2~max(\left|tanh(\mathbf{W})\right|)}+\frac{1}{2}\right)-1\right) \cdot \frac{1}{p} &\\
            \end{align}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
            k (int): bit-width of the precision of weight quantizer.
            p (int): Scaling factor, must be a power of 2.
        Returns:
            torch.Tensor: The quantized weight.
        """  # NOQA: E501
        wq = weight_quantize(w, k, dim=(1, 2, 3))
        scaling_factor = 1 / p
        return wq * scaling_factor

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> tuple[torch.Tensor, None, None]:
        return grad_output, None, None


class ChannelWisePower2Scaling(nn.Module):
    """Channel wise power2 scaling quantizer.
    This quantization is a weight quantizer, that addressed floating point scaling factor, e.g.,
    channel wise mean scaling quantizer. If this scaling factor is represented by a power of 2,
    then it does not need to use floating-point number operations, thus it can run more efficient while
    accuracy is almost unchanged.

    Args:
        k (int): bit-width of the precision of weight quantizer.
        p (int): Scaling factor, must be a power of 2.
    """

    def __init__(self, k: int, p: int) -> None:
        super().__init__()
        self.k = k
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _ChannelWisePower2ScalingFunction.apply(x, self.k, self.p)

from __future__ import annotations

import logging
import os
from pathlib import Path

import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only

from efficiera.ndk.pth.experiments.base.src.utils._get_neptune_logger import get_neptune_logger
from efficiera.ndk.pth.utils import export_onnx_file

_logger = logging.getLogger(__name__)


class ExportOnnx(pl.Callback):
    """A callback to export the model to ONNX.
    If the trainer has a Neptune logger, upload the ONNX file to Neptune.

    Args:
        input_sizes: Input image size it can be a tuple of (h, w) or a list of tuples.
        dest: Output directory for exported files.
        name: Model name, use as prefix for exported files.
    """

    def __init__(
        self,
        input_sizes: list[tuple[int, int]] | tuple[int, int],
        dest: Path,
        name: str,
    ) -> None:
        self._input_sizes = input_sizes
        self._dest = dest
        self._name = name

    @rank_zero_only
    def on_train_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        output_dir = Path(self._dest).absolute()
        os.makedirs(output_dir, exist_ok=True)

        export_onnx_file(
            model=pl_module,
            input_image_size=self._input_sizes,
            path=self._dest,
            model_name=self._name,
        )

        neptune_logger = get_neptune_logger(trainer)
        if neptune_logger:
            neptune_logger.experiment["export"].upload_files(str(output_dir))

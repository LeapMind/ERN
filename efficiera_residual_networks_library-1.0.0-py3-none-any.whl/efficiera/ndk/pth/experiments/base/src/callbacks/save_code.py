from __future__ import annotations

import logging
import os
import shutil
import tempfile

import hydra
import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only

from efficiera.ndk.pth.experiments.base.src.utils._get_neptune_logger import get_neptune_logger

_logger = logging.getLogger(__name__)


class SaveCode(pl.Callback):
    """A callback to save the code of the experiment.

    Args:
        files: Directory path of the code to upload. Defaults to None.
        ignores: File patterns not to upload. Defaults to ["__pycache__"].
    """

    def __init__(self, files: list[str] | None = None, ignores: list[str] | None = None) -> None:
        ignores_list = ["__pycache__"]
        if ignores:
            ignores_list += ignores
        self._ignores = shutil.ignore_patterns(*ignores_list)

        self._files = files or [
            f"{os.getcwd()}/.hydra",
            f"{hydra.utils.get_original_cwd()}/experimental",
            f"{hydra.utils.get_original_cwd()}/efficiera",
            f"{hydra.utils.get_original_cwd()}/lm",
        ]
        self._tmpdir = tempfile.TemporaryDirectory()

    @rank_zero_only
    def on_fit_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        neptune_logger = get_neptune_logger(trainer)
        if not neptune_logger:
            return

        # To increase visibility on neptune, put the code you want to keep in a single directory.
        upload_targets = []
        for path in self._files:
            if not os.path.exists(path):
                continue
            target = f"{self._tmpdir.name}/{os.path.basename(path)}"
            shutil.copytree(path, target, ignore=self._ignores)
            upload_targets.append(target)

        neptune_logger.experiment["code"].upload_files(upload_targets)

    @rank_zero_only
    def on_fit_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        self._tmpdir.cleanup()

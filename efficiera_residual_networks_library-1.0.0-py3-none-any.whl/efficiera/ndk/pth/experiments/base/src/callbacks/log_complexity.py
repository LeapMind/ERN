from __future__ import annotations

from collections.abc import Sequence
import logging

import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only

from efficiera.ndk.pth.utils import get_complexity

_logger = logging.getLogger(__name__)


class LogComplexity(pl.Callback):
    """A callback to log the complexity of a model.

    Args:
        input_shape: The shape of input data, usually (channels, height, width).
    """

    def __init__(self, input_shape: Sequence[int]) -> None:
        self._input_shape = input_shape

    @rank_zero_only
    def on_train_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        macs, params = get_complexity(pl_module, self._input_shape, readable=False)
        # HACK: Prevent training halts due to deadlock by set rank_zero_only in pl_module.log.
        pl_module.log("Params(M)", params / 1000**2, rank_zero_only=True)
        pl_module.log("Ops(G)", macs * 2 / 1000**3, rank_zero_only=True)

        # This is needed to suppress `NotImplementedError: You must implement either the backward or vjp method for
        # your custom autograd.Function to use it with backward mode AD`.
        pl_module.train()

from __future__ import annotations

import hashlib
import logging
from pathlib import Path
import shutil

import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only
import torch

from efficiera.ndk.pth.experiments.base.src.utils._get_neptune_logger import get_neptune_logger

_logger = logging.getLogger(__name__)


class SaveStateDict(pl.Callback):
    """A callback to save the state_dict of the specified property of LightningModule with the specified filename.

    Example:
        The following is an example of how to save_state a LightningModule property called network
        to a file called model.pth.

            class LitClassifier(pl.LightningModule):
                def __init__(self):
                    super().__init__()
                    self.network = nn.Sequential(
                        nn.Conv2d(1, 20, 5),
                        nn.ReLU(),
                        nn.Conv2d(20, 64, 5),
                        nn.ReLU(),
                    )

            save_state_dict = SavePureStateDictAndUploadToWandb(["network:model"], "~/exps")

    Args:
        targets (list[str]): List of TARGET_PROP_NAME:SAVE_FILE_NAME,
            The property names can be separated by dots to drill down in the hierarchy.
        dest (Path | str): A Path of destination directory.
    """

    def __init__(self, targets: list[str], dest: Path | str, append_hash: bool = True) -> None:
        self._targets = targets
        self._save_targets: dict[str, torch.nn.Module] = {}
        self._dest = Path(dest)
        self._append_hash = append_hash

    def _get_model_from_target(self, target: str, model: torch.nn.Module) -> torch.nn.Module:
        for prop in target.split("."):
            model = getattr(model, prop)
        return model

    def _calc_digest(self, filepath: str) -> str:
        sha256 = hashlib.sha256()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                sha256.update(chunk)
        return sha256.hexdigest()

    @rank_zero_only
    def on_train_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        for target in self._targets:
            if ":" not in target:
                self._save_targets[target] = pl_module
                continue

            target, filename = target.split(":")
            try:
                model = self._get_model_from_target(target, pl_module)
            except AttributeError as e:
                _logger.warning(str(e))
                _logger.warning(f"Saving the state_dict for target `{target}` will be skipped.")
                continue

            self._save_targets[filename] = model

    @rank_zero_only
    def on_train_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        output_dir = self._dest.absolute()
        output_dir.mkdir(parents=True, exist_ok=True)

        # Save model as a .pth
        for filename, model in self._save_targets.items():
            torch.save(model.state_dict(), f"{output_dir}/{filename}.pth")

            # Append the hash to the end of filename
            if self._append_hash:
                digest = self._calc_digest(f"{output_dir}/{filename}.pth")
                shutil.move(f"{output_dir}/{filename}.pth", f"{output_dir}/{filename}-{digest[:8]}.pth")
                filename = f"{filename}-{digest[:8]}"

            _logger.info(f"model saved in {output_dir}/{filename}.pth")

        neptune_logger = get_neptune_logger(trainer)
        if neptune_logger:
            neptune_logger.experiment["model"].upload_files(str(output_dir))

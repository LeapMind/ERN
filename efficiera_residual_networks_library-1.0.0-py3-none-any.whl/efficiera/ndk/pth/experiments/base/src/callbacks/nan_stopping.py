from __future__ import annotations

import logging
from typing import Any

import pytorch_lightning as pl
import torch

_logger = logging.getLogger(__name__)


class LossNaNError(Exception):
    pass


# (FIXME): This is a workaround to catch NaN from the loss value. The loss value needs to be fixed so it is not produced NaN. # NOQA: E501
class NaNStopping(pl.Callback):
    """
    A callback to stop training when ``NaN`` is detected in the loss values.
    Check if the loss is ``NaN`` per epoch and stop training.

    Args:
        verbose (bool, optional): If ``True``, prints a message when ``NaN`` is detected. Defaults to ``True``.
        log_rank_zero_only (bool): If ``True``, only the rank 0 process will log the message. Defaults to ``False``.
    """

    def __init__(
        self,
        verbose: bool = True,
        log_rank_zero_only: bool = False,
    ):
        self.verbose = verbose
        self.log_rank_zero_only = log_rank_zero_only
        self.stopped_epoch = 0
        self.stopped_batch_idx = 0

    def on_train_batch_end(
        self,
        trainer: pl.Trainer,
        pl_module: pl.LightningModule,
        outputs: torch.Tensor | dict[str, Any],
        batch: tuple[torch.Tensor],
        batch_idx: int,
    ) -> None:
        assert isinstance(outputs, dict)
        should_stop = outputs["loss"].isnan().any().item()
        assert isinstance(should_stop, bool)
        trainer.should_stop = trainer.should_stop or should_stop
        if should_stop:
            self.stopped_epoch = trainer.current_epoch
            self.stopped_batch_idx = batch_idx
            message = f"Epoch:{self.stopped_epoch}, Batch index:{batch_idx} detects NaN loss."
            if self.verbose:
                self._log_error(trainer, message, self.log_rank_zero_only)
            raise LossNaNError(message)

    @staticmethod
    def _log_error(trainer: pl.Trainer | None, message: str, log_rank_zero_only: bool) -> None:
        if trainer is not None:
            # Ignore logging in non-zero ranks if log_rank_zero_only flag is enabled
            if log_rank_zero_only and trainer.global_rank != 0:
                return
            # If world size is more than one then specify the rank of the process being logged
            if trainer.world_size > 1:
                _logger.error(f"[rank: {trainer.global_rank}] {message}")
                return

        # If the above conditions don't meet then we have to log
        _logger.error(message)

from __future__ import annotations

import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only

from efficiera.ndk.pth.experiments.base.src.utils.calc_sparsity import (
    calc_kernel_sparsity_ratio,
    calc_param_sparsity_ratio,
)


class LogSparsity(pl.Callback):
    """A callback to log the sparsity of a model.

    Logs following values.
        zero_kernel_ratio: Ratio of kernel with all weights are 0 when weights are quantized to 0/1.
        onehot_kernel_ratio: Ratio of kernel with only one weight is 1 when weights are quantized to 0/1.
        sparse_weight_ratio: Ratio of 0-weight when weights are quantized to 0/1.
    """

    @rank_zero_only
    def on_train_epoch_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        ratio_zero_kernel, ratio_onehot_kernel = calc_kernel_sparsity_ratio(pl_module.network)
        ratio_sparse_weight = calc_param_sparsity_ratio(pl_module.network)

        # HACK: Prevent training halts due to deadlock by set rank_zero_only in pl_module.log.
        pl_module.log("zero_kernel_ratio", ratio_zero_kernel, rank_zero_only=True)
        pl_module.log("onehot_kernel_ratio", ratio_onehot_kernel, rank_zero_only=True)
        pl_module.log("sparse_weight_ratio", ratio_sparse_weight, rank_zero_only=True)

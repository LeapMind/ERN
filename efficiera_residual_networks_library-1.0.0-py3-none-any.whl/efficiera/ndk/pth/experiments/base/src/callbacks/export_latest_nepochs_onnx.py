from __future__ import annotations

import logging
from pathlib import Path

import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only

from efficiera.ndk.pth.utils import export_onnx_file

logger = logging.getLogger(__name__)


class ExportLatestNEpochsOnnx(pl.Callback):
    """
    This callback exports an ONNX file at the end of every training epoch and keep the latest ``keep_n_epochs`` files.
    It addresses the missing ONNX file issue when an error occurs during an epoch (e.g. NaNStopping raises LossNaNError).
    Args:
        input_sizes (list[tuple[int, int]] | tuple[int, int]): Input image size which can be a tuple of (h, w) or a list of tuples.
        dest (Path | str): A Path of destination directory.
        name (str): A filename of the output ONNX file. The ONNX file will have the name specified here, suffixed by the number of epochs.
        keep_n_epochs (int, optional): The number of ONNX files to keep. Defaults to ``3``.
    """  # NOQA: E501

    def __init__(
        self,
        input_sizes: list[tuple[int, int]] | tuple[int, int],
        dest: Path | str,
        name: str,
        keep_n_epochs: int = 3,
    ) -> None:
        self._input_sizes = input_sizes
        self._dest = Path(dest).absolute()
        self._name = name
        self._keep_n_epochs = keep_n_epochs

    @rank_zero_only
    def on_train_epoch_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        if not self._dest.exists():
            self._dest.mkdir(parents=True)
        export_onnx_file(
            model=trainer.model,
            input_image_size=self._input_sizes,
            path=self._dest,
            model_name=f"{self._name}_{trainer.current_epoch}",
            keep_model_device=True,
            keep_model_training_mode=True,
        )
        # check number of saving models
        if trainer.current_epoch >= self._keep_n_epochs:
            (self._dest / f"{self._name}_{trainer.current_epoch - self._keep_n_epochs}.onnx").unlink()

"""``efficiera.ndk.pth.operators`` is a package of special operations to create models that work with Efficiera."""

from __future__ import annotations

from typing import Any

import torch
import torch.nn as nn


class _PixelEmbeddingV3Function(torch.autograd.Function):
    @staticmethod
    def symbolic(
        g: Any,
        x: torch.Tensor,
        weight: torch.Tensor,
        bias: torch.Tensor,
        k: int,
        max_val: int,
        out_channels_list: list[int],
        use_floor: bool,
    ) -> Any:
        if use_floor:
            return g.op(
                "lm::PixelEmbeddingV3", x, weight, bias, k_i=k, max_val_i=max_val, out_channels_list_i=out_channels_list
            )
        # PixelEmbeddingV3Act is a without floor version of ONNX op in the bxb converter
        return g.op(
            "lm::PixelEmbeddingV3Act", x, weight, bias, k_i=k, max_val_i=max_val, out_channels_list_i=out_channels_list
        )

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        weight: torch.Tensor,
        bias: torch.Tensor,
        k: int,
        max_val: int,
        out_channels_list: list[int],
        use_floor: bool,
    ) -> torch.Tensor:
        n, c, h, w = x.shape
        y = x.reshape((n, c, 1, h, w)) * weight - bias
        y = torch.clamp(y, 0.0, 2**k - 0.000001)
        if use_floor:
            y = torch.floor(y)
        return y.reshape((n, -1, h, w))


class PixelEmbeddingV3(nn.Module):
    """PixelEmbeddingV3.
    Pixel embedding is a technique enable quantization of the first layer for a given DNN model.
    Pixel embedding V3 is done by quantize input values to k bit using Thermometer Encoding modified from `FracBNN - Accurate and FPGA-Efficient Binary Neural Networks with Fractional Activations`_.

    Args:
        in_channels (int): A number of input channel.
        expansion (int, optional): An expansion rate for each output channel. Defaults to ``21``
        k (int, optional): A number of bit to quantized an input. Currently, only 2 is supported. Do not change. Defaults to ``2``
        max_val (int, optional): A maximum value of input of the operator. Defaults to ``255``
        use_floor (bool, optional): Use torch.floor after clamp or not. Defaults to ``True``

    .. _FracBNN - Accurate and FPGA-Efficient Binary Neural Networks with Fractional Activations:
        https://arxiv.org/abs/2012.12206
    """  # NOQA: E501

    def __init__(
        self, in_channels: int, expansion: int = 21, k: int = 2, max_val: int = 255, use_floor: bool = True
    ) -> None:
        super().__init__()
        self.expansion = expansion
        self.k = k
        self.max_val = max_val
        self.out_channels_list = [expansion for i in range(0, in_channels)]
        self.use_floor = use_floor

        step = max(1, max_val // ((2**k - 1) * expansion))

        w_const = torch.ones((1, in_channels, expansion, 1, 1)) * (1.0 / (step * expansion))
        b_const = (
            torch.arange(start=step, end=step * expansion + 1, step=step).reshape((1, 1, expansion, 1, 1))
            * (1.0 / (step * expansion))
            - 1.0
        )

        self.w_const = nn.Parameter(w_const, requires_grad=False)
        self.b_const = nn.Parameter(b_const, requires_grad=False)

        # Both w and b (n=1, c, expansion, h=1, w=1)
        self.w = nn.Parameter(torch.zeros_like(w_const), requires_grad=(not self.use_floor))
        self.b = nn.Parameter(torch.zeros_like(w_const) + 0.0001, requires_grad=(not self.use_floor))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.dtype in {torch.uint8, torch.int16, torch.int32, torch.float32}

        # if input dtype is float32, it must be normalized to 0.0 to 1.0.
        if x.dtype == torch.float32:
            x = x * self.max_val

        if self.training:
            n, c, h, w = x.shape
            y = x.reshape((n, c, 1, h, w)) * (self.w_const + self.w) - (self.b_const + self.b)
            y = torch.clamp(y, 0.0, 2**self.k - 0.000001)
            if self.use_floor:
                y = torch.floor(y)
            return y.reshape((n, c * self.expansion, h, w))

        return _PixelEmbeddingV3Function.apply(
            x,
            self.w_const + self.w,
            self.b_const + self.b,
            self.k,
            self.max_val,
            self.out_channels_list,
            self.use_floor,
        )


def _space_to_depth_forward(x: torch.Tensor, block_size: int) -> torch.Tensor:
    """Space to Depth Forward.

    Args:
        x (torch.Tensor): Input tensor in NCHW format (N, C, H x block_size, W x block_size).
        block_size (int): Input block size.
    Returns:
        torch.tensor: A tensor with reduced height and width and increased channels (N, C x block_size^2, H, W).
    """
    bs = block_size
    n, c, h, w = x.size()
    x = x.view(n, c, h // bs, bs, w // bs, bs)
    x = x.permute(0, 3, 5, 1, 2, 4).contiguous()
    x = x.view(n, c * (bs * bs), h // bs, w // bs)
    return x


class _SpaceToDepthFunction(torch.autograd.Function):
    """Space to Depth operator. (To make the user defined operator exportable into ONNX format)

    Args:
        x (torch.Tensor): Input tensor in NCHW format (N, C, H x block_size, W x block_size).
        block_size (int): Input block size.
    Returns:
        torch.tensor: A tensor with reduced height and width and increased channels (N, C x block_size^2, H, W).
    """

    @staticmethod
    def symbolic(g: Any, x: torch.Tensor, block_size: int) -> Any:
        return g.op("SpaceToDepth", x, blocksize_i=block_size)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, block_size: int) -> torch.Tensor:
        return _space_to_depth_forward(x, block_size)


class SpaceToDepth(nn.Module):
    """Space to Depth operator. (To avoid the implementation of backward function)

    Args:
        x (torch.Tensor): Input tensor in NCHW format (N, C, H x block_size, W x block_size).
        block_size (int): Input block size.

    Returns:
        torch.tensor: A tensor with reduced height and width and increased channels (N, C x block_size^2, H, W).
    """

    def __init__(self, block_size: int) -> None:
        super().__init__()
        self.block_size = block_size

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training:
            return _space_to_depth_forward(x, self.block_size)
        return _SpaceToDepthFunction.apply(x, self.block_size)


def _depth_to_space_forward(x: torch.Tensor, block_size: int) -> torch.Tensor:
    """Depth to Space Forward.

    Args:
        x (torch.Tensor): Input tensor in NCHW format (N, C x block_size^2, H, W).
        block_size (int): Input block size.
    Returns:
        torch.tensor: A tensor with increased height and width and decreased channels
        (N, C, H x block_size, W x block_size).
    """
    bs = block_size
    n, c, h, w = x.shape
    x = x.view(n, bs, bs, c // (bs * bs), h, w)
    x = x.permute(0, 3, 4, 1, 5, 2).contiguous()
    x = x.view(n, c // (bs * bs), h * bs, w * bs)
    return x


class _DepthToSpaceFunction(torch.autograd.Function):
    """Depth to Space operator. (To make the user defined operator exportable into ONNX format)

    Args:
        x (torch.Tensor): Input tensor in NCHW format (N, C x block_size^2, H, W)
        block_size (int): Input block size
    Returns:
        torch.tensor: A tensor with increased height and width and decreased channels
        (N, C, H x block_size, W x block_size)
    """

    @staticmethod
    def symbolic(g: Any, x: torch.Tensor, block_size: int) -> Any:
        return g.op("DepthToSpace", x, blocksize_i=block_size)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, block_size: int) -> torch.Tensor:
        return _depth_to_space_forward(x, block_size)


class DepthToSpace(nn.Module):
    """Depth to Space operator. (To avoid the implementation of backward function)

    Args:
        x (torch.Tensor): Input tensor in NCHW format (N, C x block_size^2, H, W).
        block_size (int): Input block size.

    Returns:
        torch.tensor: A tensor with increased height and width and decreased channels
        (N, C, H x block_size, W x block_size)
    """

    def __init__(self, block_size: int) -> None:
        super().__init__()
        self.block_size = block_size

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training:
            return _depth_to_space_forward(x, self.block_size)
        return _DepthToSpaceFunction.apply(x, self.block_size)

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

import numpy as np
from numpy.typing import _SupportsArray
from typing_extensions import TypeAlias

ArrayScalarLike: TypeAlias = "bool | int | float | complex | np.bool_ | np.number[Any]"
ArrayLike: TypeAlias = "_SupportsArray | ArrayScalarLike | Sequence[ArrayScalarLike] | Sequence[Sequence[ArrayScalarLike]] | Sequence[Sequence[Sequence[ArrayScalarLike]]] | Sequence[Sequence[Sequence[Sequence[ArrayScalarLike]]]] | Sequence[Sequence[Sequence[Sequence[Sequence[Any]]]]]"  # NOQA: E501
TensorScalarLike: TypeAlias = "bool | int | float | complex | np.bool_ | np.int8 | np.int16 | np.int32 | np.int64 | np.uint8 | np.float16 | np.float32 | np.float64 | np.complex64 | np.complex128"  # NOQA: E501
TensorLike: TypeAlias = "_SupportsArray | TensorScalarLike | Sequence[TensorScalarLike] | Sequence[Sequence[TensorScalarLike]] | Sequence[Sequence[Sequence[TensorScalarLike]]] | Sequence[Sequence[Sequence[Sequence[TensorScalarLike]]]] | Sequence[Sequence[Sequence[Sequence[Sequence[Any]]]]]"  # NOQA: E501

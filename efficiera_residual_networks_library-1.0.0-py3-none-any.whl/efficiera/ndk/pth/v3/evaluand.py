from __future__ import annotations

from dataclasses import dataclass, field

import torch

from efficiera.ndk.pth.v3.activation_fuser_for_evaluand import ActivationFuserForEvaluand
from efficiera.ndk.pth.v3.expression import Expression
from efficiera.ndk.pth.v3.fuser_for_evaluand import FuserForEvaluand
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.linear_fuser_for_evaluand import LinearFuserForEvaluand
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.value import Value


@dataclass(frozen=True)
class Evaluand:
    value: Value
    expression: Expression = field(default_factory=Expression.get_identity)
    fuser: FuserForEvaluand | None = None

    @classmethod
    def quantize(cls, tensor: torch.Tensor, precision: Precision | None = None) -> Evaluand:
        return Evaluand(value=Value.quantize(tensor, precision=precision))

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self.fuser is not None:
            kwargs.update(fuser=self.fuser)
        return get_repr(self, value=self.value, expression=self.expression, **kwargs)

    def __pos__(self) -> Evaluand:
        return self

    def __neg__(self) -> Evaluand:
        return Evaluand(value=self.value, expression=-self.expression, fuser=self.fuser)

    def __add__(self, other: Evaluand) -> Evaluand:
        return Evaluand(value=self.value + other.value, expression=self.expression + other.expression)

    def __sub__(self, other: Evaluand) -> Evaluand:
        return Evaluand(value=self.value - other.value, expression=self.expression - other.expression)

    def fold_adding(self, bias: torch.Tensor) -> Evaluand:
        return Evaluand(value=self.value, expression=self.expression.fold_adding(bias=bias), fuser=self.fuser)

    def __mul__(self, other: Evaluand) -> Evaluand:
        return Evaluand(value=self.value * other.value, expression=self.expression * other.expression)

    def fold_multiplying(self, scale: torch.Tensor) -> Evaluand:
        return Evaluand(value=self.value, expression=self.expression.fold_multiplying(scale=scale), fuser=self.fuser)

    def fold_activation_multiplying(self, positive_slope: torch.Tensor, negative_slope: torch.Tensor) -> Evaluand:
        return Evaluand(
            value=self.value,
            expression=self.expression.fold_activation_multiplying(
                positive_slope=positive_slope, negative_slope=negative_slope
            ),
            fuser=self.fuser,
        )

    def fuse_linear(self, scale_precision: Precision, bias_precision: Precision) -> Evaluand:
        return self.start_fusing_linear(scale_precision=scale_precision, bias_precision=bias_precision).end_fusing()

    def start_fusing_linear(self, scale_precision: Precision, bias_precision: Precision) -> Evaluand:
        if self.fuser is not None:
            raise ValueError
        return Evaluand(
            value=self.value,
            expression=self.expression,
            fuser=LinearFuserForEvaluand(scale_precision=scale_precision, bias_precision=bias_precision),
        )

    def fuse_activation(
        self, positive_slope_precision: Precision, negative_slope_precision: Precision, bias_precision: Precision
    ) -> Evaluand:
        return self.start_fusing_activation(
            positive_slope_precision=positive_slope_precision,
            negative_slope_precision=negative_slope_precision,
            bias_precision=bias_precision,
        ).end_fusing()

    def start_fusing_activation(
        self, positive_slope_precision: Precision, negative_slope_precision: Precision, bias_precision: Precision
    ) -> Evaluand:
        if self.fuser is not None:
            raise ValueError
        return Evaluand(
            value=self.value,
            expression=self.expression,
            fuser=ActivationFuserForEvaluand(
                positive_slope_precision=positive_slope_precision,
                negative_slope_precision=negative_slope_precision,
                bias_precision=bias_precision,
            ),
        )

    def end_fusing(self) -> Evaluand:
        if self.fuser is None:
            raise ValueError
        return Evaluand(value=self.fuser.fuse(value=self.value, expression=self.expression))

    def clamp(self, min: float | None, max: float | None) -> Evaluand:
        return self.cast(precision=Precision(min=min, max=max, fractional_bits=None))

    def bit_round(self, fractional_bits: int) -> Evaluand:
        return self.cast(precision=Precision(min=None, max=None, fractional_bits=fractional_bits))

    def cast(self, precision: Precision) -> Evaluand:
        if self.fuser is not None:
            raise ValueError
        return Evaluand(value=self.value.cast(precision=precision), expression=self.expression, fuser=self.fuser)

    def round_half_up(self) -> Evaluand:
        if self.fuser is not None:
            raise ValueError
        return Evaluand(value=self.value.round_half_up(), expression=self.expression, fuser=self.fuser)

    def conv2d(
        self, weight: Evaluand, stride: int | tuple[int, int], padding: int | tuple[int, int], groups: int
    ) -> Evaluand:
        if self.fuser is not None:
            raise ValueError
        return Evaluand(
            value=self.value.conv2d(weight=weight.value, stride=stride, padding=padding, groups=groups),
            expression=self.expression * weight.expression,
            fuser=self.fuser,
        )

    def space_to_depth(self, block_size: int) -> Evaluand:
        if self.fuser is not None:
            raise ValueError
        return Evaluand(
            value=self.value.space_to_depth(block_size=block_size),
            expression=self.expression.space_to_depth(),
            fuser=self.fuser,
        )

from dataclasses import dataclass

from efficiera.ndk.pth.v3.expression import Expression
from efficiera.ndk.pth.v3.fuser_for_evaluand import FuserForEvaluand
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.value import Value


@dataclass(frozen=True)
class ActivationFuserForEvaluand(FuserForEvaluand):
    positive_slope_precision: Precision
    negative_slope_precision: Precision
    bias_precision: Precision

    def __repr__(self) -> str:
        return get_repr(
            self,
            positive_slope_precision=self.positive_slope_precision,
            negative_slope_precision=self.negative_slope_precision,
            bias_precision=self.bias_precision,
        )

    def fuse(self, value: Value, expression: Expression) -> Value:
        value = value.activation_multiply(
            positive_slope=Value.quantize(expression.positive_slope[..., None, None])
            .cast(self.positive_slope_precision)
            .to_exportable(device=value.tensor.device),
            negative_slope=Value.quantize(expression.negative_slope[..., None, None])
            .cast(self.negative_slope_precision)
            .to_exportable(device=value.tensor.device),
        )
        value = value + Value.quantize(expression.bias[..., None, None]).cast(self.bias_precision).to_exportable(
            device=value.tensor.device
        )
        return value

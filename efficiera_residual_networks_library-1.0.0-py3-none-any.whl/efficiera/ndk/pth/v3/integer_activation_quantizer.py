from __future__ import annotations

import torch

from efficiera.ndk.pth.quantizers import IntegerQuantizer as v2_IntegerQuantizer
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class IntegerActivationQuantizer(UnaryQuantalModule):
    """Integer Activation Quantizer.
    An activation quantization scheme that allows inference to be carried out using integer-only arithmetic [1]_

    Args:
        k (int, optional): bit-width of the precision of activation function. It can only be a positive real value.
            Defaults to ``8``
        symmetric (bool, optional): If ``True``, set int_min = -int_max. Defaults to ``True``
        max_value (float, optional): Upper bound of value to clip. It can only be a positive real value. Defaults to
            ``16.0``
        disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``

    Reference:
        .. [1] `Quantization and Training of Neural Networks for Efficient Integer-Arithmetic-Only Inference
        <https://arxiv.org/abs/1712.05877>`_
    """

    def __init__(
        self,
        k: int = 8,
        symmetric: bool = True,
        max_value: float = 16.0,
        disable_post_scale: bool = False,
    ) -> None:
        super().__init__()
        self._v2 = v2_IntegerQuantizer(
            k=k, symmetric=symmetric, max_value=max_value, disable_post_scale=disable_post_scale
        )

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self._v2.k != 8:
            kwargs.update(k=self._v2.k)
        if not self._v2.symmetric:
            kwargs.update(symmetric=self._v2.symmetric)
        if self._v2.max_value != 16.0:
            kwargs.update(max_value=self._v2.max_value)
        if self._v2.disable_post_scale:
            kwargs.update(disable_post_scale=self._v2.disable_post_scale)
        return get_repr(self, **kwargs)

    def forward(self, input: Quantum) -> Quantum:
        trainand = self._v2(input.trainand)
        scale = torch.tensor((self._v2.int_max + 1.0) / self._v2.max_value)
        evaluand = input.evaluand.fold_multiplying(scale)
        evaluand = evaluand.end_fusing()
        evaluand = evaluand.cast(precision=Precision(min=self._v2.int_min, max=self._v2.int_max, fractional_bits=0))
        if not self._v2.disable_post_scale:
            evaluand = evaluand.fold_multiplying(1.0 / scale)
        return Quantum(trainand=trainand, evaluand=evaluand)

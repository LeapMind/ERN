from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F

from efficiera.ndk.pth.operators import _space_to_depth_forward
from efficiera.ndk.pth.v3.activation_multiply_function import ActivationMultiplyFunction
from efficiera.ndk.pth.v3.bit_round_function import BitRoundFunction
from efficiera.ndk.pth.v3.clamp_function import ClampFunction
from efficiera.ndk.pth.v3.evaluand import Evaluand
from efficiera.ndk.pth.v3.exporting_mode import ExportingMode
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision


@dataclass(frozen=True)
class Quantum:
    """Data structure represents the information needed for both training and evaluation in NDK v3.

    The Quantum class is used in place of ``torch.Tensor`` as the input and output of the NDK v3 modules. The Quantum
    class contains ``torch.Tensor`` used for training, as well as information used for fixed-point operations for
    evaluation and for constant folding.

    Args:
        trainand (torch.Tensor): Tensor object returned by floating-point forward used for training only.
        evaluand (Evaluand): ``Evaluand`` object returned by fixed-point forward used for both training and evaluation.
            The object contains information used for fixed-point operations and for constant folding.
    """

    trainand: torch.Tensor
    evaluand: Evaluand

    @classmethod
    def quantize(cls, tensor: torch.Tensor) -> Quantum:
        """Convert ``tensor`` to ``Quantum``.

        Args:
            tensor (torch.Tensor): Tensor object to be converted to ``Quantum``
        """
        if tensor.dtype != torch.float32:
            float_tensor = tensor.to(dtype=torch.float32)
        else:
            float_tensor = tensor
        return Quantum(trainand=float_tensor, evaluand=Evaluand.quantize(tensor))

    def __repr__(self) -> str:
        return get_repr(self, trainand=self.trainand, evaluand=self.evaluand)

    def __pos__(self) -> Quantum:
        """Return Quantum positive (+Quantum)."""
        return self

    def __neg__(self) -> Quantum:
        """Return Quantum negated (-Quantum)."""
        return Quantum(trainand=-self.trainand, evaluand=-self.evaluand)

    def __add__(self, other: Quantum) -> Quantum:
        """Return a new Quantum that represents the sum of two Quantums.

        Args:
            other (Quantum): ``Quantum`` object to be add.
        """
        return Quantum(trainand=self.trainand + other.trainand, evaluand=self.evaluand + other.evaluand)

    def fold_adding(self, bias: torch.Tensor) -> Quantum:
        """Fold a tensor object named ``bias``. Folded ``bias`` object is kept in the ``self`` object and added when the
        ``end_fusing`` method is called.

        Args:
            bias (torch.Tensor): Tensor object to be add with delay.
        """
        return Quantum(trainand=self.trainand + bias, evaluand=self.evaluand.fold_adding(bias=bias))

    def __sub__(self, other: Quantum) -> Quantum:
        """Return a new Quantum that represents the subtraction of ``self`` by ``other`` Quantum.

        Args:
            other (Quantum): ``Quantum`` object to be subtracted.
        """
        return Quantum(trainand=self.trainand - other.trainand, evaluand=self.evaluand - other.evaluand)

    def __mul__(self, other: Quantum) -> Quantum:
        """Return a new Quantum that represents the multiplication of ``self`` and ``other`` Quantum.

        Args:
            other (Quantum): ``Quantum`` object to be multiplied.
        """
        return Quantum(trainand=self.trainand * other.trainand, evaluand=self.evaluand * other.evaluand)

    def fold_multiplying(self, scale: torch.Tensor) -> Quantum:
        """Fold a tensor object named ``scale``. Folded ``scale`` object is kept in the ``self`` object and multiplied
        when the ``end_fusing`` method is called.

        Args:
            scale (torch.Tensor): Tensor object to be multiply with delay.
        """
        return Quantum(trainand=self.trainand * scale, evaluand=self.evaluand.fold_multiplying(scale=scale))

    def fold_activation_multiplying(self, positive_slope: torch.Tensor, negative_slope: torch.Tensor) -> Quantum:
        """Fold tensor objects named ``positive_slope`` and ``negative_slope``. Foled ``positive_slope`` and
        ``negative_slope`` objects are kept in the ``self` object and activation-multiplied when the ``end_fusing``
        method is called.

        Args:
            positive_slope (torch.Tensor): Tensor object to be multiplied by each element of ``self`` where ``0`` or
                positive with delay.
            negative_slope (torch.Tensor): Tensor object to be multiplied by each element of ``self`` where negative
                with delay.
        """
        return Quantum(
            trainand=ActivationMultiplyFunction.apply(self.trainand, positive_slope, negative_slope),
            evaluand=self.evaluand.fold_activation_multiplying(
                positive_slope=positive_slope, negative_slope=negative_slope
            ),
        )

    def fuse_linear(self, scale_precision: Precision, bias_precision: Precision) -> Quantum:
        """Apply a linear operation optimized by constant folding.

        Args:
            scale_precision (Precision): Precision of the coefficient to be multiplied.
            bias_precision (Precision): Precision of the coefficient to be add.
        """
        return self.start_fusing_linear(scale_precision=scale_precision, bias_precision=bias_precision).end_fusing()

    def start_fusing_linear(self, scale_precision: Precision, bias_precision: Precision) -> Quantum:
        """Specify precisions of the coefficients of a linear operation optimized by constant folding.

        Args:
            scale_precision (Precision): Precision of the coefficient to be multiplied.
            bias_precision (Precision): Precision of the coefficient to be add.
        """
        return Quantum(
            trainand=self.trainand,
            evaluand=self.evaluand.start_fusing_linear(scale_precision=scale_precision, bias_precision=bias_precision),
        )

    def fuse_activation(
        self, positive_slope_precision: Precision, negative_slope_precision: Precision, bias_precision: Precision
    ) -> Quantum:
        """Apply an activation operation optimized by constant folding.

        Args:
            positive_slope_precision (Precision): Precision of the coefficient to be multiplied by each element of
                input where the slope is positive or zero.
            negative_slope_precision (Precision): Precision of the coefficient to be multiplied by each element of
                input where negative.
            bias_precision (Precision): Precision of the coefficient to be add.
        """
        return self.start_fusing_activation(
            positive_slope_precision=positive_slope_precision,
            negative_slope_precision=negative_slope_precision,
            bias_precision=bias_precision,
        ).end_fusing()

    def start_fusing_activation(
        self, positive_slope_precision: Precision, negative_slope_precision: Precision, bias_precision: Precision
    ) -> Quantum:
        """Specify precisions of the coefficients of an activation operation optimized by constant folding.

        Args:
            positive_slope_precision (Precision): Precision of the coefficient to be multiplied by each element of
                input where the slope is positive or zero.
            negative_slope_precision (Precision): Precision of the coefficient to be multiplied by each element of
                input where negative.
            bias_precision (Precision): Precision of the coefficient to be add.
        """
        return Quantum(
            trainand=self.trainand,
            evaluand=self.evaluand.start_fusing_activation(
                positive_slope_precision=positive_slope_precision,
                negative_slope_precision=negative_slope_precision,
                bias_precision=bias_precision,
            ),
        )

    def end_fusing(self) -> Quantum:
        """Apply folded objects with the precision specified by the ``start_fusing_activation`` function."""
        return Quantum(trainand=self.trainand, evaluand=self.evaluand.end_fusing())

    def clamp(self, min: float | None, max: float | None) -> Quantum:
        """Clamp all elements in ``self`` Quantum into the range [ ``min``, ``max`` ].

        Args:
            min (float | None): Lower-bound of the range to be clamped to.
            max (float | None): Upper-bound of the range to be clamped to.
        """
        return self.cast(precision=Precision(min=min, max=max, fractional_bits=None))

    def bit_round(self, fractional_bits: int) -> Quantum:
        """Round elements of ``self`` Quantum to the nearest fixed-point number.

        Args:
            fractional_bits (int): Number of binary places to round to.
        """
        return self.cast(precision=Precision(min=None, max=None, fractional_bits=fractional_bits))

    def cast(self, precision: Precision) -> Quantum:
        """Cast to specified precision.

        Args:
            precision (Precision): Casting precision.
        """
        trainand = self.trainand
        if precision != Precision.float:
            if not self.evaluand.expression.is_identity:
                trainand = self.evaluand.expression.apply_inversely_to_tensor(trainand)
            if precision.min is not None or precision.max is not None:
                trainand = ClampFunction.apply(trainand, precision.min, precision.max)
            if precision.fractional_bits is not None:
                trainand = BitRoundFunction.apply(trainand, precision.fractional_bits)
            if not self.evaluand.expression.is_identity:
                trainand = self.evaluand.expression.apply_to_tensor(trainand)
        evaluand = self.evaluand.cast(precision=precision)
        return Quantum(trainand=trainand, evaluand=evaluand)

    def round_half_up(self) -> Quantum:
        """Round half up elements of input to the nearest integer."""
        trainand = self.trainand
        if not self.evaluand.expression.is_identity:
            trainand = self.evaluand.expression.apply_inversely_to_tensor(trainand)
        trainand = self.evaluand.expression.apply_inversely_to_tensor(self.trainand)
        trainand = torch.floor(trainand + 0.5)
        trainand = self.evaluand.expression.apply_to_tensor(trainand)
        if not self.evaluand.expression.is_identity:
            trainand = self.evaluand.expression.apply_to_tensor(trainand)
        evaluand = self.evaluand.round_half_up()
        return Quantum(trainand=trainand, evaluand=evaluand)

    def conv2d(
        self, weight: Quantum, stride: int | tuple[int, int], padding: int | tuple[int, int], groups: int
    ) -> Quantum:
        """Apply Convolution 2d operator.

        Args:
            weight (Quantum): The learnable weights of the Convolution 2d operator.
            stride (int | tuple[int, int], optional): Stride of the convolution. Defaults to ``1``.
            padding (int | tuple[int, int], optional): Padding added to all four sides of the input. Defaults to ``0``.
            groups (int, optional): Number of blocked connections from input channels to output channels. Defaults to
                ``1``.
        """
        return Quantum(
            trainand=F.conv2d(self.trainand, weight=weight.trainand, stride=stride, padding=padding, groups=groups),
            evaluand=self.evaluand.conv2d(weight=weight.evaluand, stride=stride, padding=padding, groups=groups),
        )

    def space_to_depth(self, block_size: int) -> Quantum:
        """Space to Depth operator.

        Args:
            block_size (int): Input block size.
        """
        return Quantum(
            trainand=_space_to_depth_forward(self.trainand, block_size),
            evaluand=self.evaluand.space_to_depth(block_size=block_size),
        )

    def dequantize(self, training: bool) -> torch.Tensor:
        """Convert to tensor object.

        Args:
            training (bool): Whether the model is in training mode or not.
        """
        if not self.evaluand.expression.is_identity:
            raise ValueError("Optimization by constant-folding has not been resolved. Call fuse operation.")
        if training:
            if ExportingMode.get():
                return self.trainand
            return self.trainand + (self.evaluand.value.tensor - self.trainand).detach()
        return self.evaluand.value.tensor

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar

from backports.cached_property import cached_property
import torch

from efficiera.ndk.pth.v3.get_repr import get_repr


@dataclass(frozen=True)
class Expression:
    positive_slope: torch.Tensor
    negative_slope: torch.Tensor
    bias: torch.Tensor

    rtol: ClassVar[float] = 2.0**-16
    atol: ClassVar[float] = 2.0**-16

    @classmethod
    def get_identity(cls) -> Expression:
        return Expression(positive_slope=torch.tensor(1.0), negative_slope=torch.tensor(1.0), bias=torch.tensor(0.0))

    @classmethod
    def get_linear(cls, scale: torch.Tensor, bias: torch.Tensor) -> Expression:
        return Expression(positive_slope=scale, negative_slope=scale, bias=bias)

    def __repr__(self) -> str:
        return get_repr(self, positive_slope=self.positive_slope, negative_slope=self.negative_slope, bias=self.bias)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Expression):
            return (
                torch.allclose(self.positive_slope, other.positive_slope, rtol=self.rtol, atol=self.atol)
                and torch.allclose(self.negative_slope, other.negative_slope, rtol=self.rtol, atol=self.atol)
                and torch.allclose(self.bias, other.bias, rtol=self.rtol, atol=self.atol)
            )
        return False

    @cached_property
    def has_scale(self) -> bool:
        return torch.allclose(self.positive_slope, self.negative_slope, rtol=self.rtol, atol=self.atol)

    @cached_property
    def scale(self) -> torch.Tensor:
        if not self.has_scale:
            raise ValueError
        return (self.positive_slope + self.negative_slope) / 2.0

    @cached_property
    def bias_are_zeros(self) -> bool:
        return torch.allclose(self.bias, torch.tensor(0.0), rtol=self.rtol, atol=self.atol)

    @cached_property
    def positive_slope_are_zeros_or_greater(self) -> bool:
        item = torch.all(
            torch.logical_or(
                self.positive_slope > 0.0,
                torch.isclose(self.positive_slope, torch.tensor(0.0), rtol=self.rtol, atol=self.atol),
            )
        ).item()
        assert isinstance(item, bool)
        return item

    @cached_property
    def negative_slope_are_zeros_or_greater(self) -> bool:
        item = torch.all(
            torch.logical_or(
                self.negative_slope > 0.0,
                torch.isclose(self.negative_slope, torch.tensor(0.0), rtol=self.rtol, atol=self.atol),
            )
        ).item()
        assert isinstance(item, bool)
        return item

    @cached_property
    def is_channel_wise(self) -> bool:
        return self.positive_slope.numel() > 1 or self.negative_slope.numel() > 1 or self.bias.numel() > 1

    @cached_property
    def is_identity(self) -> bool:
        return (
            torch.allclose(self.positive_slope, torch.tensor(1.0), rtol=self.rtol, atol=self.rtol)
            and torch.allclose(self.negative_slope, torch.tensor(1.0), rtol=self.rtol, atol=self.atol)
            and torch.allclose(self.bias, torch.tensor(0.0), rtol=self.rtol, atol=self.atol)
        )

    def __pos__(self) -> Expression:
        return self

    def __neg__(self) -> Expression:
        return Expression(positive_slope=-self.positive_slope, negative_slope=-self.negative_slope, bias=-self.bias)

    def __add__(self, other: Expression) -> Expression:
        if not torch.allclose(self.scale, other.scale, rtol=self.rtol, atol=self.atol):
            raise ValueError
        return Expression.get_linear((self.scale + other.scale) / 2.0, self.bias + other.bias)

    def fold_adding(self, bias: torch.Tensor) -> Expression:
        return Expression(
            positive_slope=self.positive_slope,
            negative_slope=self.negative_slope,
            bias=self.bias + bias,
        )

    def __sub__(self, other: Expression) -> Expression:
        if not torch.allclose(self.scale, other.scale, rtol=self.rtol, atol=self.atol):
            raise ValueError
        return Expression.get_linear((self.scale + other.scale) / 2.0, self.bias - other.bias)

    def __mul__(self, other: Expression) -> Expression:
        if not self.bias_are_zeros:
            raise ValueError
        if not other.bias_are_zeros:
            raise ValueError
        return Expression.get_linear(self.scale * other.scale, bias=torch.tensor(0.0))

    def fold_multiplying(self, scale: torch.Tensor) -> Expression:
        return Expression(
            positive_slope=self.positive_slope * scale,
            negative_slope=self.negative_slope * scale,
            bias=self.bias * scale,
        )

    def fold_activation_multiplying(self, positive_slope: torch.Tensor, negative_slope: torch.Tensor) -> Expression:
        if not self.bias_are_zeros:
            raise ValueError
        if not self.positive_slope_are_zeros_or_greater:
            raise NotImplementedError
        if not self.negative_slope_are_zeros_or_greater:
            raise NotImplementedError
        return Expression(
            positive_slope=self.positive_slope * positive_slope,
            negative_slope=self.negative_slope * negative_slope,
            bias=torch.tensor(0.0),
        )

    def apply_to_tensor(self, tensor: torch.Tensor) -> torch.Tensor:
        return tensor * self.scale.detach() + self.bias.detach()

    def apply_inversely_to_tensor(self, tensor: torch.Tensor) -> torch.Tensor:
        return (tensor - self.bias.detach()) / self.scale.detach()

    def space_to_depth(self) -> Expression:
        if self.is_channel_wise:
            raise ValueError
        return self

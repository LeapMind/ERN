from __future__ import annotations


def get_extra_repr(*args: object, **kwargs: object) -> str:
    extra_repr_lines: list[str] = []
    is_multilines = False
    for arg in args:
        arg_repr = repr(arg)
        arg_repr_lines = arg_repr.splitlines()
        if len(arg_repr_lines) > 1:
            extra_repr_lines.append("\n".join(arg_repr_lines))
            is_multilines = True
        else:
            extra_repr_lines.append(arg_repr)
    for kw, arg in kwargs.items():
        arg_repr = repr(arg)
        arg_repr_lines = arg_repr.splitlines()
        if len(arg_repr_lines) > 1:
            if hasattr(arg, "__array__"):
                extra_repr_lines.append(f"{kw}=\n  " + "\n  ".join(arg_repr_lines))
            else:
                extra_repr_lines.append(f"{kw}=" + "\n".join(arg_repr_lines))
            is_multilines = True
        else:
            extra_repr_lines.append(f"{kw}={arg_repr}")
    if is_multilines:
        return ",\n".join(extra_repr_lines)
    return ", ".join(extra_repr_lines)


def get_repr(self: object, *args: object, **kwargs: object) -> str:
    extra_repr = get_extra_repr(*args, **kwargs)
    extra_repr_lines = extra_repr.splitlines()
    if len(extra_repr_lines) > 1:
        return f"{type(self).__name__}(\n  " + "\n  ".join(extra_repr_lines) + "\n)"
    return f"{type(self).__name__}({extra_repr})"

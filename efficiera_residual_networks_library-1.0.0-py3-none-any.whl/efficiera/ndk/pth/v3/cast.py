from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class Cast(UnaryQuantalModule):
    def __init__(self, precision: Precision) -> None:
        super().__init__()
        self.precision = precision

    def __repr__(self) -> str:
        return get_repr(self, precision=self.precision)

    def forward(self, input: Quantum) -> Quantum:
        return input.cast(self.precision)

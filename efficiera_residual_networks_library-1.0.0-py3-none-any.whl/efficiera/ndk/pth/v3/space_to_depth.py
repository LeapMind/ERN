from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class SpaceToDepth(UnaryQuantalModule):
    """Space to Depth operator.

    Args:
        block_size (int): Input block size.
    """

    def __init__(self, block_size: int) -> None:
        super().__init__()
        self.block_size = block_size

    def __repr__(self) -> str:
        return get_repr(self, block_size=self.block_size)

    def forward(self, input: Quantum) -> Quantum:
        return input.space_to_depth(block_size=self.block_size)

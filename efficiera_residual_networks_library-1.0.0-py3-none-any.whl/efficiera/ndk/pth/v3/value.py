from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F

from efficiera.ndk.pth.operators import _SpaceToDepthFunction
from efficiera.ndk.pth.v3.activation_multiply_function import ActivationMultiplyFunction
from efficiera.ndk.pth.v3.bit_round_function import BitRoundFunction
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.to_exportable_tensor import to_exportable_tensor


@dataclass(frozen=True)
class Value:
    tensor: torch.Tensor
    precision: Precision

    @classmethod
    def quantize(cls, tensor: torch.Tensor, precision: Precision | None = None) -> Value:
        if precision is None:
            precision = Precision.from_dtype(tensor.dtype)
        if tensor.dtype != torch.float32:
            tensor = tensor.to(dtype=torch.float32)
        return cls(tensor=tensor, precision=precision)

    def __repr__(self) -> str:
        return get_repr(self, tensor=self.tensor, precision=self.precision)

    def __pos__(self) -> Value:
        return self

    def __neg__(self) -> Value:
        return Value(tensor=-self.tensor, precision=-self.precision)

    def __add__(self, other: Value) -> Value:
        return Value(tensor=self.tensor + other.tensor, precision=self.precision + other.precision)

    def __sub__(self, other: Value) -> Value:
        return Value(tensor=self.tensor - other.tensor, precision=self.precision - other.precision)

    def __mul__(self, other: Value) -> Value:
        return Value(tensor=self.tensor * other.tensor, precision=self.precision * other.precision)

    def activation_multiply(self, positive_slope: Value, negative_slope: Value) -> Value:
        return Value(
            tensor=ActivationMultiplyFunction.apply(self.tensor, positive_slope.tensor, negative_slope.tensor),
            precision=self.precision.activation_multiply(
                positive_slope_precision=positive_slope.precision, negative_slope_precision=negative_slope.precision
            ),
        )

    def clamp(self, min: float | None, max: float | None) -> Value:
        return self.cast(precision=Precision(min=min, max=max, fractional_bits=None))

    def bit_round(self, fractional_bits: int) -> Value:
        return self.cast(precision=Precision(min=None, max=None, fractional_bits=fractional_bits))

    def cast(self, precision: Precision) -> Value:
        precision = self.precision.intersection(precision)
        tensor = self.tensor
        if precision.min is not None or precision.max is not None:
            tensor = torch.clamp(tensor, precision.min, precision.max)
        if precision.fractional_bits is not None:
            tensor = BitRoundFunction.apply(tensor, precision.fractional_bits)
        return Value(tensor=tensor, precision=precision)

    def round_half_up(self) -> Value:
        return Value(tensor=torch.floor(self.tensor + 0.5), precision=self.precision.round_half_up())

    def conv2d(
        self, weight: Value, stride: int | tuple[int, int], padding: int | tuple[int, int], groups: int
    ) -> Value:
        return Value(
            tensor=F.conv2d(
                self.tensor,
                weight=weight.to_exportable(device=self.tensor.device).tensor,
                stride=stride,
                padding=padding,
                groups=groups,
            ),
            precision=self.precision.conv2d(weight_shape=weight.tensor.shape, weight_precision=weight.precision),
        )

    def space_to_depth(self, block_size: int) -> Value:
        return Value(tensor=_SpaceToDepthFunction.apply(self.tensor, block_size), precision=self.precision)

    def to_exportable(self, device: torch.device) -> Value:
        return Value(tensor=to_exportable_tensor(self.tensor, device=device), precision=self.precision)

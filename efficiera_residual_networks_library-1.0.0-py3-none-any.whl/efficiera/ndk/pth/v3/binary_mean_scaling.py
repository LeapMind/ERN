from __future__ import annotations

import torch

from efficiera.ndk.pth.quantizers import BinaryMeanScaling as v2_BinaryMeanScaling
from efficiera.ndk.pth.quantizers import _binarize
from efficiera.ndk.pth.v3.evaluand import Evaluand
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantary_module import QuantaryModule
from efficiera.ndk.pth.v3.quantum import Quantum


class BinaryMeanScaling(QuantaryModule):
    """Binary mean scaling quantizer.
    This quantization creates a binary mean scaling quantizer.

    This method is `DoReFa-Net`_ weight quantization.

    .. _DoReFa-Net:
        https://arxiv.org/abs/1606.06160

    Args:
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation
    """

    def __init__(self, delta: float = 0.0) -> None:
        super().__init__()
        self._v2 = v2_BinaryMeanScaling(delta=delta)

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self._v2.delta != 0.0:
            kwargs.update(delta=self._v2.delta)
        return get_repr(self, **kwargs)

    def forward(self, input: torch.Tensor) -> Quantum:
        trainand = self._v2(input)
        evaluand = Evaluand.quantize(_binarize(input), precision=Precision.binary)
        scaling_factor = input.abs().mean()
        evaluand = evaluand.fold_multiplying(scaling_factor)
        return Quantum(trainand=trainand, evaluand=evaluand)

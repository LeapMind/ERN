from __future__ import annotations

import torch

from efficiera.ndk.pth.v3.quantary_module import QuantaryModule
from efficiera.ndk.pth.v3.quantum import Quantum


class Quantize(QuantaryModule):
    def forward(self, input: torch.Tensor) -> Quantum:
        return Quantum.quantize(input)

from __future__ import annotations

from typing import Any

import torch


class ClampFunction(torch.autograd.Function):
    @staticmethod
    def symbolic(g: Any, x: Any, min: Any, max: Any) -> Any:
        min = g.constant(min, [1], "float")
        max = g.constant(max, [1], "float")
        return g.op("Clip", x, min, max)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, min: float | None, max: float | None) -> torch.Tensor:
        ctx.save_for_backward(x)
        ctx.other = min, max
        return torch.clamp(x, min=min, max=max)

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None, None]:
        (x,) = ctx.saved_tensors
        min, max = ctx.other
        grad_input = grad_output
        if min is not None:
            grad_input = torch.where(x < min, 0.0, grad_input)
        if max is not None:
            grad_input = torch.where(x > max, 0.0, grad_input)
        return grad_input, None, None

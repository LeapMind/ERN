from __future__ import annotations

from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class FuseLinear(UnaryQuantalModule):
    def __init__(
        self, scale_precision: Precision = Precision.float, bias_precision: Precision = Precision.float
    ) -> None:
        super().__init__()
        self.scale_precision = scale_precision
        self.bias_precision = bias_precision

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self.scale_precision != Precision.float:
            kwargs.update(scale_precision=self.scale_precision)
        if self.bias_precision != Precision.float:
            kwargs.update(bias_precision=self.bias_precision)
        return get_repr(self, **kwargs)

    def forward(self, quantum: Quantum) -> Quantum:
        quantum = quantum.start_fusing_linear(scale_precision=self.scale_precision, bias_precision=self.bias_precision)
        quantum = quantum.end_fusing()
        return quantum

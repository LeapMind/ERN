import torch.nn as nn

from efficiera.ndk.pth.v3.quantum import Quantum


class BinaryQuantalModule(nn.Module):
    def __call__(self, input1: Quantum, input2: Quantum) -> Quantum:
        return super().__call__(input1, input2)

    def forward(self, input1: Quantum, input2: Quantum) -> Quantum:
        return super().forward(input1, input2)

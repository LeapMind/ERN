from __future__ import annotations

from typing import Any

import torch


class ActivationMultiplyFunction(torch.autograd.Function):
    @staticmethod
    def symbolic(g: Any, x: Any, positive_slope: torch.Value, negative_slope: Any) -> Any:
        return g.op("lm::ActivationMul", x, positive_slope, negative_slope)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, positive_slope: torch.Tensor, negative_slope: torch.Tensor) -> torch.Tensor:
        ctx.save_for_backward(x, positive_slope, negative_slope)
        x = x * torch.where(x >= 0.0, positive_slope, negative_slope)
        return x

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        x, positive_slope, negative_slope = ctx.saved_tensors
        grad_input = grad_output * torch.where(x >= 0.0, positive_slope, negative_slope)
        grad_positive_slope = torch.where(x >= 0.0, x, torch.zeros_like(positive_slope))
        grad_negative_slope = torch.where(x >= 0.0, torch.zeros_like(negative_slope), x)
        return grad_input, grad_positive_slope, grad_negative_slope

from __future__ import annotations

from collections.abc import Callable
import functools
import operator
from typing import TypeVar
import unittest

import numpy as np
from numpy.testing import assert_allclose, assert_array_compare
import torch

from efficiera.ndk.pth.v3.bit_round import bit_round
from efficiera.ndk.pth.v3.custom_typing import ArrayLike
from efficiera.ndk.pth.v3.evaluand import Evaluand
from efficiera.ndk.pth.v3.expression import Expression
from efficiera.ndk.pth.v3.fuser_for_evaluand import FuserForEvaluand
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.value import Value

_AssertionT = TypeVar("_AssertionT", bound="Callable[..., None]")


def atomic_assertion(assertion: _AssertionT) -> _AssertionT:
    return functools.wraps(assertion)(
        eval(
            "lambda *args, **kwargs: assertion(*args, **kwargs)",
            {**globals(), "assertion": assertion, "__unittest": True},
        )
    )


class TestCase(unittest.TestCase):
    def assertQuantumEqual(self, first: Quantum, second: Quantum, msg: str | None = None) -> None:
        self.assertQuantumValidation(first)
        self.assertQuantumValidation(second)
        self.assertAllClose(first.trainand, second.trainand, msg=msg)
        self.assertEvaluandEqual(first.evaluand, second.evaluand, msg=msg)

    def assertQuantumValidation(self, quantum: Quantum, msg: str | None = None) -> None:
        self.assertTrue(torch.is_floating_point(quantum.trainand), msg=msg)
        self.assertValueValidation(quantum.evaluand.value, msg=msg)

    def assertEvaluandEqual(self, first: Evaluand, second: Evaluand, msg: str | None = None) -> None:
        self.assertValueEqual(first.value, second.value, msg=msg)
        self.assertExpressionEqual(first.expression, second.expression, msg=msg)
        self.assertFuserForEvaluandEqual(first.fuser, second.fuser, msg=msg)

    @atomic_assertion
    def assertFuserForEvaluandEqual(
        self, first: FuserForEvaluand | None, second: FuserForEvaluand | None, msg: str | None = None
    ) -> None:
        self.assertEqual(first, second, msg=msg)

    def assertExpressionEqual(self, first: Expression, second: Expression, msg: str | None = None) -> None:
        self.assertAllClose(
            first.positive_slope, second.positive_slope, rtol=Expression.rtol, atol=Expression.atol, msg=msg
        )
        self.assertAllClose(
            first.negative_slope, second.negative_slope, rtol=Expression.rtol, atol=Expression.atol, msg=msg
        )
        self.assertAllClose(first.bias, second.bias, rtol=Expression.rtol, atol=Expression.atol, msg=msg)

    def assertValueEqual(self, first: Value, second: Value, msg: str | None = None) -> None:
        self.assertValueValidation(first, msg=msg)
        self.assertValueValidation(second, msg=msg)
        self.assertAllEqual(first.tensor, second.tensor, msg=msg)
        self.assertPrecisionEqual(first.precision, second.precision, msg=msg)

    def assertValueValidation(self, value: Value, msg: str | None = None) -> None:
        self.assertTrue(torch.is_floating_point(value.tensor), msg=msg)
        if value.precision.fractional_bits is not None:
            self.assertAllEqual(value.tensor, bit_round(value.tensor, value.precision.fractional_bits), msg=msg)
        if value.precision.min is not None:
            self.assertAllGreaterOrClose(value.tensor, value.precision.min, msg=msg)
        if value.precision.max is not None:
            self.assertAllLessOrClose(value.tensor, value.precision.max, msg=msg)

    def assertPrecisionEqual(self, first: Precision, second: Precision, msg: str | None = None) -> None:
        self.assertEqual(first.fractional_bits, second.fractional_bits, msg=msg)
        self.assertEqual(first.min, second.min, msg=msg)
        self.assertEqual(first.max, second.max, msg=msg)

    @atomic_assertion
    def assertAllClose(
        self,
        first: ArrayLike,
        second: ArrayLike,
        rtol: float = 1e-5,
        atol: float = 1e-8,
        equal_nan: bool = False,
        msg: str | None = None,
        verbose: bool = True,
    ) -> None:
        if isinstance(first, torch.Tensor):
            first = first.detach().numpy()
        if isinstance(second, torch.Tensor):
            second = second.detach().numpy()
        if msg is None:
            msg = ""
        assert_allclose(first, second, rtol=rtol, atol=atol, equal_nan=equal_nan, err_msg=msg, verbose=verbose)

    @atomic_assertion
    def assertAllEqual(
        self, first: ArrayLike, second: ArrayLike, equal_nan: bool = False, msg: str | None = None, verbose: bool = True
    ) -> None:
        if isinstance(first, torch.Tensor):
            first = first.detach().numpy()
        if isinstance(second, torch.Tensor):
            second = second.detach().numpy()
        if msg is None:
            msg = ""
        assert_array_compare(
            operator.eq,
            first,
            second,
            err_msg=msg,
            verbose=verbose,
            header="Arrays are not equal",
            equal_nan=equal_nan,
        )

    @atomic_assertion
    def assertAllGreaterOrClose(
        self,
        first: ArrayLike,
        second: ArrayLike,
        rtol: float = 1e-5,
        atol: float = 1e-8,
        equal_nan: bool = False,
        msg: str | None = None,
        verbose: bool = True,
    ) -> None:
        if isinstance(first, torch.Tensor):
            first = first.detach().numpy()
        if isinstance(second, torch.Tensor):
            second = second.detach().numpy()
        if msg is None:
            msg = ""

        def compare(x: np.ndarray, y: np.ndarray) -> np.ndarray:
            return np.logical_or(np.greater(x, y), np.isclose(x, y, rtol=rtol, atol=atol))

        assert_array_compare(
            compare,
            first,
            second,
            err_msg=msg,
            verbose=verbose,
            header=f"Not greater or equal to tolerance rtol={rtol:g}, atol={atol:g}",
            equal_nan=equal_nan,
        )

    @atomic_assertion
    def assertAllLessOrClose(
        self,
        first: ArrayLike,
        second: ArrayLike,
        rtol: float = 1e-5,
        atol: float = 1e-8,
        equal_nan: bool = False,
        msg: str | None = None,
        verbose: bool = True,
    ) -> None:
        if isinstance(first, torch.Tensor):
            first = first.detach().numpy()
        if isinstance(second, torch.Tensor):
            second = second.detach().numpy()
        if msg is None:
            msg = ""

        def compare(x: np.ndarray, y: np.ndarray) -> np.ndarray:
            return np.logical_or(np.less(x, y), np.isclose(x, y, rtol=rtol, atol=atol))

        assert_array_compare(
            compare,
            first,
            second,
            err_msg=msg,
            verbose=verbose,
            header=f"Not greater or equal to tolerance rtol={rtol:g}, atol={atol:g}",
            equal_nan=equal_nan,
        )

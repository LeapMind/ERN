import torch
import torch.nn as nn

from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class ReLU(UnaryQuantalModule):
    """Applies the rectified linear unit function element-wise"""

    def __init__(self) -> None:
        super().__init__()
        self._nn = nn.ReLU()

    def __repr__(self) -> str:
        return get_repr(self)

    def forward(self, x: Quantum) -> Quantum:
        return Quantum(
            trainand=self._nn(x.trainand),
            evaluand=x.evaluand.fold_activation_multiplying(
                positive_slope=torch.tensor(1.0), negative_slope=torch.tensor(0.0)
            ),
        )

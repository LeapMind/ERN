import torch
import torch.nn as nn

from efficiera.ndk.pth.v3.quantum import Quantum


class DequantaryModule(nn.Module):
    def __call__(self, input: Quantum) -> torch.Tensor:
        return super().__call__(input)

    def forward(self, input: Quantum) -> torch.Tensor:
        return super().forward(input)

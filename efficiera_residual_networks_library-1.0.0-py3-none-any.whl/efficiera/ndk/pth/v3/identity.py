from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class Identity(UnaryQuantalModule):
    r"""A placeholder identity operator that is argument-insensitive."""

    def forward(self, input: Quantum) -> Quantum:
        return input

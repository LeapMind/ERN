from __future__ import annotations

from collections.abc import Callable

import torch

from efficiera.ndk.pth.v3.batchnorm2d import BatchNorm2d
from efficiera.ndk.pth.v3.cast import Cast
from efficiera.ndk.pth.v3.conv2d import Conv2d
from efficiera.ndk.pth.v3.fuse_activation import FuseActivation
from efficiera.ndk.pth.v3.fuse_linear import FuseLinear
from efficiera.ndk.pth.v3.identity import Identity
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantary_module import QuantaryModule
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class Conv2dBlock(UnaryQuantalModule):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        stride: int | tuple[int, int] = 1,
        padding: int | tuple[int, int] = 1,
        groups: int = 1,
        weight_quantizer: Callable[[], QuantaryModule] | QuantaryModule | None = None,
        conv_weight_initializer: Callable[[torch.Tensor], object] | None = None,
        conv_output_precision: Precision = Precision.float,
        skip_bn: bool = False,
        bn_momentum: float = 0.9999,
        bn_weight_initializer: Callable[[torch.Tensor], object] | None = None,
        bn_bias_initializer: Callable[[torch.Tensor], object] | None = None,
        linear_scale_precision: Precision = Precision.float,
        linear_bias_precision: Precision = Precision.float,
        linear_output_precision: Precision = Precision.float,
        activation: Callable[[], UnaryQuantalModule] | UnaryQuantalModule | None = None,
        activation_positive_slope_precision: Precision = Precision.float,
        activation_negative_slope_precision: Precision = Precision.float,
        activation_bias_precision: Precision = Precision.float,
        activation_quantizer: Callable[[], UnaryQuantalModule] | UnaryQuantalModule | None = None,
    ) -> None:
        super().__init__()
        self.conv = Conv2d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            groups=groups,
            weight_quantizer=weight_quantizer,
            weight_initializer=conv_weight_initializer,
        )
        self.cast_after_conv = Cast(conv_output_precision)
        if skip_bn:
            bn: Identity | BatchNorm2d = Identity()
        else:
            bn = BatchNorm2d(
                out_channels,
                momentum=bn_momentum,
                weight_initializer=bn_weight_initializer,
                bias_initializer=bn_bias_initializer,
            )
        self.bn = bn
        self.fuse_linear = FuseLinear(scale_precision=linear_scale_precision, bias_precision=linear_bias_precision)
        self.cast_after_fusing_linear = Cast(linear_output_precision)
        if activation is None:
            activation = Identity()
        elif not isinstance(activation, UnaryQuantalModule):
            activation = activation()
        self.activation = activation
        self.fuse_activation = FuseActivation(
            positive_slope_precision=activation_positive_slope_precision,
            negative_slope_precision=activation_negative_slope_precision,
            bias_precision=activation_bias_precision,
            quantizer=activation_quantizer,
        )

    def forward(self, x: Quantum) -> Quantum:
        x = self.conv(x)
        x = self.cast_after_conv(x)
        x = self.bn(x)
        x = self.fuse_linear(x)
        x = self.cast_after_fusing_linear(x)
        x = self.activation(x)
        x = self.fuse_activation(x)
        return x

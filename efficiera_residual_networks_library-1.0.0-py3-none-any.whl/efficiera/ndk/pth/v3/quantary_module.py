import torch
import torch.nn as nn

from efficiera.ndk.pth.v3.quantum import Quantum


class QuantaryModule(nn.Module):
    def __call__(self, input: torch.Tensor) -> Quantum:
        return super().__call__(input)

    def forward(self, input: torch.Tensor) -> Quantum:
        return super().forward(input)

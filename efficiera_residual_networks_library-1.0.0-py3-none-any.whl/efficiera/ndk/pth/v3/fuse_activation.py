from __future__ import annotations

from collections.abc import Callable

from efficiera.ndk.pth.v3.end_fusing import EndFusing
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class FuseActivation(UnaryQuantalModule):
    def __init__(
        self,
        positive_slope_precision: Precision = Precision.float,
        negative_slope_precision: Precision = Precision.float,
        bias_precision: Precision = Precision.float,
        quantizer: UnaryQuantalModule | Callable[[], UnaryQuantalModule] | None = None,
    ) -> None:
        super().__init__()
        self.positive_slope_precision = positive_slope_precision
        self.negative_slope_precision = negative_slope_precision
        self.bias_precision = bias_precision
        if quantizer is None:
            quantizer = EndFusing()
        elif not isinstance(quantizer, UnaryQuantalModule):
            quantizer = quantizer()
        self.quantizer = quantizer

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self.positive_slope_precision != Precision.float:
            kwargs.update(positive_slope_precision=self.positive_slope_precision)
        if self.negative_slope_precision != Precision.float:
            kwargs.update(negative_slope_precision=self.negative_slope_precision)
        if self.bias_precision != Precision.float:
            kwargs.update(bias_precision=self.bias_precision)
        if not isinstance(self.quantizer, EndFusing):
            kwargs.update(quantizer=self.quantizer)
        return get_repr(self, **kwargs)

    def forward(self, quantum: Quantum) -> Quantum:
        quantum = quantum.start_fusing_activation(
            positive_slope_precision=self.positive_slope_precision,
            negative_slope_precision=self.negative_slope_precision,
            bias_precision=self.bias_precision,
        )
        quantum = self.quantizer(quantum)
        return quantum

from __future__ import annotations

import torch

from efficiera.ndk.pth.v3.dequantary_module import DequantaryModule
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.quantum import Quantum


class Dequantize(DequantaryModule):
    def __repr__(self) -> str:
        return get_repr(self)

    def forward(self, input: Quantum) -> torch.Tensor:
        return input.dequantize(training=self.training)

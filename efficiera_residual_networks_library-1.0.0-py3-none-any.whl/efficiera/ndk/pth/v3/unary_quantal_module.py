import torch.nn as nn

from efficiera.ndk.pth.v3.quantum import Quantum


class UnaryQuantalModule(nn.Module):
    def __call__(self, input: Quantum) -> Quantum:
        return super().__call__(input)

    def forward(self, input: Quantum) -> Quantum:
        return super().forward(input)

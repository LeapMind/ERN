from __future__ import annotations

import builtins
from dataclasses import dataclass
import math
from typing import ClassVar

import torch

from efficiera.ndk.pth.v3.bit_round import bit_round
from efficiera.ndk.pth.v3.get_repr import get_repr


@dataclass(frozen=True)
class Precision:
    min: float | None = None
    max: float | None = None
    fractional_bits: int | None = None

    binary: ClassVar[Precision]
    uint8: ClassVar[Precision]
    float: ClassVar[Precision]

    @classmethod
    def get_fixed(cls, is_signed: bool, integer_bits: int, fractional_bits: int = 0) -> Precision:
        if is_signed:
            min = -(2.0**integer_bits)
        else:
            min = 0.0
        max = (2.0 ** (integer_bits + fractional_bits) - 1) * 2.0**-fractional_bits
        return Precision(min=min, max=max, fractional_bits=fractional_bits)

    @classmethod
    def from_dtype(cls, dtype: torch.dtype) -> Precision:
        if dtype.is_complex:
            raise ValueError
        if dtype.is_floating_point:
            return Precision.float
        iinfo = torch.iinfo(dtype)
        return Precision(min=iinfo.min, max=iinfo.max, fractional_bits=0)

    def __post_init__(self) -> None:
        if self.min is not None and self.max is not None and self.min > self.max:
            raise ValueError
        if self.fractional_bits is not None:
            if self.min is not None and self.min != bit_round(self.min, fractional_bits=self.fractional_bits):
                raise ValueError
            if self.max is not None and self.max != bit_round(self.max, fractional_bits=self.fractional_bits):
                raise ValueError

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self.min is not None:
            kwargs.update(min=self.min)
        if self.max is not None:
            kwargs.update(max=self.max)
        if self.fractional_bits is not None:
            kwargs.update(fractional_bits=self.fractional_bits)
        return get_repr(self, **kwargs)

    def __pos__(self) -> Precision:
        return self

    def __neg__(self) -> Precision:
        if self.min is not None:
            max = -self.min
        else:
            max = None
        if self.max is not None:
            min = -self.max
        else:
            min = None
        return Precision(min=min, max=max, fractional_bits=self.fractional_bits)

    def __add__(self, other: Precision) -> Precision:
        if self.min is not None and other.min is not None:
            min = self.min + other.min
        else:
            min = None
        if self.max is not None and other.max is not None:
            max = self.max + other.max
        else:
            max = None
        if self.fractional_bits is not None and other.fractional_bits is not None:
            fractional_bits = builtins.max(self.fractional_bits, other.fractional_bits)
        else:
            fractional_bits = None
        return Precision(min=min, max=max, fractional_bits=fractional_bits)

    def __sub__(self, other: Precision) -> Precision:
        if self.min is not None and other.max is not None:
            min = self.min - other.max
        else:
            min = None
        if self.max is not None and other.min is not None:
            max = self.max - other.min
        else:
            max = None
        if self.fractional_bits is not None and other.fractional_bits is not None:
            fractional_bits = builtins.max(self.fractional_bits, other.fractional_bits)
        else:
            fractional_bits = None
        return Precision(min=min, max=max, fractional_bits=fractional_bits)

    def __mul__(self, other: Precision) -> Precision:
        if self.min is not None and self.max is not None and other.min is not None and other.max is not None:
            min = builtins.min(self.min * other.max, self.max * other.min)
            max = builtins.max(self.min * other.min, self.max * other.max)
        else:
            min = None
            max = None
        if self.fractional_bits is not None and other.fractional_bits is not None:
            fractional_bits = self.fractional_bits + other.fractional_bits
        else:
            fractional_bits = None
        return Precision(min=min, max=max, fractional_bits=fractional_bits)

    def activation_multiply(
        self, positive_slope_precision: Precision, negative_slope_precision: Precision
    ) -> Precision:
        return self * positive_slope_precision.union(negative_slope_precision)

    def union(self, other: Precision) -> Precision:
        if self.min is not None and other.min is not None:
            min = builtins.min(self.min, other.min)
        else:
            min = None
        if self.max is not None and other.max is not None:
            max = builtins.max(self.max, other.max)
        else:
            max = None
        if self.fractional_bits is not None and other.fractional_bits is not None:
            fractional_bits = builtins.max(self.fractional_bits, other.fractional_bits)
        else:
            fractional_bits = None
        return Precision(min=min, max=max, fractional_bits=fractional_bits)

    def clamp(self, min: builtins.float | None, max: builtins.float | None) -> Precision:
        return self.intersection(Precision(min=min, max=max, fractional_bits=None))

    def bit_round(self, fractional_bits: int) -> Precision:
        return self.intersection(Precision(min=None, max=None, fractional_bits=fractional_bits))

    def intersection(self, other: Precision) -> Precision:
        if self.min is None:
            min = other.min
        elif other.min is None:
            min = self.min
        else:
            min = builtins.max(self.min, other.min)
        if self.max is None:
            max = other.max
        elif other.max is None:
            max = self.max
        else:
            max = builtins.min(self.max, other.max)
        if self.fractional_bits is None:
            fractional_bits = other.fractional_bits
        elif other.fractional_bits is None:
            fractional_bits = self.fractional_bits
        else:
            fractional_bits = builtins.min(self.fractional_bits, other.fractional_bits)
        if fractional_bits is not None:
            if min is not None:
                min = bit_round(min, fractional_bits=fractional_bits)
            if max is not None:
                max = bit_round(max, fractional_bits=fractional_bits)
        return Precision(min=min, max=max, fractional_bits=fractional_bits)

    def round_half_up(self) -> Precision:
        if self.min is not None:
            min = math.floor(self.min + 0.5)
        else:
            min = None
        if self.max is not None:
            max = math.floor(self.max + 0.5)
        else:
            max = None
        if self.fractional_bits is not None:
            fractional_bits = builtins.min(self.fractional_bits, 0)
        else:
            fractional_bits = 0
        return Precision(min=min, max=max, fractional_bits=fractional_bits)

    def conv2d(self, weight_shape: tuple[int, ...], weight_precision: Precision) -> Precision:
        if len(weight_shape) != 4:
            raise ValueError
        prod = weight_shape[1] * weight_shape[2] * weight_shape[3]
        return self * weight_precision * Precision(min=prod, max=prod, fractional_bits=0)


Precision.binary = Precision(min=-1, max=1, fractional_bits=0)
binary = Precision.binary
Precision.uint8 = Precision.get_fixed(is_signed=False, integer_bits=8, fractional_bits=0)
uint8 = Precision.uint8
Precision.float = Precision(min=None, max=None, fractional_bits=None)
float = Precision.float
get_fixed = Precision.get_fixed

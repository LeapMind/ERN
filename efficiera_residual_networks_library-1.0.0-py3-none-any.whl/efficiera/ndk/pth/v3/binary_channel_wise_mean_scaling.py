from __future__ import annotations

import torch

from efficiera.ndk.pth.quantizers import BinaryChannelWiseMeanScaling as v2_BinaryChannelWiseMeanScaling
from efficiera.ndk.pth.quantizers import _binarize
from efficiera.ndk.pth.v3.evaluand import Evaluand
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantary_module import QuantaryModule
from efficiera.ndk.pth.v3.quantum import Quantum


class BinaryChannelWiseMeanScaling(QuantaryModule):
    """Binary channel wise mean scaling quantizer.
    This quantization creates a binary channel wise mean scaling quantizer.

    This method is varient of `XNOR-Net`_ weight quantization, the difference from `XNOR-Net`_ is
    backward function.

    .. _XNOR-Net:
        https://arxiv.org/abs/1603.05279

    Args:
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation
    """

    def __init__(self, delta: float = 0.0) -> None:
        super().__init__()
        self._v2 = v2_BinaryChannelWiseMeanScaling(delta=delta)

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self._v2.delta != 0.0:
            kwargs.update(delta=self._v2.delta)
        return get_repr(self, **kwargs)

    def forward(self, input: torch.Tensor) -> Quantum:
        trainand = self._v2(input)
        evaluand = Evaluand.quantize(_binarize(input), precision=Precision.binary)
        # HACK: The scaling factor's shape [out_ch, 1, 1, 1] is not supported, so changed to [out_ch].
        scaling_factor = input.abs().mean(dim=(1, 2, 3))
        evaluand = evaluand.fold_multiplying(scaling_factor)
        return Quantum(trainand=trainand, evaluand=evaluand)

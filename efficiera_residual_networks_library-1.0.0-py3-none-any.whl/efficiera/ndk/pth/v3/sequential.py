from __future__ import annotations

from collections.abc import Iterator
from typing import overload

import torch.nn as nn

from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class Sequential(UnaryQuantalModule):
    """A sequential container."""

    def __init__(self, *args: UnaryQuantalModule) -> None:
        super().__init__()
        self._nn = nn.Sequential(*args)

    def __repr__(self) -> str:
        return self._nn.__repr__()

    def __iter__(self) -> Iterator[UnaryQuantalModule]:
        return iter(self._nn)

    @overload
    def __getitem__(self, idx: int) -> UnaryQuantalModule:
        ...

    @overload
    def __getitem__(self, idx: slice) -> Sequential:
        ...

    def __getitem__(self, idx: int | slice) -> UnaryQuantalModule | Sequential:
        if isinstance(idx, slice):
            return Sequential(self._nn[idx])
        return self._nn[idx]

    def __len__(self) -> int:
        return len(self._nn)

    def forward(self, input: Quantum) -> Quantum:
        return self._nn(input)

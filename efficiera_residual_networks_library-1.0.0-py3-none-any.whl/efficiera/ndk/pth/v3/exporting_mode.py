from __future__ import annotations

from collections.abc import Iterator
from contextlib import AbstractContextManager, contextmanager
from contextvars import ContextVar
from typing import ClassVar


class ExportingMode:
    _depth: ClassVar[ContextVar[int]] = ContextVar("_depth", default=0)

    @classmethod
    def get(cls) -> bool:
        return cls._depth.get() > 0

    @classmethod
    def set(cls) -> AbstractContextManager[None]:
        cls._depth.set(cls._depth.get() + 1)

        @contextmanager
        def resetter() -> Iterator[None]:
            yield
            cls.reset()

        return resetter()

    @classmethod
    def reset(cls) -> None:
        cls._depth.set(cls._depth.get() - 1)

from __future__ import annotations

from typing import overload

import torch


@overload
def bit_round(x: int, fractional_bits: int) -> int:
    ...


@overload
def bit_round(x: float, fractional_bits: int) -> float:
    ...


@overload
def bit_round(x: torch.Tensor, fractional_bits: int) -> torch.Tensor:
    ...


def bit_round(x: int | float | torch.Tensor, fractional_bits: int) -> int | float | torch.Tensor:
    """Round to even in binary digits

    Args:
        x (int | float | torch.Tensor): An input
        fractional_bits (int): The number of digits in binary to be rounded. If it's zero, round to an integer. If it's
            positive, round to the corresponding binary digits.
    Returns:
        int | float | torch.Tensor: A result. The type is the same as the input.
    """
    if fractional_bits < 0:
        raise ValueError(f"fractional_bits must be 0 or greater but got {fractional_bits}.")
    if isinstance(x, float):
        x = x * 2.0**fractional_bits
        x = round(x)
        x = x / 2.0**fractional_bits
        return x
    if isinstance(x, int):
        return x
    if torch.is_complex(x):
        raise ValueError("The first argument must not be complex tensor.")
    if torch.is_floating_point(x):
        dtype = x.dtype
        x = x.to(dtype=torch.float32)
        x = x * 2.0**fractional_bits
        x = torch.round(x)
        x = x / 2.0**fractional_bits
        x = x.to(dtype=dtype)
        return x
    return x

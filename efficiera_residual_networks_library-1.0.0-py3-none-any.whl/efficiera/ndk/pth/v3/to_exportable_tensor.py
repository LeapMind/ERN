from __future__ import annotations

import torch

from efficiera.ndk.pth.v3.exporting_mode import ExportingMode


def to_exportable_tensor(tensor: torch.Tensor, device: torch.device) -> torch.Tensor:
    if ExportingMode.get():
        return torch.tensor(tensor.detach().cpu().numpy(), device=device)
    return tensor.to(device=device)

from __future__ import annotations

from collections.abc import Callable

import torch
import torch.nn as nn

from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class BatchNorm2d(UnaryQuantalModule):
    """Batch normalization 2d.

    Args:
        num_features (int): ``C`` from an expected input of size ``(N, C, H, W)``
        momentum (float optional): the value used for the running_mean and running_var computation. Can be set to
            ``None`` for cumulative moving average (i.e. simple average). Defaults to  ``0.1``
        weight_initializer (Callable[[torch.Tensor], None] | None, optional): Initializer for the batch normalization
            weight. Defaults to ``None``
        bias_initializer (Callable[[torch.Tensor], None] | None, optional): Initializer for the batch normalization
            bias. Defaults to ``None``
    """

    def __init__(
        self,
        num_features: int,
        momentum: float = 0.1,
        weight_initializer: Callable[[torch.Tensor], object] | None = None,
        bias_initializer: Callable[[torch.Tensor], object] | None = None,
    ) -> None:
        super().__init__()
        self._nn = nn.BatchNorm2d(num_features, momentum=momentum)
        if weight_initializer is not None:
            with torch.no_grad():
                weight_initializer(self._nn.weight)
        self.weight_initializer = weight_initializer
        if bias_initializer is not None:
            with torch.no_grad():
                bias_initializer(self._nn.bias)
        self.bias_initializer = bias_initializer

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self._nn.momentum != 0.1:
            kwargs.update(momentum=self._nn.momentum)
        if self.weight_initializer is not None:
            kwargs.update(weight_initializer=self.weight_initializer)
        if self.bias_initializer is not None:
            kwargs.update(bias_initializer=self.bias_initializer)
        return get_repr(self, self._nn.num_features, **kwargs)

    def forward(self, input: Quantum) -> Quantum:
        if self.training:
            mean = torch.mean(input.trainand, dim=(0, 2, 3))
            var = torch.var(input.trainand, dim=(0, 2, 3), unbiased=False)
        else:
            assert self._nn.running_mean is not None
            assert self._nn.running_var is not None
            mean = self._nn.running_mean
            var = self._nn.running_var
        scale = self._nn.weight / torch.sqrt(var + self._nn.eps)
        bias = self._nn.bias - mean * scale
        trainand = self._nn(input.trainand)
        evaluand = input.evaluand.fold_multiplying(scale)
        evaluand = evaluand.fold_adding(bias)
        return Quantum(trainand=trainand, evaluand=evaluand)

from __future__ import annotations

from collections.abc import Callable
from logging import getLogger
import os
from os import PathLike
from pathlib import Path

import numpy as np
import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only
import torch
import torch.nn as nn
from typing_extensions import TypedDict

from efficiera.ndk.pth.v3.exporting_mode import ExportingMode

_logger = getLogger(__name__)


class ExportOnnxFileResult(TypedDict):
    """Dict for ONNX file export results: a directory to onnx file, debug inputs and outputs npy file."""

    onnx: str
    inputs: list[str]
    outputs: list[str]
    float_input: bool


def _tensor_to_numpy(tensor: torch.Tensor) -> np.ndarray:
    """Convert torch.Tensor to numpy array.
    Because torch.Tensor stores data in NCHW format while numpy array store data in NHWC format.
    This function will convert an input to NHWC format automatically, if the input tensor is in NCHW format.

    Args:
        tensor (torch.Tensor): A tensor to be converted to array

    Returns:
        numpy.ndarray: An output array. If the input_tensor is in NCHW format, the data format is automatically converted to NWHC format. Otherwise, dimension remains.
    """  # NOQA: E501
    array = tensor.cpu().numpy()
    if len(array.shape) == 4:
        array = np.transpose(array, [0, 2, 3, 1])
    return array


def _prepare_debug_files(
    path: Path,
    name: str,
    input_tensor: list[torch.Tensor] | torch.Tensor,
    output_tensor: list[torch.Tensor] | torch.Tensor,
) -> tuple[list[str], list[str]]:
    """Generate input and output npy file for debugging purpose

    Args:
        path (Path): Output directory for debug npy files
        input_tensor (list[torch.Tensor] | torch.Tensor): An input tensor or list of input tensors to be used for debugging.
            If it is in NCHW format, it will export as NHWC format.
        output_tensor (list[torch.Tensor] | torch.Tensor): An expected output tensor or list of output tensors from the network.
            If it is in NCHW format, it will export as NHWC format.

    Returns:
        input_npys (list[str]): List of debug input npy file
        output_npys (list[str]): List of expected output npy file
    """  # NOQA: E501
    path.mkdir(exist_ok=True)

    if isinstance(input_tensor, torch.Tensor):
        input_tensor = [input_tensor]

    if isinstance(output_tensor, torch.Tensor):
        output_tensor = [output_tensor]

    input_npys: list[str] = []
    output_npys: list[str] = []

    for i, tensor in enumerate(input_tensor):
        input_path = path / f"{name}_input_{i}.npy"
        np.save(input_path, _tensor_to_numpy(tensor))
        input_npys.append(os.fspath(input_path))

    for i, tensor in enumerate(output_tensor):
        output_path = path / f"{name}_output_{i}.npy"
        np.save(output_path, _tensor_to_numpy(tensor.detach()))
        output_npys.append(os.fspath(output_path))

    return input_npys, output_npys


def _prepare_intermediate_outputs(model: nn.Module) -> dict[str, torch.Tensor]:
    """Prepare a hook for each intermediate layers for intermediate layer output npy files

    Args:
        model (nn.Module): Model or operators to be added hook

    Returns:
        intermediate_outputs (dict[str, torch.Tensor]): Dictionary store output tensor from each layer
    """
    intermediate_outputs: dict[str, torch.Tensor] = {}

    def make_hook(name: str) -> Callable[[nn.Module, torch.Tensor, torch.Tensor], None]:
        def hook(model: nn.Module, input: torch.Tensor, output: torch.Tensor) -> None:
            intermediate_outputs[name] = output.detach()

        return hook

    children = list(model.named_children())
    ch = list(children[0][1].named_children())
    for child in ch:
        name = child[0]
        layer = child[1]
        layer.register_forward_hook(make_hook(name))

    return intermediate_outputs


def _save_intermediate_outputs(
    path: Path,
    name: str,
    intermediate_outputs: dict[str, torch.Tensor],
) -> None:
    """Save each intermediate layer output to npy files

    Args:
        path(Path): Output directory for exported files (default: $PWD)
        intermediate_outputs (dict[str, torch.Tensor]): Dictionary store output tensor from each layer
    """
    infer_path = path / f"{name}_layers_npy"
    infer_path.mkdir(parents=True, exist_ok=True)
    for layer in intermediate_outputs.keys():
        np.save(infer_path / f"{layer}.npy", _tensor_to_numpy(intermediate_outputs[layer]))


def export_onnx_file(
    model: nn.Module,
    input_image_size: list[int]
    | list[tuple[int, int]]
    | tuple[int, int]
    | list[tuple[int, int, int]]
    | tuple[int, int, int],
    training: bool = False,
    float_input: bool = False,
    quantize: bool = True,
    path: str | PathLike[str] = ".",
    name: str = "model",
    export_intermediate_outputs: bool = False,
    keep_model_device: bool = False,
    keep_model_training_mode: bool = False,
) -> ExportOnnxFileResult:
    """Export ONNX file, debug input and output npy files and return path of exported files.

    Args:
        model (nn.Module): Model or operators to be exported.
        input_image_size (list[int] | list[tuple[int, int]] | tuple[int, int] | list[tuple[int, int, int]] | tuple[int, int, int], optional):
            Input image size it can be a tuple of (h,w) or (c, h, w), or a list of c, (h,w) or (c, h, w). Defaults to ``(32, 32)``
        training (bool, optional): Flag for exporting training graph or inference graph. Specify ``False`` to convert to IP. Defaults to ``False``.
        float_input (bool, optional): Flag for enable float input. Defaults to ``False``
        quantize (bool, optional): Flag for if the model is quantized. Defaults to ``True``
        path (str | PathLike[str], optional): Output directory for exported files. Defaults to ``"."`` which is ``$PWD``.
        name (str, optional): Model name, use as name for exported files. Defaults to ``"model"``
        export_intermediate_outputs (bool, optional): Flag for enable the intermediate layer output npy files. Defaults to ``False``
        keep_model_device (bool, optional): Flag for kept model device unchanged.  This arg is a workaround for the model that cannot export via CPU. Defaults to ``False``
        keep_model_training_mode (bool, optional): Flag for kept model training mode unchanged. This arg is a workaround for exporting ONNX between training.  Defaults to ``False``

    Returns:
        ExportOnnxFileResult: {onnx (str): ONNX file name, inputs (list[str]): List of debug input npy file, outputs (list[str]): List of expected output npy file}
    """  # NOQA: E501
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    onnx_filename = path / f"{name}.onnx"

    # If model is on GPU and keep_model_device, input_tensors are created on the GPU.
    # Otherwise, all operations are done on CPU.
    _device = torch.device("cpu")
    if keep_model_device:
        try:
            _device = next(model.parameters()).device
        except StopIteration:
            pass
    else:
        model.cpu()

    _kept_training = model.training
    model.train(training)

    try:
        sizes = np.array([input_image_size]) if isinstance(input_image_size, tuple) else np.array(input_image_size)
        if len(sizes.shape) == 1 and all(isinstance(c, np.integer) for c in sizes):  # case: list[int] -> [1, c]
            input_tensors = [torch.randint(0, 256, (1, c), dtype=torch.uint8, device=_device) for c in sizes]
        elif sizes.shape[-1] == 2:  # case: list[tuple[int, int]], tuple[int, int] -> [1, 3, h, w]
            input_tensors = [torch.randint(0, 256, (1, 3, h, w), dtype=torch.uint8, device=_device) for h, w, in sizes]
        elif sizes.shape[-1] == 3:  # case:  list[tuple[int, int, int]], tuple[int, int, int] -> [1, c, h, w]
            input_tensors = [
                torch.randint(0, 256, (1, c, h, w), dtype=torch.uint8, device=_device) for c, h, w, in sizes
            ]
        else:
            raise ValueError(
                "input_image_size must be a list of int or tuple of (h, w), (c, h, w) or a list of such tuples, "
                f"but a shape of {sizes.shape} was given."
            )

        if float_input:
            input_tensors = [tensor.type(torch.float32) / 255 for tensor in input_tensors]

        if export_intermediate_outputs:
            intermediate_outputs = _prepare_intermediate_outputs(model)

        output_tensors = model.forward(*input_tensors)

        if export_intermediate_outputs:
            _save_intermediate_outputs(path, name, intermediate_outputs)
            # check model output equals to debug npy file
            assert torch.allclose(list(intermediate_outputs.items())[-1][1], output_tensors)

        if isinstance(output_tensors, torch.Tensor):
            output_tensors = [output_tensors]

        input_npys, output_npys = _prepare_debug_files(path, name, input_tensors, output_tensors)

        input_names = [f"{name}_input_{i}" for i in range(len(input_tensors))]
        output_names = [f"{name}_output_{i}" for i in range(len(output_tensors))]

        # A dictionary to indicate custom opset domain and version at export ONNX.
        # This `lm` domain custom opsets is utilized only the quantized network.
        custom_opsets = {"lm": 2} if quantize else None
        with ExportingMode.set():
            torch.onnx.export(
                model,
                tuple(input_tensors),
                onnx_filename,
                training=torch._C._onnx.TrainingMode.PRESERVE,  # Set this training in order to disable Conv+BN fusion
                do_constant_folding=True,
                input_names=input_names,
                output_names=output_names,
                custom_opsets=custom_opsets,
                opset_version=11,
            )
        _logger.info(f"model file is stored to {onnx_filename}")
        _logger.info(f"debug files are also stored to the directory {path}")

    finally:
        if keep_model_training_mode:
            model.train(_kept_training)

    return {"onnx": os.fspath(onnx_filename), "inputs": input_npys, "outputs": output_npys, "float_input": float_input}


class ExportOnnx(pl.Callback):
    """Callback to export the trained model to ONNX file when training is finished.

    Args:
        input_sizes (list[tuple[int, int]] | tuple[int, int]): Input image size it can be a tuple of (h, w) or (c, h, w), or a list of c, (h, w) or (c, h, w).
        training (bool, optional): Flag for exporting training graph or inference graph. Specify ``False`` to convert to IP. Defaults to ``False``.
        quantize (bool): Flag for if the model is quantized.
        dest (str | PathLike[str]): Output directory for exported files.
        name (str): Model name, use as name for exported files.
        debug (bool, optional): Flag for debug mode. when set to True, the output of the intermediate layer is output to the npy file. Defaults to ``False``
        keep_model_device (bool, optional): Flag for kept model device unchanged.  This arg is a workaround for the model that cannot export via CPU. Defaults to ``False``
    """  # NOQA: E501

    def __init__(
        self,
        input_sizes: list[tuple[int, int]] | tuple[int, int],
        training: bool = False,
        quantize: bool = True,
        dest: str | PathLike[str] = ".",
        name: str = "model",
        debug: bool = False,
        keep_model_device: bool = False,
    ) -> None:
        self._input_sizes = input_sizes
        self._training = training
        self._quantize = quantize
        self._dest = dest
        self._name = name
        self.debug = debug
        self.keep_model_device = keep_model_device

    @rank_zero_only
    def on_fit_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        export_onnx_file(
            model=pl_module,
            input_image_size=self._input_sizes,
            training=self._training,
            quantize=self._quantize,
            path=self._dest,
            name=self._name,
            export_intermediate_outputs=self.debug,
            keep_model_device=self.keep_model_device,
            keep_model_training_mode=False,
        )

from __future__ import annotations

import torch

from efficiera.ndk.pth.quantizers import BinaryPower2Scaling as v2_BinaryPower2Scaling
from efficiera.ndk.pth.quantizers import _binarize
from efficiera.ndk.pth.v3.evaluand import Evaluand
from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.precision import Precision
from efficiera.ndk.pth.v3.quantary_module import QuantaryModule
from efficiera.ndk.pth.v3.quantum import Quantum


class BinaryPower2Scaling(QuantaryModule):
    """Binary power2 scaling quantizer.
    This quantization is a weight quantizer, that addressed floating point scaling factor, e.g.,
    Binary channel wise mean scaling quantizer. If this scaling factor is represented by a power of 2,
    then it does not need to use floating-point number operations, thus it can run more efficient while
    accuracy is almost unchanged.

    Args:
        p (int, optional): Scaling factor, must be a power of 2. Defaults to ``32``
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation
    """

    def __init__(self, p: int = 32, delta: float = 0.0) -> None:
        super().__init__()
        self._v2 = v2_BinaryPower2Scaling(p=p, delta=delta)

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self._v2.p != 32:
            kwargs.update(p=self._v2.p)
        if self._v2.delta != 0.0:
            kwargs.update(delta=self._v2.delta)
        return get_repr(self, **kwargs)

    def forward(self, input: torch.Tensor) -> Quantum:
        trainand = self._v2(input)
        evaluand = Evaluand.quantize(_binarize(input), precision=Precision.binary)
        scaling_factor = torch.tensor(1.0 / self._v2.p)
        evaluand = evaluand.fold_multiplying(scaling_factor)
        return Quantum(trainand=trainand, evaluand=evaluand)

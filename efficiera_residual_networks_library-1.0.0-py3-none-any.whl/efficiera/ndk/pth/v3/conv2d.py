from __future__ import annotations

from collections.abc import Callable
from typing import cast

import torch
import torch.nn as nn

from efficiera.ndk.pth.v3.get_repr import get_repr
from efficiera.ndk.pth.v3.quantary_module import QuantaryModule
from efficiera.ndk.pth.v3.quantize import Quantize
from efficiera.ndk.pth.v3.quantum import Quantum
from efficiera.ndk.pth.v3.unary_quantal_module import UnaryQuantalModule


class Conv2d(UnaryQuantalModule):
    """Quantized convolution 2d.
    This quantization creates a convolution 2d with a quantized weight.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (int | tuple[int, int]): Size of the convolving kernel.
        stride (int | tuple[int, int], optional): Stride of the convolution. Defaults to ``1``
        padding (int | tuple[int, int], optional): Padding added to all four sides of the input. Defaults to ``0``
        groups (int, optional): Number of blocked connections from input channels to output channels. Defaults to ``1``
        weight_quantizer (nn.Module | None, optional): A quantizer for weight of convolution2d . Defaults to ``None``
        weight_initializer (Callable[[torch.Tensor], None], optional): Initializer for the convolution weight. Defaults
            to ``None``
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        stride: int | tuple[int, int] = 1,
        padding: int | tuple[int, int] = 0,
        groups: int = 1,
        weight_quantizer: Callable[[], QuantaryModule] | QuantaryModule | None = None,
        weight_initializer: Callable[[torch.Tensor], object] | None = None,
    ) -> None:
        super().__init__()
        self._nn = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            groups=groups,
            bias=False,
        )
        if weight_quantizer is None:
            weight_quantizer = Quantize()
        elif not isinstance(weight_quantizer, QuantaryModule):
            weight_quantizer = weight_quantizer()
        self.weight_quantizer = weight_quantizer
        if weight_initializer is not None:
            with torch.no_grad():
                weight_initializer(self._nn.weight)
        self.weight_initializer = weight_initializer

    def __repr__(self) -> str:
        kwargs: dict[str, object] = {}
        if self._nn.stride != (1, 1):
            kwargs.update(stride=self._nn.stride)
        if self._nn.padding != (0, 0):
            kwargs.update(padding=self._nn.padding)
        if self._nn.groups != 1:
            kwargs.update(groups=self._nn.groups)
        if not isinstance(self.weight_quantizer, Quantize):
            kwargs.update(weight_quantizer=self.weight_quantizer)
        if self.weight_initializer is not None:
            kwargs.update(weight_initializer=self.weight_initializer)
        return get_repr(
            self,
            self._nn.in_channels,
            self._nn.out_channels,
            kernel_size=self._nn.kernel_size,
            **kwargs,
        )

    def forward(self, quantum: Quantum) -> Quantum:
        weight = self.weight_quantizer(self._nn.weight)
        quantum = Quantum(
            trainand=self._nn._conv_forward(quantum.trainand, weight=weight.trainand, bias=self._nn.bias),
            evaluand=quantum.evaluand.conv2d(
                weight=weight.evaluand,
                stride=cast("tuple[int, int]", self._nn.stride),
                padding=cast("tuple[int, int]", self._nn.padding),
                groups=self._nn.groups,
            ),
        )
        return quantum

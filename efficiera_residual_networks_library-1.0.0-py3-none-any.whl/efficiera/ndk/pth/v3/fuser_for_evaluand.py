from dataclasses import dataclass

from efficiera.ndk.pth.v3.expression import Expression
from efficiera.ndk.pth.v3.value import Value


@dataclass(frozen=True)
class FuserForEvaluand:
    def fuse(self, value: Value, expression: Expression) -> Value:
        raise NotImplementedError

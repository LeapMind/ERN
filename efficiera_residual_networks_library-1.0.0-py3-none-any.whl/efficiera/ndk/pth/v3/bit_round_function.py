from __future__ import annotations

from typing import Any

import torch

from efficiera.ndk.pth.v3.bit_round import bit_round


class BitRoundFunction(torch.autograd.Function):
    @staticmethod
    def symbolic(g: Any, x: Any, fractional_bits: Any) -> Any:
        return g.op("lm::BitRound", x, fractional_bits_i=fractional_bits)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, fractional_bits: int) -> torch.Tensor:
        return bit_round(x, fractional_bits=fractional_bits)

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None]:
        return grad_output, None

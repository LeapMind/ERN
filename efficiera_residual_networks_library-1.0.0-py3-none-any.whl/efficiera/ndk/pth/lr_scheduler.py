"""``efficiera.ndk.pth.lr_scheduler`` is a package of learning rate schedulers to create models that work with Efficiera."""  # NOQA: E501

from __future__ import annotations

import logging
import math

import torch
from torch.optim.lr_scheduler import _LRScheduler

_logger = logging.getLogger(__name__)


class CosineAnnealingWithWarmupLR(_LRScheduler):
    """
    Set the learning rate of each parameter group using a cosine annealing with warmup schedule.

    Args:
        optimizer (Any): Wrapped optimizer.
        T_max (int): Number of max epochs.
        eta_min (float, optional): Minimum learning rate. Defaults to ``0``
        T_warmup (int, optional): Number of warmup epochs. Defaults to ``0``
        last_epoch (int, optional): The index of last epoch. Defaults to ``-1``
    """

    def __init__(
        self, optimizer: torch.optim.Optimizer, T_max: int, eta_min: float = 0, T_warmup: int = 0, last_epoch: int = -1
    ) -> None:
        if T_max <= T_warmup:
            _logger.error("T_warmup must be strictly less than T_max.")
            raise ValueError("T_warmup must be strictly less than T_max.")
        self.T_max = T_max
        self.T_warmup = T_warmup
        self.eta_min = eta_min

        super().__init__(optimizer, last_epoch)

    def get_lr(self) -> list[float]:  # omitted type annotation due to incomplete type information of _LRScheduler
        result = []
        for base_lr in self.base_lrs:
            last_epoch = self.last_epoch + 1
            if last_epoch < self.T_warmup:
                lr = self.eta_min + (base_lr - self.eta_min) * ((last_epoch / self.T_warmup) ** 2)
            else:
                lr = (
                    self.eta_min
                    + (base_lr - self.eta_min)
                    * (1 + math.cos(math.pi * (last_epoch - self.T_warmup) / (self.T_max - self.T_warmup)))
                    / 2
                )
            result.append(lr)
        return result

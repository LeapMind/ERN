"""``efficiera.ndk.pth.utils`` is a package that provides utility functions and callback classes."""

from __future__ import annotations

from collections.abc import Callable, Sequence
import contextlib
import csv
from dataclasses import dataclass
from logging import getLogger
from pathlib import Path
import subprocess
import sys
import tempfile
from typing import overload
import warnings

import hydra
from hydra.core.hydra_config import HydraConfig
import numpy as np
from ptflops import get_model_complexity_info
from ptflops.pytorch_ops import conv_flops_counter_hook, relu_flops_counter_hook
import pytorch_lightning as pl
from pytorch_lightning.utilities import rank_zero_only
from tabulate import tabulate
import torch
import torch.nn as nn
from typing_extensions import Literal
import yaml

from efficiera.ndk.pth.layers import QuantizableConv2d
from efficiera.ndk.pth.quantizers import HalfWaveGaussianQuantization, LearnedStepSizeQuantization

_logger = getLogger(__name__)


@dataclass
class ExportOnnxFileResult:
    """Class for ONNX file export results: a directory to onnx file, debug inputs and outputs npy file."""

    onnx: str
    inputs: list[str]
    outputs: list[str]
    float_input: bool


def _tensor_to_numpy(tensor: torch.Tensor) -> np.ndarray:
    """Convert torch.Tensor to numpy array.
    Because torch.Tensor stores data in NCHW format while numpy array store data in NHWC format.
    This function will convert an input to NHWC format automatically, if the input tensor is in NCHW format.

    Args:
        tensor (torch.Tensor): A tensor to be converted to array

    Returns:
        numpy.ndarray: An output array. If the input_tensor is in NCHW format, the data format is automatically converted to NWHC format. Otherwise, dimension remains.
    """  # NOQA: E501
    array = tensor.cpu().numpy()
    if len(array.shape) == 4:
        array = np.transpose(array, [0, 2, 3, 1])
    return array


def _prepare_debug_files(
    path: Path,
    input_tensor: list[torch.Tensor] | torch.Tensor,
    output_tensor: list[torch.Tensor] | torch.Tensor,
) -> tuple[list[str], list[str]]:
    """Generate input and output npy file for debugging purpose

    Args:
        path (Path): Output directory for debug npy files
        input_tensor (list[torch.Tensor] | torch.Tensor): An input tensor or list of input tensors to be used for debugging.
            If it is in NCHW format, it will export as NHWC format.
        output_tensor (list[torch.Tensor] | torch.Tensor): An expected output tensor or list of output tensors from the network.
            If it is in NCHW format, it will export as NHWC format.

    Returns:
        input_npys (list[str]): List of debug input npy file
        output_npys (list[str]): List of expected output npy file
    """  # NOQA: E501
    path.mkdir(exist_ok=True)

    if isinstance(input_tensor, torch.Tensor):
        input_tensor = [input_tensor]

    if isinstance(output_tensor, torch.Tensor):
        output_tensor = [output_tensor]

    input_npys: list[str] = []
    output_npys: list[str] = []

    for i, tensor in enumerate(input_tensor):
        input_path = path / f"inference_graph_input_{i}.npy"
        np.save(input_path, _tensor_to_numpy(tensor))
        input_npys.append(str(input_path))

    for i, tensor in enumerate(output_tensor):
        output_path = path / f"inference_graph_output_{i}.npy"
        np.save(output_path, _tensor_to_numpy(tensor.detach()))
        output_npys.append(str(output_path))

    return input_npys, output_npys


def _prepare_intermediate_outputs(model: torch.nn.Module) -> dict[str, torch.Tensor]:
    """Prepare a hook for each intermediate layers for intermediate layer output npy files

    Args:
        model (torch.nn.Module): Model or operators to be added hook

    Returns:
        intermediate_outputs (dict[str, torch.Tensor]): Dictionary store output tensor from each layer
    """
    intermediate_outputs: dict[str, torch.Tensor] = {}

    def make_hook(name: str) -> Callable[[nn.Module, torch.Tensor, torch.Tensor], None]:
        def hook(model: nn.Module, input: torch.Tensor, output: torch.Tensor) -> None:
            intermediate_outputs[name] = output.detach()

        return hook

    children = list(model.named_children())
    ch = list(children[0][1].named_children())
    for child in ch:
        name = child[0]
        layer = child[1]
        layer.register_forward_hook(make_hook(name))

    return intermediate_outputs


def _save_intermediate_outputs(
    path: Path,
    intermediate_outputs: dict[str, torch.Tensor],
) -> None:
    """Save each intermediate layer output to npy files

    Args:
        path(Path): Output directory for exported files (default: $PWD)
        intermediate_outputs (dict[str, torch.Tensor]): Dictionary store output tensor from each layer
    """
    infer_path = path / "layers_npy"
    infer_path.mkdir(parents=True, exist_ok=True)
    for layer in intermediate_outputs.keys():
        np.save(infer_path / f"{layer}.npy", _tensor_to_numpy(intermediate_outputs[layer]))


def export_onnx_file(
    model: torch.nn.Module,
    input_image_size: list[int]
    | list[tuple[int, int]]
    | tuple[int, int]
    | list[tuple[int, int, int]]
    | tuple[int, int, int] = (32, 32),
    float_input: bool = False,
    quantize: bool = True,
    path: str | Path = Path("."),
    model_name: str = "model",
    export_intermediate_outputs: bool = False,
    keep_model_device: bool = False,
    keep_model_training_mode: bool = False,
) -> ExportOnnxFileResult:
    """Export ONNX file, debug input and output npy files and return path of exported files.

    Args:
        model (torch.nn.Module): Model or operators to be exported.
        input_image_size (list[int] | list[tuple[int, int]] | tuple[int, int] | list[tuple[int, int, int]] | tuple[int, int, int], optional):
            Input image size it can be a tuple of (h,w) or (c, h, w), or a list of c, (h,w) or (c, h, w). Defaults to ``(32, 32)``
        float_input (bool, optional): Flag for enable float input. Defaults to ``False``
        quantize (bool, optional): Flag for if the model is quantized. Defaults to ``True``
        path (Path, optional): Output directory for exported files. Defaults to ``Path(".")`` which is ``$PWD``.
        model_name (str, optional): Model name, use as prefix for exported files. Defaults to ``"model"``
        export_intermediate_outputs (bool, optional): Flag for enable the intermediate layer output npy files. Defaults to ``False``
        keep_model_device (bool, optional): Flag for kept model device unchanged.  This arg is a workaround for the model that cannot export via CPU. Defaults to ``False``
        keep_model_training_mode (bool, optional): Flag for kept model training mode unchanged. This arg is a workaround for exporting ONNX between training.  Defaults to ``False``

    Returns:
        ExportOnnxFileResult: {onnx (str): ONNX file name, inputs (list[str]): List of debug input npy file, outputs (list[str]): List of expected output npy file}
    """  # NOQA: E501
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    onnx_filename = path / f"{model_name}.onnx"

    # If model is on GPU and keep_model_device, input_tensors are created on the GPU.
    # Otherwise, all operations are done on CPU.
    _device = torch.device("cpu")
    if keep_model_device:
        try:
            _device = next(model.parameters()).device
        except StopIteration:
            pass
    else:
        model.cpu()

    _training = model.training
    model.eval()

    try:
        sizes = np.array([input_image_size]) if isinstance(input_image_size, tuple) else np.array(input_image_size)
        if len(sizes.shape) == 1 and all(isinstance(c, np.integer) for c in sizes):  # case: list[int] -> [1, c]
            input_tensors = [torch.randint(0, 256, (1, c), dtype=torch.uint8, device=_device) for c in sizes]
        elif sizes.shape[-1] == 2:  # case: list[tuple[int, int]], tuple[int, int] -> [1, 3, h, w]
            input_tensors = [torch.randint(0, 256, (1, 3, h, w), dtype=torch.uint8, device=_device) for h, w, in sizes]
        elif sizes.shape[-1] == 3:  # case:  list[tuple[int, int, int]], tuple[int, int, int] -> [1, c, h, w]
            input_tensors = [
                torch.randint(0, 256, (1, c, h, w), dtype=torch.uint8, device=_device) for c, h, w, in sizes
            ]
        else:
            raise ValueError(
                "input_image_size must be a list of int or tuple of (h, w), (c, h, w) or a list of such tuples, "
                f"but a shape of {sizes.shape} was given."
            )

        if float_input:
            input_tensors = [tensor.type(torch.float32) / 255 for tensor in input_tensors]

        if export_intermediate_outputs:
            intermediate_outputs = _prepare_intermediate_outputs(model)

        output_tensors = model.forward(*input_tensors)

        if export_intermediate_outputs:
            _save_intermediate_outputs(path, intermediate_outputs)
            # check model output equals to debug npy file
            assert torch.allclose(list(intermediate_outputs.items())[-1][1], output_tensors)

        if isinstance(output_tensors, torch.Tensor):
            output_tensors = [output_tensors]

        input_npys, output_npys = _prepare_debug_files(path, input_tensors, output_tensors)

        input_names = [f"inference_graph_input_{i}" for i in range(len(input_tensors))]
        output_names = [f"inference_graph_output_{i}" for i in range(len(output_tensors))]

        # A dictionary to indicate custom opset domain and version at export ONNX.
        # This `lm` domain custom opsets is utilized only the quantized network.
        custom_opsets = {"lm": 2} if quantize else None

        # FIXME: Remove this hack once PyTorch is updated to v2.0 and warning have been resolved.
        # HACK: This is a workaround to suppress known warning when export the ONNX file.
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="It is recommended that constant folding be turned off")
            warnings.filterwarnings("ignore", message="The shape inference of lm::")
            warnings.filterwarnings("ignore", category=FutureWarning)
            torch.onnx.export(
                model,
                tuple(input_tensors),
                onnx_filename,
                training=torch._C._onnx.TrainingMode.PRESERVE,  # Set this training in order to disable Conv+BN fusion
                do_constant_folding=True,
                input_names=input_names,
                output_names=output_names,
                custom_opsets=custom_opsets,
                opset_version=11,
            )
        _logger.info(f"exported model onnx file is stored to {onnx_filename}")
        _logger.info(
            f"Input and output numpy files for debugging inference_image.eii are also stored to the directory {path}"
        )

    finally:
        if keep_model_training_mode:
            model.train(_training)

    return ExportOnnxFileResult(str(onnx_filename), input_npys, output_npys, float_input)


class ExportOnnx(pl.Callback):
    """Callback to export the trained model to ONNX file when training is finished.

    Args:
        input_sizes (list[tuple[int, int]] | tuple[int, int]): Input image size it can be a tuple of (h, w) or (c, h, w), or a list of c, (h, w) or (c, h, w).
        quantize (bool): Flag for if the model is quantized.
        dest (Path): Output directory for exported files.
        name (str): Model name, use as prefix for exported files.
        debug (bool, optional): Flag for debug mode. when set to True, the output of the intermediate layer is output to the npy file. Defaults to ``False``
        keep_model_device (bool, optional): Flag for kept model device unchanged.  This arg is a workaround for the model that cannot export via CPU. Defaults to ``False``
    """  # NOQA: E501

    def __init__(
        self,
        input_sizes: list[tuple[int, int]] | tuple[int, int],
        quantize: bool,
        dest: str | Path,
        name: str,
        debug: bool = False,
        keep_model_device: bool = False,
    ) -> None:
        self._input_sizes = input_sizes
        self._quantize = quantize
        self._dest = dest
        self._name = name
        self.debug = debug
        self.keep_model_device = keep_model_device

    @rank_zero_only
    def on_fit_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule) -> None:
        export_onnx_file(
            model=pl_module,
            input_image_size=self._input_sizes,
            quantize=self._quantize,
            path=self._dest,
            model_name=self._name,
            export_intermediate_outputs=self.debug,
            keep_model_device=self.keep_model_device,
            keep_model_training_mode=False,
        )


def verify_model_compatibility(
    model: torch.nn.Module,
    input_image_size: list[int]
    | list[tuple[int, int]]
    | tuple[int, int]
    | list[tuple[int, int, int]]
    | tuple[int, int, int] = (32, 32),
    quantize: bool = True,
    ignore_tolerance: bool = False,
    keep_model_device: bool = False,
) -> None:
    """Verify the converter compatibility to the model graph by actual conversion via `efficonv` command

    Args:
        model (torch.nn.Module): Model or operators to be verify
        input_image_size (list[int] | list[tuple[int, int]] | tuple[int, int] | list[tuple[int, int, int]] | tuple[int, int, int], optional):
            Input image size it can be a tuple of (h,w) or (c, h, w), or a list of c, (h,w) or (c, h, w). Defaults to ``(32, 32)``
        quantize (bool, optional): Flag for if the model is quantized. Defaults to ``True``
        ignore_tolerance (bool, optional): Flag for ignore tolerance threshold too small error in conversion. Defaults to ``False``
        keep_model_device (bool, optional): Flag for kept model device unchanged.  This arg is a workaround for the model that cannot export via CPU. Defaults to ``False``
    """  # NOQA: E501
    with tempfile.TemporaryDirectory() as tempdir:
        config_path = Path(tempdir) / "config.yaml"
        config_dict = {"ignore_tolerance": ignore_tolerance}
        with open(config_path, "w") as f:
            yaml.dump(config_dict, f)

        onnx_file_results = export_onnx_file(
            model=model,
            input_image_size=input_image_size,
            quantize=quantize,
            path=Path(tempdir),
            model_name="model",
            export_intermediate_outputs=False,
            keep_model_device=keep_model_device,
            keep_model_training_mode=True,
        )
        args = f"-a b64m1c1 -c {config_path} -o model.eii {onnx_file_results.onnx}"
        exitcode, output = subprocess.getstatusoutput(
            f"{sys.executable} -m efficiera.converter.generate_project {args}"
        )
        if exitcode == 127:
            exitcode, output = subprocess.getstatusoutput(f"efficonv {args}")
            if exitcode == 127:
                _logger.error("efficonv: command not found")
                raise FileNotFoundError("efficonv: command not found")
        if exitcode == 1:
            _logger.error("Failed to verify the convertion of the model")
            _logger.error(output)
            raise RuntimeError("Failed to verify the convertion of the model")
        _logger.info("Succeeded verify model compatibility")
        if "warning" in output:
            _logger.warning(output)


class ToIntegerWithScaling(object):
    """This is a processor that scale and convert tensor to Integer.

    Args:
        scale (float): The scaling factor to each element of the tensor.
                       Default is set to ``255.0`` to revert the transformation of torchvision.ToTensor

    Returns:
        torch.tensor: The transformed tensor
    """

    def __init__(self, scale: float = 255.0) -> None:
        self.scale = scale

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        return (tensor * self.scale).int()


def get_hydra_cwd_absolute_path(path: str | Path) -> Path:
    """Get the absolute path of the original without the hydra environment.

    Args:
        path (str | Path): The path want to retrieve

    Returns:
        Path: Absolute path from the original path
    """
    p = Path(path)
    p = p.expanduser()
    if p.is_absolute():
        return p
    if not HydraConfig.initialized():
        return p.absolute()
    return hydra.utils.get_original_cwd() / p


@overload
def get_complexity(
    model: torch.nn.Module,
    input_shape: Sequence[int],
    readable: Literal[False] = ...,
    print_per_layer_stat: bool = ...,
) -> tuple[int, int]:
    ...


@overload
def get_complexity(
    model: torch.nn.Module,
    input_shape: Sequence[int],
    readable: Literal[True],
    print_per_layer_stat: bool = ...,
) -> tuple[str, str]:
    ...


def get_complexity(
    model: torch.nn.Module,
    input_shape: Sequence[int],
    readable: bool = False,
    print_per_layer_stat: bool = False,
) -> tuple[int, int] | tuple[str, str]:
    """Compute the theoretical amount of multiply-add operations and parameters for whole model.

    Args:
        model (torch.nn.Module): A model for measuring computational complexity.
        input_shape (tuple[int, int, int]): input size, (C, H, W)
        readable (bool, optional): Whether the output should be in a readable form or not, Defaults to ``False``
        print_per_layer_stat (bool, optional): Whether to print detailed information for each layer, Defaults to ``False``

    Returns:
        tuple: Number of MACs and params.
    """  # NOQA: E501
    # TODO: Add PixelEmbeddings
    custom_ops = {
        QuantizableConv2d: conv_flops_counter_hook,
        HalfWaveGaussianQuantization: relu_flops_counter_hook,
        LearnedStepSizeQuantization: relu_flops_counter_hook,
    }
    with contextlib.redirect_stdout(None):
        macs, params = get_model_complexity_info(
            model,
            tuple(input_shape),
            print_per_layer_stat=print_per_layer_stat,
            as_strings=False,
            custom_modules_hooks=custom_ops,
        )

    if not readable:
        return int(macs), int(params)

    return _to_readable_number(macs), _to_readable_number(params)


def _to_readable_number(number: float) -> str:
    power = 1000
    n = 0
    units = ["", "K", "M", "G", "T"]

    while number > power and n < 4:
        number /= power
        n += 1

    return f"{number:.1f} {units[n]}"


def _prepare_intermediate_inputs_shape(model: torch.nn.Module) -> dict[str, tuple[int | tuple[int, ...], ...]]:
    """Prepare a hook for each intermediate layers for each layer input shape

    Args:
        model (torch.nn.Module): Model or operators to be added hook

    Returns:
        intermediate_inputs_shape (dict[str, tuple]): Dictionary store input tensor shape from each layer
    """
    intermediate_inputs_shape: dict[str, tuple[int | tuple[int, ...], ...]] = {}

    def make_hook(name: str) -> Callable[[nn.Module, torch.Tensor, torch.Tensor], None]:
        def hook(model: nn.Module, input: torch.Tensor, output: torch.Tensor) -> None:
            if isinstance(input[0], (tuple, list)):
                intermediate_inputs_shape[name] = tuple(tuple(sub_input.detach().shape) for sub_input in input[0])
            else:
                intermediate_inputs_shape[name] = tuple(input[0].detach().shape)

        return hook

    for name, layer in model.named_modules():
        layer.register_forward_hook(make_hook(name))

    return intermediate_inputs_shape


def get_quantizableconv2d_complexity(
    model: torch.nn.Module,
    input_shape: tuple[int, int, int],
    include_float_conv2d: bool = False,
    print_per_layer_stat: bool = False,
    path: Path | None = None,
) -> tuple[int, int]:
    """Compute the theoretical amount of multiply-add operations and total weight size for QuantizableConv2d.

    Args:
        model (torch.nn.Module): A model for measuring computational complexity
        input_shape (tuple[int, int, int]): input size, (C, H, W)
        include_float_conv2d (bool, optional): Whether to include float convolution layer. Defaults to ``False``
        print_per_layer_stat (bool, optional): Whether to print detailed information for each layer. Defaults to ``False``
        path (Path | None, optional): Output directory for complexity details csv files. Defaults to ``None`` (Do not export csv file)

    Returns:
        tuple: Number of total MACs and totalweights (bytes)
    """  # NOQA: E501
    model.cpu()
    model.eval()

    input_tensors = torch.rand((1,) + input_shape)
    intermediate_inputs_shape = _prepare_intermediate_inputs_shape(model)

    model.forward(input_tensors)

    headers = ["LAYER", "X", "Y", "C", "D", "Kx", "Ky", "Stride", "MACs", "Weight (bytes)"]
    layers: list[tuple[str, int, int, int, int, int, int, int, int, int]] = []
    macs = 0
    weights = 0
    for name, layer in model.named_modules():
        if isinstance(layer, QuantizableConv2d):
            is_float = layer.weight_quantizer is None
            if is_float and not include_float_conv2d:
                continue
            assert intermediate_inputs_shape[name][1] == layer.in_channels
            X, Y = intermediate_inputs_shape[name][2:]
            # HACK: Suppress mypy error of multiple input case, for QuantizableConv2d X, Y can be int only
            assert isinstance(X, int)
            assert isinstance(Y, int)
            C, D = layer.in_channels, layer.out_channels
            K_x, K_y = layer.kernel_size
            stride = layer.stride[0] * layer.stride[1]

            mac = -(-X * Y * C * D * K_x * K_y // stride)
            # weight_size = 1 for quantized weight and 32 for floating point weight
            weight_size = 1 if not is_float else 32
            weight = -(-weight_size * C * D * K_x * K_y // 8)
            macs += mac
            weights += weight

            if is_float:
                name = f"{name} (float)"
            layers.append((name, X, Y, C, D, K_x, K_y, stride, mac, weight))

    if print_per_layer_stat:
        print(tabulate(layers, headers=headers))
        print(f"Total MACs: {macs}")
        print(f"Total weight (bytes): {weights}")

    if path is not None:
        path.mkdir(exist_ok=True)
        with open(path / "complexity.csv", "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(layers)

    return (macs, weights)

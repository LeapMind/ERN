from __future__ import annotations

import torch
import torch.nn as nn


class Compressor(nn.Module):
    """Compressor
    A base class for a compressor module.

    Args:
        p (int, optional): Scaling factor of BinaryPower2Scaling. Defaults to ``32``

    Note:
        Compression logic and tensor format conversions should be implemented
        in ``forward`` method of a subclass.
    """

    def __init__(self, p: int = 32) -> None:
        super().__init__()
        self.p = p
        self.apply_lossless_compressor: bool = False
        self.original_size: int = 0
        self.compressed_size: int = 0

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError()

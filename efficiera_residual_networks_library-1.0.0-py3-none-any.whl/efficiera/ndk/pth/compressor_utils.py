from __future__ import annotations

import itertools
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from efficiera.ndk.pth.compressor import Compressor


def nchw_to_nhchwcl(x: torch.Tensor, scaling_factor_inverse: int, b: int = 64) -> torch.Tensor:
    """Convert tensor format from NCHW to NHChWCl
    During the process, the tensor is multiplied by the inverse of the scaling factor of BinaryPower2Scaling
    so that each element can be represented as a 16-bit integer.

    Args:
        x (torch.Tensor): input tensor in NCHW format
        scaling_factor_inverse (int): Inverse of the scaling factor
        b (int, optional): B parameter of the accelerator. Defaults to ``64``.

    Returns
        torch.Tensor: output tensor in NHChWCl format
    """
    n, c, h, w = x.shape
    cl = min(c, b)
    ch = c // cl
    x = x * scaling_factor_inverse
    x = torch.permute(x, (0, 2, 1, 3))  # NHCW
    x = torch.reshape(x, (n, h, ch, cl, w))  # NHChClW
    x = torch.permute(x, (0, 1, 2, 4, 3))  # NHChWCl
    return x


def nhchwcl_to_nchw(x: torch.Tensor, scaling_factor_inverse: int) -> torch.Tensor:
    """Convert tensor format from NHChWCl to NCHW
    During the process, the tensor is multiplied by the scaling factor of BinaryPower2Scaling
    so that the output tensor has the same scale as the original tensor.

    Args:
        x (torch.Tensor): input tensor in NHChWCl format
        scaling_factor_inverse (int): Inverse of the scaling factor

    Returns
        torch.Tensor: output tensor in NCHW format
    """
    n, h, ch, w, cl = x.shape
    b = cl
    c = b * ch
    x = torch.permute(x, (0, 1, 2, 4, 3))  # NHChClW
    x = torch.reshape(x, (n, h, c, w))  # NHCW
    x = torch.permute(x, (0, 2, 1, 3))  # NCHW
    x = x / scaling_factor_inverse
    return x


def nhchwcl_to_compression_blocks(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    """Convert NHChWCl tensor to a 3D tensor with compression blocks stacked along the first dimension
    If W is not divisible by 32, zero padding is performed to make it a multiple of 32 before conversion.

    Args:
        x (torch.Tensor): input tensor in NHChWCl format
    Returns:
        tuple[torch.Tensor, torch.Tensor]: Tuple of tensors
            x: Tensor with the shape of [num_compression_blocks, 32, Cl].
            widths: 1D tensor with the shape of [num_compression_block].
                Each element represents the effective width of the corresponding compressed block.
    """
    n, h, ch, w, cl = x.shape
    num_width_splits = math.ceil(w / 32)
    padding_width = num_width_splits * 32 - w
    x = F.pad(x, (0, 0, 0, padding_width))
    num_compression_blocks = n * h * ch * num_width_splits
    x = torch.reshape(x, (num_compression_blocks, 32, cl))
    widths = torch.where(torch.arange(1, num_compression_blocks + 1) % num_width_splits == 0, 32 - padding_width, 32)
    return x, widths


def compression_blocks_to_nhchwcl(x: torch.Tensor, shape: tuple[int, ...]) -> torch.Tensor:
    """Convert 3D tensor of stacked compression blocks to NHChWCl format

    Args:
        x (torch.Tensor): input tensor with the shape of [num_compression_blocks, 32, Cl]
        shape (tuple[int, ...]): Shape of output tensor in NHChWCl format
    Returns:
        torch.Tensor: output tensor in NHChWCl format
    """
    n, h, ch, w, cl = shape
    num_width_splits = math.ceil(w / 32)
    x = torch.reshape(x, (n, h, ch, num_width_splits * 32, cl))
    x = torch.split(x, w, dim=3)[0]
    return x


def tensor_to_byteslist(x: torch.Tensor) -> list[bytes]:
    """Convert a tensor in NHChWCl format to a list of bytes for the compression.

    Args:
        x (torch.Tensor): Tensor in NHChWCl format

    Returns:
        list[bytes]: List of bytes for compression
    """
    _, _, _, w, cl = x.shape
    x = torch.flatten(x)
    chunks_ch = torch.split(x, w * cl)  # split along Ch dimension
    chunks_ch_w = [torch.split(t, 32 * cl) for t in chunks_ch]  # split along W dimension
    tensors = list(itertools.chain.from_iterable(chunks_ch_w))  # flatten list of lists
    byteslist = [t.numpy().tobytes() for t in tensors]
    return byteslist


def byteslist_to_tensor(byteslist: list[bytes], shape: tuple[int, ...], dtype: torch.dtype) -> torch.Tensor:
    """Concatenate a decompressed list of bytes to a tensor in NHChWCl format.

    Args:
        byteslist (list[bytes]): List of bytes
        shape (tuple[int, ...]): Shape of output tensor
        dtype (torch.dtype): Data type of output tensor

    Returns:
        torch.Tensor: Tensor in NHChWCl format
    """
    tensors = [torch.frombuffer(bytearray(buf), dtype=dtype) for buf in byteslist]
    x = torch.cat(tensors)
    x = torch.reshape(x, shape)
    return x


def enable_lossless_compression(network: nn.Module) -> None:
    """Enable lossless compression in the network

    Args:
        network (torch.nn.Module): A network.
    """
    for module in network.modules():
        if isinstance(module, Compressor):
            module.apply_lossless_compressor = True


def disable_lossless_compression(network: nn.Module) -> None:
    """Disable lossless compression in the network

    Args:
        network (torch.nn.Module): A network.
    """
    for module in network.modules():
        if isinstance(module, Compressor):
            module.apply_lossless_compressor = False


def collect_compression_stats(network: nn.Module) -> list[tuple[str, int, int, float]]:
    """Collect compression statistics from all the compressor in the network

    Args:
        network (torch.nn.Module): A network.
    Returns:
        list[tuple[str, int, int, float]]: List of compressor statistics.
            Each element in the list is (module name, original size, compressed size, compression ratio)
            of each compressor.
    """

    def calc_compression_ratio(original_size: int, compressed_size: int) -> float:
        if compressed_size == 0:
            return 0
        return original_size / compressed_size

    data = []
    original_size_total = 0
    compressed_size_total = 0

    for name, module in network.named_modules():
        if isinstance(module, Compressor):
            original_size_total += module.original_size
            compressed_size_total += module.compressed_size
            compression_ratio = calc_compression_ratio(module.original_size, module.compressed_size)
            data.append((name, module.original_size, module.compressed_size, compression_ratio))

    compression_ratio_total = calc_compression_ratio(original_size_total, compressed_size_total)
    data.append(("total", original_size_total, compressed_size_total, compression_ratio_total))

    return data

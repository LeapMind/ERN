from __future__ import annotations

from collections.abc import Callable
import logging
from typing import Any, Type

import torch
import torch.nn as nn

from efficiera.ndk.pth.compressor import Compressor
from efficiera.ndk.pth.layers import Block, PreActBlock, PreActBottleneckBlock, QuantizableConv2d
from efficiera.ndk.pth.operators import PixelEmbeddingV3
from efficiera.ndk.pth.quantizers import BinaryPower2Scaling, HalfWaveGaussianQuantization

_logger = logging.getLogger(__name__)


class LMPreActResNet(nn.Module):
    """LMPreActResNet.
    The following changes have been made to this network from the original ResNet.

    * Pre-activation residual block is adopted `Identity Mappings in Deep Residual Networks`_.
    * Instead of a 7x7 (64ch) stem, we use a 3x3 (32ch, 32ch, 64ch) deep stem, which is the structure of ResNet-C from `Bag of Tricks for Image Classification with Convolutional Neural Networks`_.
    * If the ``tiny`` flag is set to ``True``, the first layer will be 3x3 conv instead of 7x7 stride2 conv as in ResNet20,
      and the next maxpool will be skipped.
    * If the ``unify_wq`` flag is set to ``True``, some layer that applied BinaryPower2Scaling by default will be replace with specify weight quantizer instead. (This option make model inconvertible.)
    * If the ``force_post_scale`` flag is set to ``True``, all the activation quantizer are applied post scaling. (This option make model inconvertible.)

    Args:
        block (type[Block]): Class of residual block.
        num_blocks (list[int]): Number of blocks per stage.
        channels (list[int]): Output channel size of conv per stage.
        strides (list[int]): Stride value of the block per stage.
        num_classes (int): Number of classes in the input image.
        tiny (bool, optional): Flag whether to use a network structure with small input size. Defaults to ``False``.
        apply_pixel_embedding (bool, optional): If ``True``, add a pixel embedding layer before the first conv. Defaults to ``True``.
        pixel_embedding_bit (int, optional): The number of bits of the pixel embedding. Defaults to ``8``.
        bn_momentum (float, optional): Momentum of the batch normalization. Defaults to ``0.9999``.
        weight_quantizer (Callable[[], nn.Module] | None, optional): The weight quantizer to use. Defaults to ``BinaryPower2Scaling``.
        unify_wq (bool, optional): Flag whether to ignore the converter restriction and use all weight quantizer in the whole network. Defaults to ``False``.
        activation_quantizer (Callable[..., nn.Module] | None, optional): The activation quantizer to use. Defaults to ``HalfWaveGaussianQuantization``.
        apply_relu (bool, optional): Flag whether to add ReLU layer right before activation quantizer. Defaults to ``False``. Recommended to set to "True" when using AQ with symmetric setting.
        force_post_scale (bool, optional): Flag whether to enforce post scale to all activation quantizers. Defaults to ``False``.
        features_only (bool, optional): Flag whether to use a network structure that only extracts feature maps. Defaults to ``False``.
        compressor (Type[Compressor], optional): Compressor for compressing intermediate data. Defaults to ``None``.

    .. _Identity Mappings in Deep Residual Networks:
        https://arxiv.org/abs/1603.05027

    .. _Bag of Tricks for Image Classification with Convolutional Neural Networks:
        https://arxiv.org/abs/1812.01187
    """  # NOQA: E501

    def __init__(
        self,
        block: type[Block],
        num_blocks: list[int],
        channels: list[int],
        strides: list[int],
        num_classes: int,
        tiny: bool = False,
        apply_pixel_embedding: bool = True,
        pixel_embedding_bit: int = 8,
        bn_momentum: float = 0.9999,
        weight_quantizer: Callable[[], nn.Module] | None = BinaryPower2Scaling,
        unify_wq: bool = False,
        activation_quantizer: Callable[..., nn.Module] | None = HalfWaveGaussianQuantization,
        apply_relu: bool = False,
        force_post_scale: bool = False,
        features_only: bool = False,
        compressor: Type[Compressor] | None = None,
    ) -> None:

        super().__init__()
        self._ch = 64
        self.pixel_embedding: PixelEmbeddingV3 | None = None
        self.weight_quantizer = weight_quantizer
        self.unify_wq = unify_wq
        self.activation_quantizer = activation_quantizer
        self.apply_relu = apply_relu
        self.force_post_scale = force_post_scale
        in_channels = 3
        self.features_only = features_only
        self.compressor = compressor

        if apply_pixel_embedding:
            self.pixel_embedding = PixelEmbeddingV3(in_channels=3, expansion=10, k=pixel_embedding_bit)
            in_channels = 30

        if tiny:
            self.stem = nn.Sequential(
                QuantizableConv2d(in_channels, self._ch, 3, self._wq_bp2s(), padding=1, bias=False)
            )
            self.maxpool = nn.Sequential()
        else:
            self.stem = nn.Sequential(
                QuantizableConv2d(in_channels, self._ch // 2, 3, self._wq(), stride=2, padding=1, bias=False),
                nn.BatchNorm2d(self._ch // 2, momentum=bn_momentum),
                self._act(),
                QuantizableConv2d(self._ch // 2, self._ch // 2, 3, self._wq(), padding=1, bias=False),
                nn.BatchNorm2d(self._ch // 2, momentum=bn_momentum),
                self._act(),
                QuantizableConv2d(self._ch // 2, self._ch, 3, self._wq(), padding=1, bias=False),
                nn.BatchNorm2d(self._ch, momentum=bn_momentum),
                self._act(disable_post_scale=True),
            )
            self.maxpool = nn.Sequential(
                nn.MaxPool2d(kernel_size=3, stride=2, padding=1),
                QuantizableConv2d(self._ch, self._ch, 3, self._wq_bp2s(), padding=1, bias=False),
            )

        blocks = [self._make_layer(block, c, n, s, bn_momentum) for c, n, s in zip(channels, num_blocks, strides)]
        self.features = nn.Sequential(
            *blocks,
            nn.BatchNorm2d(self._ch, momentum=bn_momentum),
            self._act(),
        )

        if not features_only:
            self.last_conv = QuantizableConv2d(self._ch, num_classes, 1, self._wq(), bias=False)
            self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
            self.flatten = nn.Flatten()

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, val=1)
                nn.init.zeros_(m.bias)

    def _wq(self) -> nn.Module | None:
        """Get weight quantizer
        when self.weight_quantizer is set then return weight quantizer instance

        Returns:
            The weight quantizer used in this network
        """
        if self.weight_quantizer is not None:
            return self.weight_quantizer()
        return None

    def _wq_bp2s(self) -> nn.Module | None:
        """Get BinaryPower2Scaling as a weight quantizer
        when self.weight_quantizer is set
        but when self.unify_wq is set then return weight quantizer specify in class instead of BinaryPower2Scaling

        Returns:
            The weight quantizer used in this network
        """
        # Apply same weight quantizers to all layers
        if self.unify_wq:
            return self._wq()

        if self.weight_quantizer is not None:
            return BinaryPower2Scaling()
        return None

    def _act(self, disable_post_scale: bool = False) -> nn.Module:
        """Get activation
        when self.activation_quantizer is set then return activation quantizer instance.
        otherwise, return ReLU instance.
        Moreover, when self.force_post_scale option is set then all activation quantizers will apply post scaling.

        Returns:
            The activation used in this network
        """
        # Ignore all disable post scale flag and force all aq to apply post scaler
        if self.force_post_scale:
            disable_post_scale = False

        if self.activation_quantizer is not None:
            activation = self.activation_quantizer(disable_post_scale=disable_post_scale)
            if self.apply_relu:
                activation = nn.Sequential(nn.ReLU(), activation)
            return activation
        return nn.ReLU(inplace=True)

    def _make_layer(
        self,
        block: type[Block],
        out_channels: int,
        num_blocks: int,
        stride: int = 1,
        bn_momentum: float = 0.1,
    ) -> nn.Sequential:
        layers = []
        for i in range(num_blocks):
            layers.append(
                block(
                    in_channels=self._ch,
                    out_channels=out_channels,
                    stride=stride if i == 0 else 1,
                    bn_momentum=bn_momentum,
                    weight_quantizer=self.weight_quantizer,
                    unify_wq=self.unify_wq,
                    activation_quantizer=self.activation_quantizer,
                    apply_relu=self.apply_relu,
                    force_post_scale=self.force_post_scale,
                    compressor=self.compressor,
                )
            )
            self._ch = out_channels * block.expansion

        return nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.pixel_embedding:
            x = self.pixel_embedding(x)
        else:
            x = x.float()

        out = self.stem(x)
        out = self.maxpool(out)
        out = self.features(out)

        if not self.features_only:
            out = self.last_conv(out)
            out = self.avg_pool(out)
            out = self.flatten(out)

        return out


def lm_preact_resnet18(num_classes: int, **kwargs: Any) -> LMPreActResNet:
    """Helper function to generate the network structure of LMPreActResNet18.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMPreActResNet: A nn.Module with the structure of LMPreActResNet18
    """
    return LMPreActResNet(PreActBlock, [2, 2, 2, 2], [64, 128, 256, 512], [1, 2, 2, 2], num_classes, **kwargs)


def lm_preact_resnet18_tiny(num_classes: int, **kwargs: Any) -> LMPreActResNet:
    """Helper function to generate the network structure of LMPreActResNet18Tiny.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMPreActResNet: A nn.Module with the structure of LMPreActResNet18Tiny
    """
    return LMPreActResNet(PreActBlock, [2, 2, 2, 2], [64, 128, 256, 512], [1, 2, 2, 2], num_classes, True, **kwargs)


def lm_preact_resnet34(num_classes: int, **kwargs: Any) -> LMPreActResNet:
    """Helper function to generate the network structure of LMPreActResNet34.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMPreActResNet: A nn.Module with the structure of LMPreActResNet34
    """
    return LMPreActResNet(PreActBlock, [3, 4, 6, 3], [64, 128, 256, 512], [1, 2, 2, 2], num_classes, **kwargs)


def lm_preact_resnet34_tiny(num_classes: int, **kwargs: Any) -> LMPreActResNet:
    """Helper function to generate the network structure of LMPreActResNet34Tiny.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMPreActResNet: A nn.Module with the structure of LMPreActResNet34Tiny
    """
    return LMPreActResNet(PreActBlock, [3, 4, 6, 3], [64, 128, 256, 512], [1, 2, 2, 2], num_classes, True, **kwargs)


def lm_preact_resnet50(num_classes: int, **kwargs: Any) -> LMPreActResNet:
    """Helper function to generate the network structure of LMPreActResNet50.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMPreActResNet: A nn.Module with the structure of LMPreActResNet50
    """
    return LMPreActResNet(PreActBottleneckBlock, [3, 4, 6, 3], [64, 128, 256, 256], [1, 2, 2, 2], num_classes, **kwargs)


def lm_preact_resnet50_tiny(num_classes: int, **kwargs: Any) -> LMPreActResNet:
    """Helper function to generate the network structure of LMPreActResNet50Tiny.

    Args:
        num_classes (int): Number of classes

    Returns:
        LMPreActResNet: A nn.Module with the structure of LMPreActResNet50Tiny
    """
    return LMPreActResNet(
        PreActBottleneckBlock, [3, 4, 6, 3], [64, 128, 256, 256], [1, 2, 2, 2], num_classes, True, **kwargs
    )

"""``efficiera.ndk.pth.layers`` is a package of layers to create models that work with Efficiera."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, ClassVar, Type

import torch
import torch.nn as nn

from efficiera.ndk.pth.compressor import Compressor
from efficiera.ndk.pth.quantizers import BinaryPower2Scaling, HalfWaveGaussianQuantization


class QuantizableConv2d(nn.Conv2d):
    """Quantized convolution 2d.
    This quantization creates a convolution 2d layer with a quantized weight.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (int | tuple[int, int]): Size of the convolving kernel.
        weight_quantizer (nn.Module | None, optional): A quantizer for weight of convolution2d layer.
            Defaults to ``None``
    """

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        weight_quantizer: nn.Module | None = None,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        super().__init__(in_channels, out_channels, kernel_size, *args, **kwargs)
        self.weight_quantizer = weight_quantizer

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.weight_quantizer:
            w = self.weight_quantizer(self.weight)
        else:
            w = self.weight

        return nn.functional.conv2d(x, w, self.bias, self.stride, self.padding, self.dilation, self.groups)


class QuantizedConv2dBlock(nn.Module):
    """QuantizedConv2dBlock (LMNet Block)
    This block is a quantized block of three layers in the following order: 1-Convolutional, 2-Batch Normalization
    and 3-Activation. The quantizers are weight quantizer for weight of convolutional layer and activation quantizer
    for the activation.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        kernel_size (int | tuple[int, int]): Size of the convolving kernel.
        stride (int | tuple[int, int]): Stride of the convolution. Defaults to ``1``
        padding (int | tuple[int, int]): Zero-padding added to both sides of the input. Defaults to ``1``
        groups (int): Number of blocked connections from input channels to output channels. Defaults to ``1``
        weight_quantizer (nn.Module | None, optional): A quantizer for weight of convolution2d layer.
            Defaults to ``None``
        weight_initializer (Callable[[torch.Tensor], None], optional): Initializer for the convolution layer weight. Defaults to ``None``
        activation (Callable[[torch.Tensor], torch.Tensor], optional): Activation function to use. Defaults to ``None``
        skip_bn (bool, optional): If ``True``, skip BatchNorm in this block. Defaults to ``False``
        bn_momentum (float, optional): Momentum value for the batch normalization. Defaults to ``0.9999``
        bias (bool, optional): If ``True``, add bias to convolution. Defaults to ``False``
    """  # NOQA: E501

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int | tuple[int, int],
        stride: int | tuple[int, int] = 1,
        padding: int | tuple[int, int] = 1,
        groups: int = 1,
        weight_quantizer: nn.Module | None = None,
        weight_initializer: Callable[[torch.Tensor], None] | None = None,
        activation: Callable[[torch.Tensor], torch.Tensor] | None = None,
        skip_bn: bool = False,
        bn_momentum: float = 0.9999,
        bias: bool = False,
    ) -> None:
        super().__init__()

        self.activation = activation
        self.conv = QuantizableConv2d(
            in_channels,
            out_channels,
            kernel_size,
            weight_quantizer,
            stride=stride,
            padding=padding,
            groups=groups,
            bias=bias,
        )

        if weight_initializer:
            weight_initializer(self.conv.weight)

        self.bn = nn.BatchNorm2d(out_channels, momentum=bn_momentum) if not skip_bn else None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv(x)
        if self.bn:
            x = self.bn(x)
        if self.activation:
            x = self.activation(x)

        return x


class Block(nn.Module):
    expansion: ClassVar[int]


class PreActBlock(Block):
    """Residual connection block used in ResNet.
    This block uses a pre-activation structure, so the Batch Norm is executed after Add.
    In order to make the calculation possible in Efficiera,
    the weight quantizer and the activation quantizer cannot be selected.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        stride (int, optional): Value of stride. Defaults to ``1``.
        bn_momentum (float, optional): Momentum value for the batch normalization. Defaults to ``0.1``.
        weight_quantizer (Callable[[], nn.Module], optional): Weight quantizer for the convolution. Defaults to ``BinaryPower2Scaling``.
        unify_wq (bool, optional): Flag whether to ignore the converter restriction and use all weight quantizer in the whole network. Defaults to ``False``.
        activation_quantizer (Callable[..., nn.Module], optional): Activation quantizer. Defaults to ``HalfWaveGaussianQuantization``.
        apply_relu (bool, optional): Flag whether to add ReLU layer right before activation quantizer. Defaults to ``False``. Recommended to set to "True" when using AQ with symmetric setting.
        force_post_scale (bool, optional): Flag whether to enforce post scale to all activation quantizers. Defaults to ``False``.
        compressor (Type[Compressor], optional): Compressor for compressing intermediate data. Defaults to ``None``.
    """  # NOQA: E501

    expansion: ClassVar[int] = 1

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        bn_momentum: float = 0.1,
        weight_quantizer: Callable[[], nn.Module] | None = BinaryPower2Scaling,
        unify_wq: bool = False,
        activation_quantizer: Callable[..., nn.Module] | None = HalfWaveGaussianQuantization,
        apply_relu: bool = False,
        force_post_scale: bool = False,
        compressor: Type[Compressor] | None = None,
    ):
        super().__init__()
        self.downsample = None
        self.weight_quantizer = weight_quantizer
        self.unify_wq = unify_wq
        self.activation_quantizer = activation_quantizer
        self.apply_relu = apply_relu
        self.force_post_scale = force_post_scale
        self.compressor = None

        if stride != 1 or in_channels != self.expansion * out_channels:
            self.downsample = QuantizableConv2d(
                in_channels=in_channels,
                out_channels=self.expansion * out_channels,
                kernel_size=1,
                weight_quantizer=self._wq_bp2s(),
                stride=stride,
                bias=False,
            )

        if self.downsample is None and compressor is not None:
            self.compressor = compressor()

        self.bn0 = nn.BatchNorm2d(in_channels, momentum=bn_momentum)
        self.act0 = self._act(disable_post_scale=self.downsample is not None)
        self.conv1 = QuantizableConv2d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=3,
            weight_quantizer=self._wq(),
            stride=stride,
            padding=1,
            bias=False,
        )
        self.bn1 = nn.BatchNorm2d(out_channels, momentum=bn_momentum)
        self.act1 = self._act(disable_post_scale=True)
        self.conv2 = QuantizableConv2d(
            in_channels=out_channels,
            out_channels=self.expansion * out_channels,
            kernel_size=3,
            weight_quantizer=self._wq_bp2s(),
            padding=1,
            bias=False,
        )

    def _wq(self) -> nn.Module | None:
        """Get weight quantizer
        when self.weight_quantizer is set then return weight quantizer instance

        Returns:
            The weight quantizer used in this network
        """
        if self.weight_quantizer is not None:
            return self.weight_quantizer()
        return None

    def _wq_bp2s(self) -> nn.Module | None:
        """Get BinaryPower2Scaling as a weight quantizer
        when self.weight_quantizer is set
        but when self.unify_wq is set then return weight quantizer specify in class instead of BinaryPower2Scaling

        Returns:
            The weight quantizer used in this network
        """
        # Apply same weight quantizers to all layers
        if self.unify_wq:
            return self._wq()

        if self.weight_quantizer is not None:
            return BinaryPower2Scaling()
        return None

    def _act(self, disable_post_scale: bool = False) -> nn.Module:
        """Get activation
        when self.activation_quantizer is set then return activation quantizer instance.
        otherwise, return ReLU instance.
        Moreover, when self.force_post_scale option is set then all activation quantizers will apply post scaling.

        Returns:
            The activation used in this network
        """
        # Ignore all disable post scale flag and force all aq to apply post scaler
        if self.force_post_scale:
            disable_post_scale = False

        if self.activation_quantizer is not None:
            activation = self.activation_quantizer(disable_post_scale=disable_post_scale)
            if self.apply_relu:
                activation = nn.Sequential(nn.ReLU(), activation)
            return activation
        return nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x

        out = self.bn0(x)
        out = self.act0(out)

        if self.downsample:
            identity = self.downsample(out)
        elif self.compressor:
            identity = self.compressor(x)

        out = self.conv1(out)
        out = self.bn1(out)
        out = self.act1(out)
        out = self.conv2(out)

        out += identity

        return out


class PreActBottleneckBlock(Block):
    """Residual connection bottleneck block used in ResNet.
    This block uses a pre-activation structure, so the Batch Norm is executed after Add.
    In order to make the calculation possible in Efficiera,
    the weight quantizer and the activation quantizer cannot be selected.

    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        stride (int, optional): Value of stride. Defaults to ``1``.
        bn_momentum (float, optional): Momentum value for the batch normalization. Defaults to ``0.1``.
        weight_quantizer (Callable[[], nn.Module], optional): Weight quantizer for the convolution. Defaults to ``BinaryPower2Scaling``.
        unify_wq (bool, optional): Flag whether to ignore the converter restriction and use all weight quantizer in the whole network. Defaults to ``False``.
        activation_quantizer (Callable[..., nn.Module], optional): Activation quantizer. Defaults to ``HalfWaveGaussianQuantization``.
        apply_relu (bool, optional): Flag whether to add ReLU layer right before activation quantizer. Defaults to ``False``. Recommended to set to "True" when using AQ with symmetric setting.
        force_post_scale (bool, optional): Flag whether to enforce post scale to all activation quantizers. Defaults to ``False``.
        compressor (Type[Compressor], optional): Compressor for compressing intermediate data. Defaults to ``None``.
    """  # NOQA: E501

    expansion: ClassVar[int] = 4

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        bn_momentum: float = 0.1,
        weight_quantizer: Callable[[], nn.Module] | None = BinaryPower2Scaling,
        unify_wq: bool = False,
        activation_quantizer: Callable[..., nn.Module] | None = HalfWaveGaussianQuantization,
        apply_relu: bool = False,
        force_post_scale: bool = False,
        compressor: Type[Compressor] | None = None,
    ):
        super().__init__()
        self.downsample = None
        self.weight_quantizer = weight_quantizer
        self.unify_wq = unify_wq
        self.activation_quantizer = activation_quantizer
        self.apply_relu = apply_relu
        self.force_post_scale = force_post_scale
        self.compressor = None

        if stride != 1 or in_channels != self.expansion * out_channels:
            self.downsample = QuantizableConv2d(
                in_channels=in_channels,
                out_channels=self.expansion * out_channels,
                kernel_size=1,
                weight_quantizer=self._wq_bp2s(),
                stride=stride,
                bias=False,
            )

        if self.downsample is None and compressor is not None:
            self.compressor = compressor()

        self.bn0 = nn.BatchNorm2d(in_channels, momentum=bn_momentum)
        self.act0 = self._act(disable_post_scale=self.downsample is not None)
        self.conv1 = QuantizableConv2d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=1,
            weight_quantizer=self._wq(),
            bias=False,
        )
        self.bn1 = nn.BatchNorm2d(out_channels, momentum=bn_momentum)
        self.act1 = self._act(disable_post_scale=False)
        self.conv2 = QuantizableConv2d(
            in_channels=out_channels,
            out_channels=out_channels,
            kernel_size=3,
            weight_quantizer=self._wq(),
            stride=stride,
            padding=1,
            bias=False,
        )
        self.bn2 = nn.BatchNorm2d(out_channels, momentum=bn_momentum)
        self.act2 = self._act(disable_post_scale=True)
        self.conv3 = QuantizableConv2d(
            in_channels=out_channels,
            out_channels=self.expansion * out_channels,
            kernel_size=1,
            weight_quantizer=self._wq_bp2s(),
            bias=False,
        )

    def _wq(self) -> nn.Module | None:
        """Get weight quantizer
        when self.weight_quantizer is set then return weight quantizer instance

        Returns:
            The weight quantizer used in this network
        """
        if self.weight_quantizer is not None:
            return self.weight_quantizer()
        return None

    def _wq_bp2s(self) -> nn.Module | None:
        """Get BinaryPower2Scaling as a weight quantizer
        when self.weight_quantizer is set
        but when self.unify_wq is set then return weight quantizer specify in class instead of BinaryPower2Scaling

        Returns:
            The weight quantizer used in this network
        """
        # Apply same weight quantizers to all layers
        if self.unify_wq:
            return self._wq()

        if self.weight_quantizer is not None:
            return BinaryPower2Scaling()
        return None

    def _act(self, disable_post_scale: bool = False) -> nn.Module:
        """Get activation
        when self.activation_quantizer is set then return activation quantizer instance.
        otherwise, return ReLU instance.
        Moreover, when self.force_post_scale option is set then all activation quantizers will apply post scaling.

        Returns:
            The activation used in this network
        """
        # Ignore all disable post scale flag and force all aq to apply post scaler
        if self.force_post_scale:
            disable_post_scale = False

        if self.activation_quantizer is not None:
            activation = self.activation_quantizer(disable_post_scale=disable_post_scale)
            if self.apply_relu:
                activation = nn.Sequential(nn.ReLU(), activation)
            return activation
        return nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x

        out = self.bn0(x)
        out = self.act0(out)

        if self.downsample:
            identity = self.downsample(out)
        elif self.compressor:
            identity = self.compressor(x)

        out = self.conv1(out)
        out = self.bn1(out)
        out = self.act1(out)
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.act2(out)
        out = self.conv3(out)

        out += identity

        return out

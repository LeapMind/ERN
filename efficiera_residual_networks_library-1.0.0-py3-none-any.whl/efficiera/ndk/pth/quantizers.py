"""``efficiera.ndk.pth.quantizers`` is a package of operations for quantization to create models that work with Efficiera."""  # NOQA: E501

from __future__ import annotations

from collections.abc import Callable
from logging import getLogger
import math
from typing import Any

import torch
import torch.nn as nn

_logger = getLogger(__name__)


def _binarize(x: torch.Tensor) -> torch.Tensor:
    """This is custom sign function for quantizer. The different from torch.sign(x) is sign of 0 is 1 instead of 0.

    Args:
        x (torch.Tensor): Input tensor.
    Returns:
        torch.tensor: A new tensor with the custom signs of the elements of input.
    """
    return torch.where(x >= 0, 1.0, -1.0)


def _round_half_up(x: torch.Tensor) -> torch.Tensor:
    """This is custom round function for quantizer. The diffetent from torch.round(x) is round of 0.5 is 1 instead of 0.

    Args:
        x (torch.Tensor): Input tensor.
    Returns:
        torch.tensor: A new tensor with the custom round of the elements of input.
    """
    return torch.floor(x + 0.5)


class _BinaryChannelWiseMeanScalingFunction(torch.autograd.Function):
    """Binary channel wise mean scaling quantizer. (torch.autograd.Function)
    This quantization creates a binary channel wise mean scaling quantizer.

    This method is varient of XNOR-Net [1]_ weight quantization, the difference from XNOR-Net [1]_ is
    backward function.

    `op_type` is ``BinaryChannelWiseMeanScalingQuantizer``.

    Reference:
        .. [1] `XNOR-Net: ImageNet Classification Using Binary Convolutional Neural Networks
        <https://arxiv.org/abs/1603.05279>`_
    """

    @staticmethod
    def symbolic(g: Any, w: Any) -> Any:
        return g.op("lm::BinaryChannelWiseMeanScalingQuantizer", w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \bar{\mathbf{w}} & = \frac{1}{n}||\mathbf{W}||_{\ell1}
                & \text{$\bar{\mathbf{w}}$ is a $c$-channels vector} \\
                & & \text{$n$ is number of elements in each channel of $\mathbf{W}$} \\\\
                \mathbf{Y} & = \text{sign}\big(\mathbf{W}\big) \times \bar{\mathbf{w}} &\\
            \end{align}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        scaling_factor = w.abs().mean(dim=(1, 2, 3), keepdim=True)
        return _binarize(w) * scaling_factor

    @staticmethod
    def backward(ctx: Any, grad_output: Any) -> torch.Tensor:
        return grad_output


class _BinaryChannelWiseMeanScalingFunctionWithEWGS(torch.autograd.Function):
    """Binary channel wise mean scaling quantizer with EWGS. (torch.autograd.Function)
    The difference from _BinaryChannelWiseMeanScalingFunction is only an EWGS [1]_ gradient approximation in backward function.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(g: Any, w: Any, delta: Any) -> Any:
        return _BinaryChannelWiseMeanScalingFunction.symbolic(g, w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, delta: float) -> torch.Tensor:
        q = _BinaryChannelWiseMeanScalingFunction.forward(ctx, w)
        ctx.ewgs = w - q, delta
        return q

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None]:
        q_err, delta = ctx.ewgs
        scaled = grad_output * (1 + delta * torch.sign(grad_output) * q_err)
        return scaled, None


class BinaryChannelWiseMeanScaling(nn.Module):
    """Binary channel wise mean scaling quantizer.
    This quantization creates a binary channel wise mean scaling quantizer.

    This method is varient of `XNOR-Net`_ weight quantization, the difference from `XNOR-Net`_ is
    backward function.

    .. _XNOR-Net:
        https://arxiv.org/abs/1603.05279

    Args:
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation
    """

    def __init__(self, delta: float = 0) -> None:
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        self.delta = delta

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.delta == 0:  # Switch to STE
            return _BinaryChannelWiseMeanScalingFunction.apply(x)
        return _BinaryChannelWiseMeanScalingFunctionWithEWGS.apply(x, self.delta)


class _BinaryMeanScalingFunction(torch.autograd.Function):
    """Binary mean scaling quantizer. (torch.autograd.Function)
    This quantization creates a binary mean scaling quantizer.

    This method is DoReFa-Net [2]_ weight quantization.

    `op_type` is ``BinaryMeanScalingQuantizer``.

    Reference:
        .. [2] `DoReFa-Net: Training Low Bitwidth Convolutional Neural Networks with Low Bitwidth Gradients
        <https://arxiv.org/abs/1606.06160>`_
    """

    @staticmethod
    def symbolic(g: Any, w: Any) -> Any:
        return g.op("lm::BinaryMeanScalingQuantizer", w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor) -> torch.Tensor:
        r"""Forward.

        .. math::
            \begin{align}
                \bar{x} & = \frac{1}{N}||\mathbf{X}||_{\ell1}
                & \text{$\bar{x}$ is a scalar} \\
                & & \text{$N$ is number of elements in all channels of $\mathbf{X}$}\\
                \mathbf{Y} & = \text{sign}\big(\mathbf{X}\big) \cdot \bar{x} &\\
            \end{align}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        scaling_factor = w.abs().mean()
        return _binarize(w) * scaling_factor

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> torch.Tensor:
        return grad_output


class _BinaryMeanScalingFunctionWithEWGS(torch.autograd.Function):
    """Binary mean scaling quantizer with EWGS. (torch.autograd.Function)
    The difference from _BinaryMeanScalingFunction is only an EWGS [1]_ gradient approximation in backward function.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """

    @staticmethod
    def symbolic(g: Any, w: Any, delta: Any) -> Any:
        return _BinaryMeanScalingFunction.symbolic(g, w)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, delta: float) -> torch.Tensor:
        q = _BinaryMeanScalingFunction.forward(ctx, w)
        ctx.ewgs = w - q, delta
        return q

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None]:
        q_err, delta = ctx.ewgs
        scaled = grad_output * (1 + delta * torch.sign(grad_output) * q_err)
        return scaled, None


class BinaryMeanScaling(nn.Module):
    """Binary mean scaling quantizer.
    This quantization creates a binary mean scaling quantizer.

    This method is `DoReFa-Net`_ weight quantization.

    .. _DoReFa-Net:
        https://arxiv.org/abs/1606.06160

    Args:
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation
    """

    def __init__(self, delta: float = 0) -> None:
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        self.delta = delta

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.delta == 0:  # Switch to STE
            return _BinaryMeanScalingFunction.apply(x)
        return _BinaryMeanScalingFunctionWithEWGS.apply(x, self.delta)


class _BinaryPower2ScalingFunction(torch.autograd.Function):
    """Binary power2 scaling quantizer. (torch.autograd.Function)
    This quantization is a weight quantizer, that addressed floating point scaling factor, e.g.,
    Binary channel wise mean scaling quantizer. If this scaling factor is represented by a power of 2,
    then it does not need to use floating-point number operations, thus it can run more efficient while
    accuracy is almost unchanged.

    `op_type` is ``BinaryPower2ScalingQuantizer``.
    """

    @staticmethod
    def symbolic(g: Any, w: Any, p: Any) -> Any:
        p = g.constant(p, [0], "int")
        return g.op("lm::BinaryPower2ScalingQuantizer", w, p)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, p: int) -> torch.Tensor:
        r"""Forward.

        .. math::
            \mathbf{Y} & = \text{sign}\big(\mathbf{W}\big) \times \frac{1}{p}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
            p (int): Scaling factor, must be a power of 2. Defaults to ``32``
        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        return _binarize(w) * (1.0 / p)

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None]:
        return grad_output, None


class _BinaryPower2ScalingFunctionWithEWGS(torch.autograd.Function):
    """Binary power2 scaling quantizer with EWGS. (torch.autograd.Function)
    The difference from _BinaryPower2ScalingFunction is only an EWGS [1]_ gradient approximation in backward function.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """

    @staticmethod
    def symbolic(g: Any, w: Any, p: Any, delta: Any) -> Any:
        return _BinaryPower2ScalingFunction.symbolic(g, w, p)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, p: int, delta: float) -> torch.Tensor:
        q = _BinaryPower2ScalingFunction.forward(ctx, w, p)
        ctx.ewgs = w - q, delta
        return q

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None, None]:
        q_err, delta = ctx.ewgs
        scaled = grad_output * (1 + delta * torch.sign(grad_output) * q_err)
        return scaled, None, None


class BinaryPower2Scaling(nn.Module):
    """Binary power2 scaling quantizer.
    This quantization is a weight quantizer, that addressed floating point scaling factor, e.g.,
    Binary channel wise mean scaling quantizer. If this scaling factor is represented by a power of 2,
    then it does not need to use floating-point number operations, thus it can run more efficient while
    accuracy is almost unchanged.

    Args:
        p (int, optional): Scaling factor, must be a power of 2. Defaults to ``32``
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation
    """

    def __init__(self, p: int = 32, delta: float = 0) -> None:
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        assert p & (p - 1) == 0
        self.p = p
        self.delta = delta

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.delta == 0:  # Switch to STE
            return _BinaryPower2ScalingFunction.apply(x, self.p)
        return _BinaryPower2ScalingFunctionWithEWGS.apply(x, self.p, self.delta)


class _LearnedStepSizeBinaryWeightScalingFunction(torch.autograd.Function):
    """LearnedStepSizeBinaryWeightScaling (WLSQ).  (torch.autograd.Function)
    This quantization creates a learned step size quantizer on weight.

    This quantization method is LSQ [1]_ weight quantization variant,

    `op_type` is ``BinaryWeightQuantizer``.

    Reference:
        .. [1] `LEARNED STEP SIZE QUANTIZATION <https://arxiv.org/abs/1902.08153>`_
    """

    @staticmethod
    def symbolic(g: Any, w: Any, scale: Any) -> Any:
        return g.op("lm::BinaryWeightQuantizer", w, scale)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, step_size: float) -> torch.Tensor:
        r"""Forward.

        .. math::
            \mathbf{Y} = \text{sign}\big(\mathbf{X}\big) \cdot \mathbf{step\_size}

        Args:
            w (torch.Tensor): Weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        Returns:
            torch.tensor: The quantized weight.
        """  # NOQA: E501
        ctx.save_for_backward(w, step_size)
        return _binarize(w) * step_size

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        w, step_size = ctx.saved_tensors
        gradscale_factor = torch.tensor(1.0 / math.sqrt(w.numel())).to(grad_output.device)

        grad_step_size_no_border = 0.5 * (-w / step_size + (w / step_size).sign()) * gradscale_factor
        grad_step_size_upper_border = torch.where(w <= step_size, grad_step_size_no_border, gradscale_factor)
        grad_step_size = torch.where(w >= -step_size, grad_step_size_upper_border, -gradscale_factor)

        return grad_output, (grad_step_size * grad_output).sum()


class _LearnedStepSizeBinaryWeightScalingFunctionWithEWGS(torch.autograd.Function):
    """LearnedStepSizeBinaryWeightScaling (WLSQ) with EWGS. (torch.autograd.Function)
    The difference from _LearnedStepSizeBinaryWeightScaling is only an EWGS [1]_ gradient approximation in backward function.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(g: Any, w: Any, scale: Any, delta: Any) -> Any:
        return _LearnedStepSizeBinaryWeightScalingFunction.symbolic(g, w, scale)

    @staticmethod
    def forward(ctx: Any, w: torch.Tensor, step_size: float, delta: float) -> torch.Tensor:
        q = _LearnedStepSizeBinaryWeightScalingFunction.forward(ctx, w, step_size)
        ctx.ewgs = w - q, delta
        return q

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, None]:
        q_err, delta = ctx.ewgs
        grad_input, grad_step_size, *_ = _LearnedStepSizeBinaryWeightScalingFunction.backward(ctx, grad_output)
        scaled = grad_input * (1 + delta * torch.sign(grad_input) * q_err)
        return scaled, grad_step_size, None


class LearnedStepSizeBinaryWeightScaling(nn.Module):
    """LearnedStepSizeBinaryWeightScaling (WLSQ).
    This quantization creates a learned step size quantizer on weight.

    Args:
        step_size (float, optional): Step size. Defaults to ``0.05``
        min_value (float, optional): Lower bound of step size. Defaults to ``0.00001``
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation
    """

    def __init__(self, step_size: float = 0.05, min_value: float = 0.00001, delta: float = 0) -> None:
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        self.step_size = nn.Parameter(torch.tensor(step_size))
        self.min_value = min_value
        self.delta = delta

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training:
            step_size = torch.clamp(self.step_size, min=self.min_value)
        else:
            step_size = torch.clamp(self.step_size.data, min=self.min_value)

        if self.delta == 0:  # Switch to STE
            return _LearnedStepSizeBinaryWeightScalingFunction.apply(x, step_size)
        return _LearnedStepSizeBinaryWeightScalingFunctionWithEWGS.apply(x, step_size, self.delta)


class _ElementWiseGradientScalingQuantizationFunction(torch.autograd.Function):
    """Element-Wise Gradient Scaling Quantizer. (torch.autograd.Function)

    This function only performs the core of quantization, that is, given the input tensor [0, 1], which is already
    clipped but not quantized, quantize it to `k`-bits by rounding to `[0, 1/M, 2/M, ..., M/M]`, given `M=2**k-1`.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, k: int, delta: float) -> torch.Tensor:
        r"""Forward.

        .. math::
            s &= 2^k-1\\
            \mathbf{Y} &= \text{round}\big(s \cdot \mathbf{X}\big) \cdot \frac{1}{s}

        Args:
            x (torch.Tensor): tensor to be quantized
            k (int): bit-width of quantization
            delta (float): scaling factor of the gradient. When `delta=0`, this function becomes STE.
        Returns:
            q (torch.Tensor): quantized tensor to `k`-bits
        """
        scale = 2**k - 1
        q = _round_half_up(x * scale) / scale
        ctx.ewgs = x - q, delta
        return q

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None, None]:
        q_err, delta = ctx.ewgs
        scaled = grad_output * (1 + delta * torch.sign(grad_output) * q_err)
        return scaled, None, None


class _ElementWiseGradientScalingQuantization(nn.Module):
    """The element-wise gradient scaling quantizer (EWGS).

    This quantizer performs the EWGS authors proposed quantizers in the paper [1]_, precisely Eq.1 to Eq.3.
    This quantizer can be either Weight quantizer and Activation quantizer.
    Note that this quantizer can not be used individually as it is not convertible.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_

     Args:
        k (int, optional): bit-width of the precision of activation function. Defaults to ``2``
        is_activation (bool, optional): Whether to use this quantizer as activation quantizer. Defaults to ``False``
        delta (float, optional): : The delta variable in EWGS. Defaults to ``1e-3``
    """

    def __init__(self, k: int = 2, is_activation: bool = False, delta: float = 0.0) -> None:
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        self.k = k
        self.is_activation = is_activation
        self.delta = delta

    def forward(self, x: torch.Tensor, lower: torch.Tensor, upper: torch.Tensor) -> torch.Tensor:
        scaled_x = (x - lower) / (upper - lower)
        scaled_x = scaled_x.clamp(min=0, max=1)
        q_x = _ElementWiseGradientScalingQuantizationFunction.apply(scaled_x, self.k, self.delta)

        if self.is_activation:
            return q_x
        return 2 * (q_x - 0.5)


class IntervalEWGSBinaryWeightScaling(nn.Module):
    """Interval-based binary weight scaling with element-wise gradient scaling (EWGS).

    Difference from the `EWGS`_ paper : In the paper's formulation, the output is unscaled binary values of `{-1, +1}`.
    This quantizer multiplies step size `s` to this output to make the final output `{-s, s}`.

    .. _EWGS:
        https://arxiv.org/abs/2104.00903v1

    Args:
        k (int, optional): bit-width of the precision of activation function. Defaults to ``1``.
        step_size (float, optional): Step size. Defaults to ``0.05``
        lower (float, optional): Lower bound of quantization range. Defaults to ``-sqrt(2*3/(9*128))``, which is lower
            bound for He uniform initialization for `Conv2d(128, 128, 3)`.
        upper (float, optional): Upper bound of quantization range. Defaults to ``sqrt(2*3/(9*128))``.
        delta (float, optional): EWGS scaling factor of the gradient. Defaults to ``0.001``
        grad_factor (float, optional): Gradients for `step_size`, `lower`, and `upper` are scaled by this number.
            For example, when it is 0.01, these gradients are reduced by 100 times. Defaults to ``0.01``
    """

    def __init__(
        self,
        k: int = 1,
        step_size: float = 0.05,
        lower: float = -0.07216878365,
        upper: float = 0.07216878365,
        delta: float = 0.001,
        grad_factor: float = 0.01,
    ) -> None:
        super().__init__()
        if lower >= upper:
            _logger.error("For IntervalEWGSBinaryWeightScaling, initial lower should be less than upper.")
            raise ValueError("For IntervalEWGSBinaryWeightScaling, initial lower should be less than upper.")
        self.k = k
        self.ewgs = _ElementWiseGradientScalingQuantization(delta=delta, k=self.k, is_activation=False)
        self.step_size = nn.Parameter(torch.tensor(step_size))
        self.lower = nn.Parameter(torch.tensor(lower))
        self.upper = nn.Parameter(torch.tensor(upper))

        self.step_size.register_hook(lambda grad: grad * grad_factor)
        self.lower.register_hook(lambda grad: grad * grad_factor)
        self.upper.register_hook(lambda grad: grad * grad_factor)

    def forward(self, w: torch.Tensor) -> torch.Tensor:
        if self.training:
            w = self.ewgs(w, self.lower, self.upper)  # Binary tensor with (-1, 1) without scaling.
            return w * self.step_size

        # This is a hack so the quantizer is convertible for inference time.
        # At inference, for binary quantizer, only the signs after scaling matter.
        scaled_w = (w - self.lower) / (self.upper - self.lower) - 0.5
        # After getting signs, the operation can be reduced to LSQ forward pass.
        return _LearnedStepSizeBinaryWeightScalingFunction.apply(scaled_w, self.step_size)


class _HalfWaveGaussianQuantizationFunction(torch.autograd.Function):
    """Half wave gaussian quantizer (Linear mid tread half quantizer). (torch.autograd.Function)
    This quantization creates a linear mid tread half quantizer.

    This quantization method is DoReFa-Net [1]_ activation quantization variant,
    the difference from DoReFa-Net [1]_ is to be able to change `max_value`.

    `op_type` is ``LinearMidTreadHalfV2``.

    Reference:
        - `Deep Learning with Low Precision by Half-wave Gaussian Quantization <https://arxiv.org/abs/1702.00953>`_
        .. [1] `DoReFa-Net: Training Low Bitwidth Convolutional Neural Networks with Low Bitwidth Gradients
        <https://arxiv.org/abs/1606.06160>`_
    """

    @staticmethod
    def symbolic(g: Any, x: Any, bit: Any, max_value: Any, disable_post_scale: Any) -> Any:
        min_val = g.constant(0.0, [0], "int")
        max_val = g.constant(2**bit - 1, [0], "int")
        scale1 = g.constant((2**bit - 1) / max_value, [1], "float")
        scale2 = g.constant(max_value / (2**bit - 1), [1], "float")
        beta1 = g.constant(0.0, [1], "float")
        beta2 = g.constant(0.0, [1], "float")

        if disable_post_scale:
            scale2 = g.constant(1.0, [1], "float")

        return g.op("lm::LinearMidTreadHalfV2", x, min_val, max_val, scale1, scale2, beta1, beta2)

    @staticmethod
    def forward(ctx: Any, x: torch.Tensor, bit: int, max_value: float, disable_post_scale: bool) -> torch.Tensor:
        r"""Forward.

        .. math::
            \mathbf{X} & = \text{clip}\big(\mathbf{X}, 0, max\_value\big)\\
            \mathbf{Y} & =
                \begin{cases}
                \mathbf{X},  & \text{if $bit$ is 32} \\
                \frac{\text{round}\big(\frac{\mathbf{X}}{max\_value}
                    \cdot (2^{bit}-1)\big)}{2^{bit}-1} \cdot max\_value, & otherwise
                \end{cases}
        Args:
            x (torch.Tensor): Input tensor in NCHW format to be quantized in this activation.
            bit (int): bit-width of the precision of activation function. Defaults to ``2``
            max_value (float): Upper bound of value to clip. Defaults to ``2.0``
            disable_post_scale (bool): Whether to disable post scaling.
        Returns:
            torch.Tensor: The output tensor from quantized activation function.
        """
        n = 2**bit - 1
        min_value = 0.0
        value_range = max_value - min_value

        ctx.save_for_backward(x)
        ctx.other = max_value, n, value_range, disable_post_scale
        x_clamp = torch.clamp(x, min_value, max_value)
        shifted = x_clamp - min_value
        quantized = _round_half_up(shifted * (n / value_range))

        if disable_post_scale:
            return quantized

        unshifted = quantized * (value_range / n) + min_value
        return unshifted

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None, None, None]:
        r"""Backward.

        .. math::
            \frac{\partial Loss}{\partial \mathbf{X}} =
                \begin{cases}
                \frac{\partial Loss}{\partial y},  & \text{if $0 < x < max\_value$}\\
                0, & otherwise
                \end{cases}

        Args:
            ctx (Any): The autograd backward operation.
            grad_output (torch.Tensor): The gradient w.r.t quantized input.
        Returns:
            torch.Tensor: The gradient w.r.t. normal (non-quantized) input.
        """
        (x,) = ctx.saved_tensors
        max_value, n, value_range, disable_post_scale = ctx.other
        grad_input = grad_output.clone()

        zero_tensor = torch.tensor(0.0, device=x.device, dtype=grad_output.dtype)
        grad_input = torch.where(x < 0.0, zero_tensor, grad_input)
        grad_input = torch.where(x > max_value, zero_tensor, grad_input)

        if disable_post_scale:
            grad_input = grad_input * (n / value_range)

        return grad_input, None, None, None


class _HalfWaveGaussianQuantizationFunctionWithEWGS(torch.autograd.Function):
    """HalfWave Gaussian Quantization Function with EWGS. (torch.autograd.Function)
    The difference from _HalfWaveGaussianQuantizationFunction is only an EWGS [1]_ gradient approximation in backward function.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(g: Any, x: Any, bit: Any, max_value: Any, disable_post_scale: Any, delta: Any) -> Any:
        return _HalfWaveGaussianQuantizationFunction.symbolic(g, x, bit, max_value, disable_post_scale)

    @staticmethod
    def forward(
        ctx: Any, x: torch.Tensor, bit: int, max_value: float, disable_post_scale: bool, delta: float
    ) -> torch.Tensor:
        q = _HalfWaveGaussianQuantizationFunction.forward(ctx, x, bit, max_value, disable_post_scale)
        ctx.ewgs = x - q, delta
        return q

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None, None, None, None]:
        q_err, delta = ctx.ewgs
        grad_input, *_ = _HalfWaveGaussianQuantizationFunction.backward(ctx, grad_output)
        scaled = grad_input * (1 + delta * torch.sign(grad_input) * q_err)
        return scaled, None, None, None, None


class HalfWaveGaussianQuantization(nn.Module):
    """Half wave gaussian quantizer (Linear mid tread half quantizer).
    This quantization creates a linear mid tread half quantizer.
    Set ``disable_post_scale`` to ``True`` if you want to use it before the Residual connection add operator.

    Args:
        bit (int, optional): bit-width of the precision of activation function. Defaults to ``2``
        max_value (float, optional): Upper bound of value to clip. Defaults to ``2.0``
        disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``
        step_size (float, optional): Step size. Defaults to ``0.05``
        min_value (float, optional): Lower bound of step size. Defaults to ``0.00001``
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation

    Returns:
        torch.Tensor: The output tensor from quantized activation function.
    """

    def __init__(
        self,
        bit: int = 2,
        max_value: float = 2.0,
        disable_post_scale: bool = False,
        delta: float = 0,
    ) -> None:
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        self.bit = bit
        self.max_value = max_value
        self.disable_post_scale = disable_post_scale
        self.delta = delta

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.delta == 0:  # Switch to STE
            return _HalfWaveGaussianQuantizationFunction.apply(x, self.bit, self.max_value, self.disable_post_scale)
        return _HalfWaveGaussianQuantizationFunctionWithEWGS.apply(
            x, self.bit, self.max_value, self.disable_post_scale, self.delta
        )


class _LearnedStepSizeQuantizationFunctionWithBeta(torch.autograd.Function):
    """Learned step size quantizer (LSQ) (Linear mid tread half quantizer V2). (torch.autograd.Function)
    This quantization creates a learned step size quantizer.

    LSQ obtain maximum value for quantization function by learning.
    LSQ learns the step size of the weight and activation quantizers (each layer has a different step size).
    By doing this, it can reduce the accuracy gap between quantized and float precision models.

    This quantization method is Learned step size quantizaztion (LSQ) [1]_ activation quantization variant,
    the difference from LSQ is obtain an initial value of `max value` for quantize function from HWGQ.

    `op_type` is ``LinearMidTreadHalfV2``.

    Reference:
        .. [1] `LEARNED STEP SIZE QUANTIZATION <https://arxiv.org/abs/1902.08153>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(
        g: Any,
        x: Any,
        min_val: Any,
        max_val: Any,
        scale1: Any,
        scale2: Any,
        beta1: Any,
        beta2: Any,
        count_features: Any,
    ) -> Any:
        min_val = g.constant(min_val, [0], "int")
        max_val = g.constant(max_val, [0], "int")
        return g.op("lm::LinearMidTreadHalfV2", x, min_val, max_val, scale1, scale2, beta1, beta2)

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        beta1: float | list[float],
        beta2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
    ) -> torch.Tensor:
        r"""Forward.
        .. math::
            \mathbf{h} & = (\mathbf{x} + \mathbf{\beta_1}) * \mathbf{\scale_1} \\
            \mathbf{h} & = \text{round}\big(\text{clip}\big(\mathbf{h}, min\_value, max\_value\big)\big) \\
            \mathbf{h} & = \mathbf{h} \times (\mathbf{\scale_2} + \mathbf{\beta_2})

        Args:
            x: input tensor
            min_val (int): minimum clipping value
            max_val (int): maximum clipping value
            scale1 (float | list[float]): pre quantized scale factor. For vector of list[float], size = channel size
            scale2 (float | list[float]): post quantized scale factor. For vector of list[float], size = channel size
            beta1 (float | list[float]): pre quantized shift factor. For vector of list[float], size = channel size
            beta2 (float | list[float]): post quantized shift factor. For vector of list[float], size = channel size
            count_features (Callable[[torch.Tensor], int]): function return number of features in a layer.
        Returns:
            torch.Tensor: The output tensor from quantized activation function.
        """  # NOQA: E501
        ctx.save_for_backward(x, scale1, scale2, beta1, beta2)
        ctx.other = min_val, max_val, count_features

        h = torch.clamp((x + beta1) * scale1, min_val, max_val)
        h = _round_half_up(h)
        h = h * scale2 + beta2
        return h

    @staticmethod
    def backward(
        ctx: Any, grad_output: torch.Tensor
    ) -> tuple[torch.Tensor, None, None, None, torch.Tensor, None, None, None]:
        x, scale1, scale2, beta1, beta2 = ctx.saved_tensors
        min_val, max_val, count_features = ctx.other

        grad_input = grad_output.clone()
        grad_input = torch.where(
            (x >= min_val) & (x <= (max_val * scale2)),
            grad_input,
            torch.tensor(0.0, dtype=grad_input.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )

        x_beta_scale = (x + beta1) * scale1
        # Calculate mid area
        grad_scale2 = -x_beta_scale + _round_half_up(x_beta_scale)
        # Replace value on negative and positive area
        grad_scale2 = torch.where(
            x_beta_scale >= min_val,
            grad_scale2,
            torch.tensor(min_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )
        grad_scale2 = torch.where(
            x_beta_scale <= max_val,
            grad_scale2,
            torch.tensor(max_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )

        grad_scale_factor = grad_output.new_tensor(1.0 / math.sqrt(max_val * count_features(x)))
        grad_scale2 = (grad_scale2 * grad_output).sum().unsqueeze(dim=0) * grad_scale_factor

        # Using grad_scale2 instead because this is more efficient and also more numerically stable. (#5605)
        return grad_input, None, None, None, grad_scale2, None, None, None


class _LearnedStepSizeQuantizationFunction(torch.autograd.Function):
    """Fast Learned step size quantizer (FastLSQ) function (Linear mid tread half quantizer V2). (torch.autograd.Function)
    This quantization creates an accelerated learned step size quantizer which drop beta, which always equals to 0, from the calculation.

    LSQ obtain maximum value for quantization function by learning.
    LSQ learns the step size of the weight and activation quantizers (each layer has a different step size).
    By doing this, it can reduce the accuracy gap between quantized and float precision models.

    This quantization method is Learned step size quantizaztion (LSQ) [1]_ activation quantization variant,
    the difference from LSQ is obtain an initial value of `max value` for quantize function from HWGQ.

    `op_type` is ``LinearMidTreadHalfV2``.

    Reference:
        .. [1] `LEARNED STEP SIZE QUANTIZATION <https://arxiv.org/abs/1902.08153>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(g: Any, x: Any, min_val: Any, max_val: Any, scale1: Any, scale2: Any, count_features: Any) -> Any:
        min_val = g.constant(min_val, [0], "int")
        max_val = g.constant(max_val, [0], "int")
        beta1 = g.constant(0.0, [1], "float")
        beta2 = g.constant(0.0, [1], "float")
        return g.op("lm::LinearMidTreadHalfV2", x, min_val, max_val, scale1, scale2, beta1, beta2)

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
    ) -> torch.Tensor:
        r"""Forward.
        .. math::
            \mathbf{h} & = (\mathbf{x} + \mathbf{\beta_1}) * \mathbf{\scale_1} \\
            \mathbf{h} & = \text{round}\big(\text{clip}\big(\mathbf{h}, min\_value, max\_value\big)\big) \\
            \mathbf{y} & = \mathbf{h} \times (\mathbf{\scale_2} + \mathbf{\beta_2})

        Args:
            x: input tensor
            y :output tensor
            min_val (int): minimum clipping value
            max_val (int): maximum clipping value
            scale1 (float | list[float]): pre quantized scale factor. For vector of list[float], size = channel size
            scale2 (float | list[float]): post quantized scale factor. For vector of list[float], size = channel size
            count_features (Callable[[torch.Tensor], int]): function return number of features in a layer.
        Returns:
            torch.Tensor: The output tensor from quantized activation function.
        """  # NOQA: E501
        ctx.save_for_backward(x, scale1, scale2)
        ctx.other = min_val, max_val, count_features

        h = torch.clamp(x * scale1, min_val, max_val)
        h = _round_half_up(h)
        h = h * scale2
        return h

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None, None, None, torch.Tensor, None]:
        x, scale1, scale2 = ctx.saved_tensors
        min_val, max_val, count_features = ctx.other

        grad_input = grad_output.clone()
        grad_input = torch.where(
            (x >= min_val) & (x <= (max_val * scale2)),
            grad_input,
            torch.tensor(0.0, dtype=grad_input.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )

        x_scale = x * scale1
        # Calculate mid area
        grad_scale2 = -x_scale + _round_half_up(x_scale)
        # Replace value on negative and positive area
        grad_scale2 = torch.where(
            x_scale >= min_val,
            grad_scale2,
            torch.tensor(min_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )
        grad_scale2 = torch.where(
            x_scale <= max_val,
            grad_scale2,
            torch.tensor(max_val, dtype=grad_output.dtype, device=x.device),  # Fixed type mismatch for torch.where
        )

        grad_scale_factor = grad_output.new_tensor(1.0 / math.sqrt(max_val * count_features(x)))
        grad_scale2 = (grad_scale2 * grad_output).sum().unsqueeze(dim=0) * grad_scale_factor

        # Using grad_scale2 instead because this is more efficient and also more numerically stable. (#5605)
        return grad_input, None, None, None, grad_scale2, None


class _LearnedStepSizeQuantizationFunctionWithEWGS(torch.autograd.Function):
    """Fast Learned step size quantizer function with EWGS. (torch.autograd.Function)
    The difference from _LearnedStepSizeQuantizationFunction is only an EWGS [1]_ gradient approximation in backward function.

    Reference:
        .. [1] `Network Quantization with Element-wise Gradient Scaling <https://arxiv.org/abs/2104.00903v1>`_
    """  # NOQA: E501

    @staticmethod
    def symbolic(
        g: Any, x: Any, min_val: Any, max_val: Any, scale1: Any, scale2: Any, count_features: Any, delta: Any
    ) -> Any:
        return _LearnedStepSizeQuantizationFunction.symbolic(g, x, min_val, max_val, scale1, scale2, count_features)

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        min_val: int,
        max_val: int,
        scale1: float | list[float],
        scale2: float | list[float],
        count_features: Callable[[torch.Tensor], int],
        delta: float,
    ) -> torch.Tensor:
        q = _LearnedStepSizeQuantizationFunction.forward(ctx, x, min_val, max_val, scale1, scale2, count_features)
        ctx.ewgs = x - q, delta
        return q

    @staticmethod
    def backward(
        ctx: Any, grad_output: torch.Tensor
    ) -> tuple[torch.Tensor, None, None, None, torch.Tensor, None, None]:
        q_err, delta = ctx.ewgs
        grad_input, _, _, _, grad_scale2, *_ = _LearnedStepSizeQuantizationFunction.backward(ctx, grad_output)
        scaled = grad_input * (1 + delta * torch.sign(grad_input) * q_err)
        return scaled, None, None, None, grad_scale2, None, None


class LearnedStepSizeQuantization(nn.Module):
    r"""Learned step size quantizer (LSQ) (Linear mid tread half quantizer V2).
    This quantization creates a learned step size quantizer.

    Args:
        x (torch.Tensor): Input tensor in NCHW format to be quantized in this activation.
        num_ch (int, optional): Currently unused, but reserved parameter for future updates on channel-wise LSQ. Defaults to ``None``
        k (int, optional): bit-width of the precision of activation function. Defaults to ``2``
        symmetric (bool, optional): If ``True``, set min_value = -max_value. Defaults to ``False``
        max_value (int, optional): Upper bound of value to clip. Defaults to ``None`` -- self.max_value = 2^k-1
        features (str, optional): Determines how to compute :math:`N_F` in the scaling factor for the step size gradient.
            Allowed values are "C", "CHW", and "NCHW". Defaults to ``"NCHW"``
        delta (float, optional): : The delta variable in EWGS. Defaults to ``0`` - use STE for backward calculation

    Returns:
        torch.Tensor: The output tensor from quantized activation function.

    Note:
        In the LSQ paper, gradient scale :math:`g = \frac{1.0}{\sqrt{N_F * Q_P}}` where :math:`Q_P` is max_value (3 by default).
        The `features` option determines how to compute :math:`N_F`.

        * `features="C"`: :math:`N_F` is the number of channels in the activation.
        * `features="CHW"`: :math:`N_F` is the size of activations in the layer.
        * `features="NCHW"`: :math:`N_F` is the total elements in the layer in the current batch. N is the batch size.

        The NDK scaling is similar to "CHW".
        Currently, "NCHW" is a default setting because it seems to perform slightly better than "C".
        Depending on the models, "CHW" and "C" may be worth trying if the gradients for scales look too small.
    """  # NOQA: E501, W605

    def __init__(
        self,
        num_ch: int | None = None,
        k: int = 2,
        symmetric: bool = False,
        max_value: int | None = None,
        features: str = "NCHW",
        delta: float = 0,
    ):
        super().__init__()
        if delta < 0:
            _logger.error("delta must be greater than or equal to 0")
            raise ValueError("delta must be greater than or equal to 0")
        self.k = k
        self.max_value = max_value if max_value is not None else int(2**self.k - 1)
        self.min_value = -self.max_value if symmetric else 0
        self.scale = nn.Parameter(torch.Tensor(1).fill_(0.0))

        get_count_features = {
            "C": lambda x: x.size(1),
            "CHW": lambda x: x[0].numel(),
            "NCHW": lambda x: x.numel(),
        }
        assert features in ("C", "CHW", "NCHW")
        self.count_features = get_count_features[features]
        self.delta = delta

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        scale1 = 1.0 / (1.85 / self.max_value + self.scale)
        scale2 = 1.85 / self.max_value + self.scale
        if self.delta == 0:  # Switch to STE
            return _LearnedStepSizeQuantizationFunction.apply(
                x, self.min_value, self.max_value, scale1, scale2, self.count_features
            )
        return _LearnedStepSizeQuantizationFunctionWithEWGS.apply(
            x, self.min_value, self.max_value, scale1, scale2, self.count_features, self.delta
        )


class IntervalEWGSQuantization(nn.Module):
    """Interval-based activation quantization with element-wise gradient scaling (EWGS) and post-scaling.

    Similarly to `IntervalEWGSBinaryWeightScaling`, the original output of `_ElementWiseGradientScalingQuantization`,
    which is unscaled `[0, 1/M, 2/M, ..., M/M]`, will be post-scaled by a layer-wise step size, as in
    `LearnedStepSizeQuantization`.

    In the `EWGS`_ paper, this post-scaling is not performed in each activation layer. Rather, the post-scalings of
    weight quantizer and activation quantizer are reduced to a single scaling operation for each layer. Our formulation
    allows to integrate EWGS quantizers keeping the structure of LM networks.

    .. _EWGS:
        https://arxiv.org/abs/2104.00903v1

    Args:
        k (int, optional): bit-width of the precision of activation function. Defaults to ``2``.
        step_size (float, optional): Step size. Defaults to `1.85/3`, which is 1/3 of default `upper`.
        lower (float, optional): Lower bound of quantization range. Defaults to ``0.0``.
        upper (float, optional): Upper bound of quantization range. Defaults to ``1.85``.
        delta (float, optional): EWGS scaling factor of the gradient. Defaults to ``0.001``.
        grad_factor (float, optional): Gradients for `step_size`, `lower`, and `upper` are scaled by this number.
            For example, when it is 0.01, these gradients are reduced by 100 times. Defaults to ``0.01``.
        learn_lower (bool, optional): If `False`, lower bound of quantization range is fixed to the initial value.
            Defalts to ``True``.
    """

    def __init__(
        self,
        k: int = 2,
        step_size: float = 0.6166666667,
        lower: float = 0.0,
        upper: float = 1.85,
        delta: float = 0.001,
        grad_factor: float = 0.01,
        learn_lower: bool = True,
    ) -> None:
        super().__init__()
        if lower >= upper:
            _logger.error("For IntervalEWGSQuantization, initial lower should be less than upper.")
            raise ValueError("For IntervalEWGSQuantization, initial lower should be less than upper.")
        self.k = k
        self.min_value = 0.0
        self.max_value = int(2**self.k - 1)
        self.ewgs = _ElementWiseGradientScalingQuantization(delta=delta, k=self.k, is_activation=True)
        self.step_size = nn.Parameter(torch.Tensor(1).fill_(step_size))
        self.lower = nn.Parameter(torch.tensor(lower), requires_grad=learn_lower)
        self.upper = nn.Parameter(torch.tensor(upper))

        self.step_size.register_hook(lambda grad: grad * grad_factor)
        if learn_lower:
            self.lower.register_hook(lambda grad: grad * grad_factor)
        self.upper.register_hook(lambda grad: grad * grad_factor)

        # A constant used in eval forward pass.
        self._lsq_post_shift = torch.tensor(0.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training:
            lower = torch.clamp(self.lower, min=0.0)
            x = self.ewgs(x, lower, self.upper)  # [0, 1/m, 2/m, ..., m/m]; m=max_value
            return x * self.max_value * self.step_size

        # This is a hack so the quantizer is convertible for inference time.
        lower = torch.clamp(self.lower.data, min=0.0)
        pre_shift = -lower
        scale1 = 3.0 / (self.upper - lower)
        scale2 = self.step_size
        return _LearnedStepSizeQuantizationFunctionWithBeta.apply(
            x,
            self.min_value,
            self.max_value,
            scale1,
            scale2,
            pre_shift,
            self._lsq_post_shift,
            None,
        )


class _IntegerQuantizerFunction(torch.autograd.Function):
    """Integer Quantizer
    A quantization scheme that allows inference to be carried out using integer-only arithmetic [1]_

    `op_type` is ``IntegerQuantizer`` (TBC).

    Reference:
        .. [1] `Quantization and Training of Neural Networks for Efficient Integer-Arithmetic-Only Inference
        <https://arxiv.org/abs/1712.05877>`_
    """

    @staticmethod
    def symbolic(
        g: Any, x: Any, max_value: Any, symmetric: Any, int_min: Any, int_max: Any, disable_post_scale: Any
    ) -> Any:
        # FIXME(oatawa1): This need to be fix when this quantizer is available in converter.
        # Currently, the operator layout will keep the same as bluetorch.
        return g.op("lm::IntegerQuantizer", x, max_val_f=max_value, int_min_i=int_min, int_max_i=int_max)

    @staticmethod
    def forward(
        ctx: Any,
        x: torch.Tensor,
        max_value: float,
        symmetric: bool,
        int_min: int,
        int_max: int,
        disable_post_scale: bool,
    ) -> torch.Tensor:
        r"""Forward.
        .. math::
            \mathbf{q} = \Biggl \lceil \dfrac{clamp(\mathbf{x}, int\_min, int\_max)}{S}\Biggr \rfloor * S \\
            S = \dfrac{max\_val}{int\_max + 1}

        Args:
            x (torch.Tensor): Input tensor in NCHW format to be quantized in this quantizer or
                            weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
            max_value (float): Upper bound of value to clip. It can only be a positive real value.
            symmetric (bool): If ``True``, set min_value = -max_value. Otherwise, min_value = 0.0
            int_min (int): minimum quantized value
            int_max (int): maximum quantized value
            disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``
        Returns:
            torch.Tensor: The output tensor from quantized activation function.
        """  # NOQA: E501
        scale = (int_max + 1) / max_value
        assert scale > 0
        ctx.save_for_backward(x)
        ctx.other = -max_value if symmetric else 0.0, max_value, disable_post_scale, scale

        x = x * scale
        x = torch.clamp(x, min=int_min, max=int_max)
        x = _round_half_up(x)
        if disable_post_scale:
            return x
        x = x / scale
        return x

    @staticmethod
    def backward(ctx: Any, grad_output: torch.Tensor) -> tuple[torch.Tensor, None, None, None, None, None]:
        (x,) = ctx.saved_tensors
        min_value, max_value, disable_post_scale, scale = ctx.other
        grad_input = grad_output.clone()
        if disable_post_scale:
            grad_input = grad_input * scale

        zero_tensor = torch.tensor(0.0, dtype=grad_output.dtype, device=x.device)
        grad_input = torch.where(x < min_value, zero_tensor, grad_input)
        grad_input = torch.where(x > max_value, zero_tensor, grad_input)

        return grad_input, None, None, None, None, None


class IntegerQuantizer(nn.Module):
    """Integer Quantizer
    A quantization scheme that allows inference to be carried out using integer-only arithmetic [1]_

    Args:
        x (torch.Tensor): Input tensor in NCHW format to be quantized in this quantizer or
                            weight tensor to be quantized with (out_channels, in_channels, kernel_height, kernel_width) shape.
        k (int, optional): bit-width of the precision of activation function. It can only be a positive real value. Defaults to ``8``
        symmetric (bool, optional): If ``True``, set int_min = -int_max. Defaults to ``True``
        max_value (float, optional): Upper bound of value to clip. It can only be a positive real value. Defaults to ``16.0``
        disable_post_scale (bool, optional): Whether to disable post scaling. Defaults to ``False``

    Reference:
        .. [1] `Quantization and Training of Neural Networks for Efficient Integer-Arithmetic-Only Inference
        <https://arxiv.org/abs/1712.05877>`_
    """  # NOQA: E501

    def __init__(
        self, k: int = 8, symmetric: bool = True, max_value: float = 16.0, disable_post_scale: bool = False
    ) -> None:
        super().__init__()

        if k <= 0:
            _logger.error("k must be a positive integer value")
            raise ValueError("k must be a positive integer value")

        if max_value <= 0:
            _logger.error("max_value must be a positive real value")
            raise ValueError("max_value must be a positive real value")

        if symmetric:
            self.int_max = int(2 ** (k - 1) - 1)
            self.int_min = -self.int_max
        else:
            self.int_max = int(2**k - 1)
            self.int_min = 0

        self.k = k
        self.symmetric = symmetric
        self.max_value = max_value
        self.disable_post_scale = disable_post_scale

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _IntegerQuantizerFunction.apply(
            x, self.max_value, self.symmetric, self.int_min, self.int_max, self.disable_post_scale
        )

from typing import Any

import numpy as np
import torch


def assert_allclose(
    actual: Any,
    desired: Any,
    rtol: float = 1e-5,
    atol: float = 1e-8,
    equal_nan: bool = False,
    err_msg: str = "",
    verbose: bool = True,
) -> None:
    if torch.is_tensor(actual):
        actual = actual.detach().numpy()
    if torch.is_tensor(desired):
        desired = desired.detach().numpy()
    np.testing.assert_allclose(
        actual, desired, rtol=rtol, atol=atol, equal_nan=equal_nan, err_msg=err_msg, verbose=verbose
    )

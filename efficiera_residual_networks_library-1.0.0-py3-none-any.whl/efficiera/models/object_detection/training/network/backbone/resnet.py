from typing import Any, Dict, List, Optional, Type, Union

from torch import Tensor
import torch.nn as nn

try:
    from torch.hub import load_state_dict_from_url  # noqa: 401
except ImportError:
    from torch.utils.model_zoo import load_url as load_state_dict_from_url  # noqa: 401

from efficiera.models.object_detection.training.network.block import Bottleneck, PreActBlock, PreActBottleneck
from efficiera.ndk.pth.compressor import Compressor
from efficiera.ndk.pth.layers import QuantizableConv2d
from efficiera.ndk.pth.operators import SpaceToDepth
from efficiera.ndk.pth.quantizers import (
    BinaryChannelWiseMeanScaling,
    BinaryPower2Scaling,
    HalfWaveGaussianQuantization,
    LearnedStepSizeBinaryWeightScaling,
    LearnedStepSizeQuantization,
)

model_urls = {
    "resnet50": "https://download.pytorch.org/models/resnet50-0676ba61.pth",
    "resnext50_32x4d": "https://download.pytorch.org/models/resnext50_32x4d-7cdf4587.pth",
}


class ResNet(nn.Module):
    def __init__(
        self,
        block: Type[Union[Bottleneck, PreActBottleneck, PreActBlock]],
        layers: List[int],
        initial_kernel_size: int = 7,
        use_secondary_layer: bool = False,
        groups: int = 1,
        in_channels: int = 3,
        width_per_group: int = 64,
        quantize: bool = False,
        use_multiple_output: bool = False,
        output_p3: bool = True,
        weight_quantizer: str = "BinaryChannelWiseMeanScaling",
        activation_quantizer: str = "HalfWaveGaussianQuantization",
        downsample_method: str = "maxpool",
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
        compressor: Optional[Type[Compressor]] = None,
        ewgs_delta: float = 0.0,
        overrided_output_channels: int = -1,
    ) -> None:
        super().__init__()
        self.use_secondary_layer = use_secondary_layer
        norm_layer = nn.BatchNorm2d
        self._norm_layer = norm_layer
        self.bn_kwargs = bn_kwargs
        self.inplanes = 64
        self.dilation = 1
        self.groups = groups
        self.base_width = width_per_group
        self.quantize = quantize
        self.use_multiple_output = use_multiple_output
        self.output_p3 = output_p3
        self.preact = (block == PreActBottleneck) or (block == PreActBlock)
        self.last_channels = 512 * block.expansion if overrided_output_channels == -1 else overrided_output_channels * block.expansion
        self.compressor = compressor
        self.ewgs_delta = ewgs_delta
        self.overrided_output_channels = overrided_output_channels

        if initial_kernel_size not in [3, 5, 7]:
            raise ValueError("Initial kernel size must be one of 3, 5, and 7.")
        self.initial_kernel_size = initial_kernel_size
        self.initial_padding = (self.initial_kernel_size - 1) // 2

        if weight_quantizer not in [
            "BinaryPower2Scaling",
            "BinaryChannelWiseMeanScaling",
            "LearnedStepSizeBinaryWeightScaling",
        ]:
            raise ValueError(
                f"Weight quantizer {weight_quantizer} not available."
                "Weight quantizer must be BinaryPower2Scaling, BinaryChannelWiseMeanScaling,"
                " or LearnedStepSizeBinaryWeightScaling."
            )

        if weight_quantizer == "BinaryPower2Scaling":
            self.weight_quantizer = BinaryPower2Scaling
        elif weight_quantizer == "BinaryChannelWiseMeanScaling":
            self.weight_quantizer = BinaryChannelWiseMeanScaling
        else:
            self.weight_quantizer = LearnedStepSizeBinaryWeightScaling

        if activation_quantizer not in [
            "HalfWaveGaussianQuantization",
            "LearnedStepSizeQuantization",
        ]:
            raise ValueError(
                f"Activation quantizer {activation_quantizer} not available."
                "Activation quantizer must be HalfWaveGaussianQuantization or LearnedStepSizeQuantization."
            )
        if activation_quantizer == "HalfWaveGaussianQuantization":
            self.activation_quantizer = HalfWaveGaussianQuantization
        else:
            self.activation_quantizer = LearnedStepSizeQuantization

        self.conv1 = QuantizableConv2d(
            in_channels=in_channels,
            out_channels=self.inplanes,
            kernel_size=self.initial_kernel_size,
            weight_quantizer=self.weight_quantizer(delta=self.ewgs_delta) if quantize else None,
            stride=2,
            padding=self.initial_padding,
            bias=False,
        )
        self.bn1 = norm_layer(self.inplanes, **bn_kwargs)
        self.act1 = self.activation_quantizer(delta=self.ewgs_delta) if quantize else nn.ReLU(inplace=True)

        if self.use_secondary_layer:
            self.conv2 = QuantizableConv2d(
                in_channels=self.inplanes,
                out_channels=self.inplanes,
                kernel_size=3,
                stride=1,
                weight_quantizer=self.weight_quantizer(delta=self.ewgs_delta) if quantize else None,
                padding=1,
                bias=False,
            )
            self.bn2 = norm_layer(self.inplanes, **bn_kwargs)
            self.act2 = self.activation_quantizer(delta=self.ewgs_delta) if quantize else nn.ReLU(inplace=True)

        if downsample_method == "maxpool":
            self.downsample = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        elif downsample_method == "s2d_with_layer":
            self.s2d = SpaceToDepth(2)
            self.conv_after_s2d = QuantizableConv2d(
                in_channels=self.inplanes * 4,
                out_channels=self.inplanes,
                kernel_size=1,
                weight_quantizer=self.weight_quantizer(delta=self.ewgs_delta) if quantize else None,
                padding=0,
                bias=False,
            )
            self.bn_after_s2d = norm_layer(self.inplanes, **bn_kwargs)
            self.act_after_s2d = self.activation_quantizer(delta=self.ewgs_delta) if quantize else nn.ReLU(inplace=True)
            self.downsample = nn.Sequential(self.s2d, self.conv_after_s2d, self.bn_after_s2d, self.act_after_s2d)
        elif downsample_method == "s2d_without_layer":
            if not self.preact:
                raise ValueError("preact must be true to use s2d_without_layer option to fit the channel size.")
            self.downsample = SpaceToDepth(2)
        elif downsample_method == "conv":
            self.conv_downsample = QuantizableConv2d(
                in_channels=self.inplanes,
                out_channels=self.inplanes,
                kernel_size=3,
                stride=2,
                weight_quantizer=self.weight_quantizer(delta=self.ewgs_delta) if quantize else None,
                padding=1,
                bias=False,
            )
            self.bn_downsample = norm_layer(self.inplanes, **bn_kwargs)
            self.act_downsample = (
                self.activation_quantizer(delta=self.ewgs_delta) if quantize else nn.ReLU(inplace=True)
            )
            self.downsample = nn.Sequential(self.conv_downsample, self.bn_downsample, self.act_downsample)
        else:
            raise ValueError(
                f"Downsample method {downsample_method} not available."
                "Downsample method must be eitehr s2d_with_layer, s2d_without_layer or maxpool."
            )

        if self.preact:
            self.conv1_2 = QuantizableConv2d(
                in_channels=self.inplanes * 4 if downsample_method == "s2d_without_layer" else self.inplanes,
                out_channels=self.inplanes,
                kernel_size=1,
                weight_quantizer=self.weight_quantizer(delta=self.ewgs_delta) if quantize else None,
                padding=0,
                bias=False,
            )
            self.last_bn_layer4 = norm_layer(self.last_channels, **bn_kwargs)
            self.last_act_layer4 = (
                self.activation_quantizer(delta=self.ewgs_delta) if quantize else nn.ReLU(inplace=True)
            )
            self.last_bn_layer3 = norm_layer(256 * block.expansion, **bn_kwargs)
            self.last_act_layer3 = (
                self.activation_quantizer(delta=self.ewgs_delta) if quantize else nn.ReLU(inplace=True)
            )
            if self.output_p3:
                self.last_bn_layer2 = norm_layer(128 * block.expansion, **bn_kwargs)
                self.last_act_layer2 = (
                    self.activation_quantizer(delta=self.ewgs_delta) if quantize else nn.ReLU(inplace=True)
                )

        self.layer1 = self._make_layer(block, 64, layers[0])
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512 if overrided_output_channels == -1 else overrided_output_channels, layers[3], stride=2)

    def _make_layer(
        self,
        block: Type[Union[Bottleneck, PreActBottleneck, PreActBlock]],
        out_channels: int,
        blocks: int,
        stride: int = 1,
    ) -> nn.Sequential:
        norm_layer = self._norm_layer
        downsample = None
        if stride != 1 or self.inplanes != out_channels * block.expansion or block == PreActBlock:
            # The weight quantizer of this conv must be BinaryPower2Scaling
            downsample = QuantizableConv2d(
                in_channels=self.inplanes,
                out_channels=out_channels * block.expansion,
                kernel_size=1,
                weight_quantizer=BinaryPower2Scaling(delta=self.ewgs_delta) if self.quantize else None,
                stride=stride,
                bias=False,
            )
            if not self.preact:
                downsample = nn.Sequential(downsample, norm_layer(out_channels * block.expansion, **self.bn_kwargs))

        layers = []
        layers.append(
            block(
                in_channels=self.inplanes,
                out_channels=out_channels,
                stride=stride,
                downsample=downsample,
                groups=self.groups,
                base_width=self.base_width,
                norm_layer=norm_layer,
                quantize=self.quantize,
                weight_quantizer=self.weight_quantizer,
                bn_kwargs=self.bn_kwargs,
                compressor=self.compressor,
            )
        )
        self.inplanes = out_channels * block.expansion
        for _ in range(1, blocks):
            layers.append(
                block(
                    in_channels=self.inplanes,
                    out_channels=out_channels,
                    groups=self.groups,
                    base_width=self.base_width,
                    norm_layer=norm_layer,
                    quantize=self.quantize,
                    weight_quantizer=self.weight_quantizer,
                    bn_kwargs=self.bn_kwargs,
                    compressor=self.compressor,
                )
            )

        return nn.Sequential(*layers)

    def forward(self, x: Tensor) -> Tensor:
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.act1(x)
        if self.use_secondary_layer:
            x = self.conv2(x)
            x = self.bn2(x)
            x = self.act2(x)
        x = self.downsample(x)
        if self.preact:
            # name of this parameter is not suitable after the introduction of conv2, yet the name kept same for loading
            # existing checkpoint files.
            x = self.conv1_2(x)

        x1 = self.layer1(x)
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)

        if self.preact:
            x4 = self.last_bn_layer4(x4)
            x4 = self.last_act_layer4(x4)
            x3 = self.last_bn_layer3(x3)
            x3 = self.last_act_layer3(x3)
            if self.output_p3:
                x2 = self.last_bn_layer2(x2)
                x2 = self.last_act_layer2(x2)
        if self.use_multiple_output:
            if self.output_p3:
                return [x2, x3, x4]
            else:
                return [x3, x4]
        return x4


def _resnet(
    arch: str,
    block: Type[Union[Bottleneck, PreActBottleneck]],
    layers: List[int],
    pretrained: bool,
    progress: bool,
    **kwargs: Any,
) -> ResNet:
    model = ResNet(block, layers, **kwargs)
    if pretrained and not kwargs["quantize"] and not block == PreActBottleneck and not block == PreActBlock:
        state_dict = load_state_dict_from_url(model_urls[arch], progress=progress)
        model.load_state_dict(state_dict, strict=False)
    return model


def resnet50(pretrained: bool = False, progress: bool = True, quantize: bool = False, **kwargs: Any) -> ResNet:
    """ResNet-50 model from
    `"Deep Residual Learning for Image Recognition" <https://arxiv.org/pdf/1512.03385.pdf>`_.
    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
        quantize (bool): If True, the model will be quantized
    """
    kwargs["quantize"] = quantize
    return _resnet("resnet50", Bottleneck, [3, 4, 6, 3], pretrained, progress, **kwargs)


def resnext50_32x4d(pretrained: bool = False, progress: bool = True, quantize: bool = False, **kwargs: Any) -> ResNet:
    """ResNeXt-50 32x4d model from
    `"Aggregated Residual Transformation for Deep Neural Networks" <https://arxiv.org/pdf/1611.05431.pdf>`_.

    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
        quantize (bool): If True, the model will be quantized
    """
    kwargs["groups"] = 32
    kwargs["width_per_group"] = 4
    kwargs["quantize"] = quantize
    return _resnet("resnext50_32x4d", Bottleneck, [3, 4, 6, 3], pretrained, progress, **kwargs)


def preact_resnet50(pretrained: bool = False, progress: bool = True, quantize: bool = False, **kwargs: Any) -> ResNet:
    """PreAct ResNet-50 model from
    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
        quantize (bool): If True, the model will be quantized
    """
    kwargs["quantize"] = quantize
    return _resnet("resnet50", PreActBottleneck, [3, 4, 6, 3], pretrained, progress, **kwargs)


def preact_resnet34(pretrained: bool = False, progress: bool = True, quantize: bool = False, **kwargs: Any) -> ResNet:
    """PreAct ResNet-34 model from
    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
        quantize (bool): If True, the model will be quantized
    """
    kwargs["quantize"] = quantize
    return _resnet("resnet34", PreActBlock, [3, 4, 6, 3], pretrained, progress, **kwargs)


def preact_resnet18(pretrained: bool = False, progress: bool = True, quantize: bool = False, **kwargs: Any) -> ResNet:
    """PreAct ResNet-18 model from
    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
        quantize (bool): If True, the model will be quantized
    """
    kwargs["quantize"] = quantize
    return _resnet("resnet18", PreActBlock, [2, 2, 2, 2], pretrained, progress, **kwargs)


def preact_resnext50_32x4d(
    pretrained: bool = False, progress: bool = True, quantize: bool = False, **kwargs: Any
) -> ResNet:
    """PreAct ResNeXt-50 32x4d model from
    Args:
        pretrained (bool): If True, returns a model pre-trained on ImageNet
        progress (bool): If True, displays a progress bar of the download to stderr
        quantize (bool): If True, the model will be quantized
    """
    kwargs["groups"] = 32
    kwargs["width_per_group"] = 4
    kwargs["quantize"] = quantize
    return _resnet("resnext50_32x4d", PreActBottleneck, [3, 4, 6, 3], pretrained, progress, **kwargs)

from typing import Callable, ClassVar, Dict, Optional, Type, Union

import torch
from torch import Tensor
import torch.nn as nn

from efficiera.ndk.pth.compressor import Compressor
from efficiera.ndk.pth.layers import QuantizableConv2d
from efficiera.ndk.pth.quantizers import (
    BinaryChannelWiseMeanScaling,
    BinaryPower2Scaling,
    HalfWaveGaussianQuantization,
)


class Conv2dBlock(nn.Module):
    """Conv2dBlock (LMNet Block)
    This block is a quantized block of three layers in the following order: 1-Convolutional, 2-Batch Normalization
    and 3-Activation. The quantizers are weight quantizer for weight of convolutional layer and activation quantizer
    for the activation.
    Args:
        in_channels (int): Number of channels in the input image
        out_channels (int): Number of channels produced by the convolution
        kernel_size (int): Size of the convolving kernel
        stride (int): Stride of the convolution. Default: 1
        padding (int): Zero-padding added to both sides of the input. Default: 1
        weight_quantizer (Optional[nn.Module], optional): A quantizer for weight of convolution2d layer.
            Defaults to None
        weight_initializer (callable, optional): Initializer for the convolution layer weight
        activation (callable, optional): Activation function to use
        skip_bn (bool, optional): If `True`, skip BatchNorm in this block. Default: False
        bias (bool, optional): If `True`, add bias to convolution. Default: False
    """  # NOQA: E501

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        stride: int = 1,
        padding: int = 1,
        weight_quantizer: Optional[nn.Module] = None,
        weight_initializer: Optional[Callable] = None,
        activation: Optional[Callable] = None,
        skip_bn: bool = False,
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
        bias: bool = False,
    ) -> None:
        super().__init__()

        self.conv = QuantizableConv2d(
            in_channels, out_channels, kernel_size, weight_quantizer, stride=stride, padding=padding, bias=bias
        )

        if weight_initializer:
            weight_initializer(self.conv.weight)

        self.bn = nn.BatchNorm2d(out_channels, **bn_kwargs) if not skip_bn else None
        self.activation = activation

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward
        Args:
            x (torch.Tensor): The input tensor
        Returns:
            torch.Tensor: The output tensor from LMNet block.
        """
        x = self.conv(x)
        if self.bn:
            x = self.bn(x)
        if self.activation:
            x = self.activation(x)

        return x


class PreActConv2dBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int,
        stride: int = 1,
        padding: int = 1,
        weight_quantizer: Optional[nn.Module] = None,
        weight_initializer: Optional[Callable] = None,
        activation: Callable = nn.ReLU(),
        skip_bn: bool = False,
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
        bias: bool = False,
    ) -> None:
        super().__init__()

        self.conv = QuantizableConv2d(
            in_channels, out_channels, kernel_size, weight_quantizer, stride=stride, padding=padding, bias=bias
        )

        if weight_initializer:
            weight_initializer(self.conv.weight)

        self.bn = nn.BatchNorm2d(in_channels, **bn_kwargs) if not skip_bn else None
        self.activation = activation

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward
        Args:
            x (torch.Tensor): The input tensor
        Returns:
            torch.Tensor: The output tensor from LMNet block.
        """
        x = self.bn(x)
        x = self.activation(x)
        x = self.conv(x)
        return x


class Bottleneck(nn.Module):
    """Residual connection bottleneck block used in ResNet.
    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        stride (int, optional): Value of stride. Defaults to 1.
        downsample (Optional[nn.Module], optional): Downsampling layer before residual connection.
        groups (int): The number of divisions for 3x3 conv.
        base_width (int): Base output channels of 3x3 conv.
        norm_layer (Optional[Callable[..., nn.Module]]): Batch norm layer.
        quantize (bool, optional): Value of whether to quantize or not. Defaults to True.
        compressor (Compressor, optional): The compressor for the feature map.
    """

    expansion: int = 4

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 64,
        norm_layer: Optional[Callable[..., nn.Module]] = None,
        act_layer: Optional[Callable[..., nn.Module]] = None,
        quantize: bool = False,
        weight_quantizer: Type[Union[BinaryChannelWiseMeanScaling, BinaryPower2Scaling]] = BinaryPower2Scaling,
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
        compressor: Optional[Compressor] = None,
        ewgs_delta: float = 0.0,
    ) -> None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        width = int(out_channels * (base_width / 64.0)) * groups
        self.conv1 = QuantizableConv2d(
            in_channels=in_channels,
            out_channels=width,
            kernel_size=1,
            weight_quantizer=weight_quantizer(delta=ewgs_delta) if quantize else None,
            bias=False,
        )
        self.bn1 = norm_layer(width, **bn_kwargs)
        self.conv2 = QuantizableConv2d(
            in_channels=width,
            out_channels=width,
            kernel_size=3,
            weight_quantizer=weight_quantizer(delta=ewgs_delta) if quantize else None,
            stride=stride,
            groups=groups,
            padding=1,
            bias=False,
        )
        self.bn2 = norm_layer(width, **bn_kwargs)
        self.conv3 = QuantizableConv2d(
            in_channels=width,
            out_channels=out_channels * self.expansion,
            kernel_size=1,
            weight_quantizer=BinaryPower2Scaling(delta=ewgs_delta) if quantize else None,
            bias=False,
        )
        self.bn3 = norm_layer(out_channels * self.expansion, **bn_kwargs)
        if act_layer:
            self.act = act_layer(delta=ewgs_delta)
        else:
            self.act = HalfWaveGaussianQuantization(delta=ewgs_delta) if quantize else nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride
        self.compressor = compressor

    def forward(self, x: Tensor) -> Tensor:
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.act(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.act(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)
        elif self.compressor:
            identity = self.compressor(x)

        out += identity
        out = self.act(out)

        return out


class PreActBottleneck(nn.Module):
    """
    Residual connection bottleneck block used in ResNet.
    This block uses a pre-activation structure, so the Batch Norm is executed after Add.
    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        stride (int, optional): Value of stride. Defaults to 1.
        downsample (Optional[nn.Module], optional): Downsampling layer before residual connection.
        groups (int): The number of divisions for 3x3 conv.
        base_width (int): Base output channels of 3x3 conv.
        norm_layer (Optional[Callable[..., nn.Module]]): Batch norm layer.
        quantize (bool, optional): Value of whether to quantize or not. Defaults to True.
        compressor (Compressor, optional): compressor for the feature map.
    """

    expansion: int = 4

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 64,
        norm_layer: Optional[Callable[..., nn.Module]] = None,
        act_layer: Optional[Callable[..., nn.Module]] = None,
        quantize: bool = False,
        weight_quantizer: Type[Union[BinaryChannelWiseMeanScaling, BinaryPower2Scaling]] = BinaryPower2Scaling,
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
        compressor: Optional[Type[Compressor]] = None,
        ewgs_delta: float = 0.0,
    ) -> None:
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        width = int(out_channels * (base_width / 64.0)) * groups

        self.bn1 = norm_layer(in_channels, **bn_kwargs)
        if act_layer:
            self.act1 = act_layer(delta=ewgs_delta)
        else:
            self.act1 = (
                HalfWaveGaussianQuantization(disable_post_scale=downsample is not None, delta=ewgs_delta)
                if quantize
                else nn.ReLU(inplace=True)
            )
        self.conv1 = QuantizableConv2d(
            in_channels=in_channels,
            out_channels=width,
            kernel_size=1,
            weight_quantizer=weight_quantizer(delta=ewgs_delta) if quantize else None,
            bias=False,
        )

        self.bn2 = norm_layer(width, **bn_kwargs)
        if act_layer:
            self.act2 = act_layer(delta=ewgs_delta)
        else:
            self.act2 = HalfWaveGaussianQuantization(delta=ewgs_delta) if quantize else nn.ReLU(inplace=True)
        self.conv2 = QuantizableConv2d(
            in_channels=width,
            out_channels=width,
            kernel_size=3,
            weight_quantizer=weight_quantizer(delta=ewgs_delta) if quantize else None,
            stride=stride,
            groups=groups,
            padding=1,
            bias=False,
        )

        self.bn3 = norm_layer(width, **bn_kwargs)
        if act_layer:
            self.act3 = act_layer(delta=ewgs_delta)
        else:
            self.act3 = (
                HalfWaveGaussianQuantization(disable_post_scale=True, delta=ewgs_delta)
                if quantize
                else nn.ReLU(inplace=True)
            )
        self.conv3 = QuantizableConv2d(
            in_channels=width,
            out_channels=out_channels * self.expansion,
            kernel_size=1,
            weight_quantizer=BinaryPower2Scaling(delta=ewgs_delta) if quantize else None,
            bias=False,
        )

        self.downsample = downsample
        self.stride = stride
        self.compressor = None
        if self.downsample is None and compressor is not None:
            self.compressor = compressor()

    def forward(self, x: Tensor) -> Tensor:
        identity = x

        out = self.bn1(x)
        out = self.act1(out)

        if self.downsample:
            identity = self.downsample(out)
        elif self.compressor:
            identity = self.compressor(x)

        out = self.conv1(out)
        out = self.bn2(out)
        out = self.act2(out)
        out = self.conv2(out)
        out = self.bn3(out)
        out = self.act3(out)
        out = self.conv3(out)

        out += identity

        return out


class Bottle2neck(nn.Module):
    expansion: int = 4

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 26,
        scale=4,
        norm_layer: Optional[Callable[..., nn.Module]] = None,
        act_layer: Optional[Callable[..., nn.Module]] = None,
        quantize: bool = False,
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
    ):
        """Constructor
        Args:
            in_channels (int): Number of channels in the input image.
            out_channels (int): Number of channels produced by the convolution.
            stride (int, optional): Value of stride. Defaults to 1.
            downsample (Optional[nn.Module], optional): Downsampling layer before residual connection.
            base_width (int): Base output channels of 3x3 conv.
            scale (int): Number of scale.
            norm_layer (Optional[Callable[..., nn.Module]]): Batch norm layer.
            act_layer: (Optional[Callable[..., nn.Module]]): Activation layer.
            quantize (bool, optional): Value of whether to quantize or not. Defaults to True.
        """
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        self.width = int(out_channels * (base_width / 64.0)) * groups
        self.scale = scale

        self.downsample = downsample
        self.conv1 = QuantizableConv2d(
            in_channels,
            out_channels=self.width * self.scale,
            kernel_size=1,
            weight_quantizer=BinaryPower2Scaling() if quantize else None,
            bias=False,
        )
        self.bn1 = norm_layer(self.width * self.scale, **bn_kwargs)
        self.is_first = stride > 1 or self.downsample is not None
        if self.is_first:
            self.pool = nn.AvgPool2d(
                kernel_size=3,
                stride=stride,
                padding=1,
            )
        convs = []
        bns = []
        for _ in range(max(1, self.scale - 1)):
            convs.append(
                QuantizableConv2d(
                    in_channels=self.width,
                    out_channels=self.width,
                    kernel_size=3,
                    stride=stride,
                    groups=groups,
                    padding=1,
                    weight_quantizer=BinaryPower2Scaling() if quantize else None,
                    bias=False,
                )
            )
            bns.append(norm_layer(self.width, **bn_kwargs))
        self.convs = nn.ModuleList(convs)
        self.bns = nn.ModuleList(bns)

        self.conv3 = QuantizableConv2d(
            in_channels=self.width * self.scale,
            out_channels=out_channels * self.expansion,
            kernel_size=1,
            weight_quantizer=BinaryPower2Scaling() if quantize else None,
            bias=False,
        )
        self.bn3 = norm_layer(out_channels * self.expansion, **bn_kwargs)
        if act_layer:
            self.act = act_layer()
        else:
            self.act = HalfWaveGaussianQuantization() if quantize else nn.ReLU(inplace=True)

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.act(out)

        spx = torch.split(out, self.width, 1)
        spo = []
        for i, (conv, bn) in enumerate(zip(self.convs, self.bns)):
            if i == 0 or self.is_first:
                sp = spx[i]
            else:
                sp = sp + spx[i]
            sp = conv(sp)
            sp = bn(sp)
            sp = self.act(sp)
            spo.append(sp)

        if self.scale > 1:
            if self.is_first:
                spo.append(self.pool(spx[-1]))
            else:
                spo.append(spx[-1])
        out = torch.cat(spo, 1)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.act(out)

        return out


class PreActBottle2neck(nn.Module):
    expansion: int = 4

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 26,
        scale=4,
        norm_layer: Optional[Callable[..., nn.Module]] = None,
        act_layer: Optional[Callable[..., nn.Module]] = None,
        quantize: bool = False,
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
    ):
        """Constructor
        Args:
            in_channels (int): Number of channels in the input image.
            out_channels (int): Number of channels produced by the convolution.
            stride (int, optional): Value of stride. Defaults to 1.
            downsample (Optional[nn.Module], optional): Downsampling layer before residual connection.
            base_width (int): Base output channels of 3x3 conv.
            scale (int): Number of scale.
            norm_layer (Optional[Callable[..., nn.Module]]): Batch norm layer.
            act_layer: (Optional[Callable[..., nn.Module]]): Activation layer.
            quantize (bool, optional): Value of whether to quantize or not. Defaults to True.
        """
        super().__init__()
        if norm_layer is None:
            norm_layer = nn.BatchNorm2d
        self.width = int(out_channels * (base_width / 64.0)) * groups
        self.scale = scale
        self.downsample = downsample

        self.bn1 = norm_layer(in_channels, **bn_kwargs)
        self.act1 = (
            HalfWaveGaussianQuantization(disable_post_scale=self.downsample is not None)
            if quantize
            else nn.ReLU(inplace=True)
        )
        self.conv1 = QuantizableConv2d(
            in_channels,
            out_channels=self.width * self.scale,
            kernel_size=1,
            weight_quantizer=BinaryPower2Scaling() if quantize else None,
            bias=False,
        )

        self.is_first = stride > 1 or self.downsample is not None
        if self.is_first:
            self.pool = nn.AvgPool2d(
                kernel_size=3,
                stride=stride,
                padding=1,
            )
        convs = []
        bns = []
        for _ in range(max(1, self.scale - 1)):
            convs.append(
                QuantizableConv2d(
                    in_channels=self.width,
                    out_channels=self.width,
                    kernel_size=3,
                    stride=stride,
                    groups=groups,
                    padding=1,
                    weight_quantizer=BinaryPower2Scaling() if quantize else None,
                    bias=False,
                )
            )
            bns.append(norm_layer(self.width, **bn_kwargs))
        self.convs = nn.ModuleList(convs)
        self.bns = nn.ModuleList(bns)
        self.act2 = HalfWaveGaussianQuantization() if quantize else nn.ReLU(inplace=True)

        self.bn3 = norm_layer(self.width * self.scale, **bn_kwargs)
        self.act3 = HalfWaveGaussianQuantization(disable_post_scale=True) if quantize else nn.ReLU(inplace=True)
        self.conv3 = QuantizableConv2d(
            in_channels=self.width * self.scale,
            out_channels=out_channels * self.expansion,
            kernel_size=1,
            weight_quantizer=BinaryPower2Scaling() if quantize else None,
            bias=False,
        )
        if act_layer:
            self.act = act_layer()
        else:
            self.act = HalfWaveGaussianQuantization() if quantize else nn.ReLU(inplace=True)

    def forward(self, x):
        identity = x

        out = self.bn1(x)
        out = self.act1(out)

        if self.downsample:
            identity = self.downsample(out)

        out = self.conv1(out)

        spx = torch.split(out, self.width, 1)
        spo = []
        for i, (conv, bn) in enumerate(zip(self.convs, self.bns)):
            if i == 0 or self.is_first:
                sp = spx[i]
            else:
                sp = sp + spx[i]
            sp = bn(sp)
            sp = self.act2(sp)
            sp = conv(sp)
            spo.append(sp)

        if self.scale > 1:
            if self.is_first:
                spo.append(self.pool(spx[-1]))
            else:
                spo.append(spx[-1])
        out = torch.cat(spo, 1)

        out = self.bn3(out)
        out = self.act3(out)
        out = self.conv3(out)

        out += identity

        return out


class PreActBlock(nn.Module):
    """Residual connection block used in ResNet.
    This block uses a pre-activation structure, so the Batch Norm is executed after Add.
    In order to make the calculation possible in Efficiera,
    the weight quantizer and the activation quantizer cannot be selected.
    Args:
        in_channels (int): Number of channels in the input image.
        out_channels (int): Number of channels produced by the convolution.
        stride (int, optional): Value of stride. Defaults to ``1``.
        quantize (bool, optional): Value of whether to quantize or not. Defaults to ``True``.
        weight_quantizer (Callable, optional): Weight quantizer.
        activation_quantizer(Callable, optional): Activation quantizer.
        downsample (Callable, optional): Downsample layer of the block.
        groups (int, optional): Group paramter of conv layer.
        base_width (int, optional): Base width paramter of conv layer.
        norm_layer (Callable, optional): Layer of batch normalization.
        bn_kwargs (float, optional): Keyword arguments for batch normalization layers.
        compressor (Compressor class, optional): compressor class applied to feature map.
    """

    expansion: ClassVar[int] = 1

    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        quantize: bool = True,
        weight_quantizer: Callable[[], nn.Module] = BinaryPower2Scaling,
        activation_quantizer: Callable[..., nn.Module] = HalfWaveGaussianQuantization,
        downsample: Optional[nn.Module] = None,
        groups: int = 1,
        base_width: int = 1,
        norm_layer: Callable[[], nn.Module] = None,
        bn_kwargs: Dict = {"momentum": 0.1, "track_running_stats": True},
        compressor: Optional[Type[Compressor]] = None,
        ewgs_delta: float = 0.0,
    ):
        super().__init__()
        self.downsample = downsample
        self.bn0 = nn.BatchNorm2d(in_channels, **bn_kwargs)
        self.act0 = (
            HalfWaveGaussianQuantization(disable_post_scale=self.downsample is not None, delta=ewgs_delta)
            if quantize
            else nn.ReLU(inplace=True)
        )
        self.conv1 = QuantizableConv2d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=3,
            weight_quantizer=weight_quantizer(delta=ewgs_delta) if quantize else None,
            stride=stride,
            padding=1,
            bias=False,
        )
        self.bn1 = nn.BatchNorm2d(out_channels, **bn_kwargs)
        self.act1 = (
            HalfWaveGaussianQuantization(disable_post_scale=True, delta=ewgs_delta)
            if quantize
            else nn.ReLU(inplace=True)
        )
        self.conv2 = QuantizableConv2d(
            in_channels=out_channels,
            out_channels=self.expansion * out_channels,
            kernel_size=3,
            weight_quantizer=BinaryPower2Scaling(delta=ewgs_delta) if quantize else None,
            padding=1,
            bias=False,
        )
        self.compressor = None
        if self.downsample is None and compressor is not None:
            self.compressor = compressor()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x

        out = self.bn0(x)
        out = self.act0(out)

        if self.downsample:
            identity = self.downsample(out)
        elif self.compressor:
            identity = self.compressor(x)

        out = self.conv1(out)
        out = self.bn1(out)
        out = self.act1(out)
        out = self.conv2(out)

        out += identity

        return out

from __future__ import annotations

from logging import getLogger
from pathlib import Path

import hydra
from hydra.core.hydra_config import HydraConfig
from omegaconf import DictConfig, OmegaConf
import pytorch_lightning as pl
import torch.nn
from torchvision import transforms

from efficiera.ndk.pth.experiments.base.src.utils.histogram import HistogramPlotter
from efficiera.ndk.pth.experiments.classification.src.datasets.datasets import get_dataset, get_dataset_numclasses
from efficiera.ndk.pth.utils import verify_model_compatibility

logger = getLogger(__name__)


def train(cfg: DictConfig) -> dict[str, torch.Tensor]:
    """Core function for training
    Args:
        cfg (DictConfig): A dicts defining parameter for training
    """
    pl.seed_everything(42, workers=True)

    # Current config.yaml (hydra.run.dir) set `pwd` and `hydra pwd` equivalent.
    logger.info(f"PWD: {Path.cwd()}")
    if HydraConfig.initialized():
        logger.info(f"hydra PWD: {hydra.utils.get_original_cwd()}")

    input_dir = Path(cfg.input_dir).absolute()
    output_dir = Path(cfg.output_dir).absolute()
    logger.info(f"input path: {output_dir}")
    logger.info(f"output path: {output_dir}")

    if "weight_quantizer" not in cfg and cfg.apply_pixel_embedding:
        logger.warning(
            "Cannot convert with Efficiera Converter because `apply_pixel_embedding=True` is"
            " specified but `weight_quantizer` is not specified."
        )

    augmentor = hydra.utils.instantiate(cfg.augmentor, _convert_="all")
    pre_processor = hydra.utils.instantiate(cfg.pre_processor, _convert_="all")
    pre_processor_val = hydra.utils.instantiate(cfg.get("pre_processor_val", []), _convert_="all")

    train_dataset = get_dataset(cfg.dataset, transform=transforms.Compose(augmentor + pre_processor), train=True)
    val_dataset = get_dataset(cfg.dataset, transform=transforms.Compose(pre_processor_val + pre_processor), train=False)

    train_dataloader = hydra.utils.instantiate(cfg.dataloader, dataset=train_dataset, _convert_="all")
    val_dataloader = hydra.utils.instantiate(cfg.dataloader, dataset=val_dataset, shuffle=False, _convert_="all")
    backbone = hydra.utils.instantiate(cfg.network.backbone, _convert_="all")
    model = hydra.utils.instantiate(
        cfg.pl_module,
        network=hydra.utils.instantiate(
            cfg.network,
            backbone=backbone,
            num_classes=get_dataset_numclasses(cfg.dataset),
            _recursive_=False,
        ),
        _recursive_=False,
        _convert_="none",
    )
    if cfg.verify_model_conversion:
        verify_model_compatibility(
            model, input_image_size=cfg.input_image_sizes, quantize=cfg.quantize, ignore_tolerance=True
        )
    if cfg.pretrained_model_path:
        pretrained_model_path = Path(input_dir, cfg.pretrained_model_path).absolute()
        logger.info(f"Loading pretrained model from {pretrained_model_path}")
        state_dict = torch.load(pretrained_model_path)
        model.load_state_dict(state_dict, strict=False)

    last_checkpoint_path = Path(input_dir, cfg.checkpoint_dir, "last.ckpt").absolute()
    resume_from_checkpoint = last_checkpoint_path if last_checkpoint_path.exists() else None

    # Trainer, precision, parallel training
    precision = 16 if cfg.amp else 32
    strategy = None if cfg.gpus <= 1 else "ddp"

    trainer = hydra.utils.instantiate(
        cfg.trainer,
        logger=list(hydra.utils.instantiate(cfg.get("loggers", {}), _convert_="all").values()),
        callbacks=list(hydra.utils.instantiate(cfg.get("callbacks", {}), _convert_="all").values()),
        strategy=strategy,
        precision=precision,
        deterministic=True,
        _convert_="all",
    )

    config_dict = OmegaConf.to_container(cfg, resolve=True)
    summary_list = ["network", "dataset", "optimizer", "scheduler"]
    summary_dict = {}
    for key in summary_list:
        if key not in config_dict.keys():
            continue
        config = config_dict[key]
        val = config["_target_"]
        while val == "functools.partial":
            config = config["_args_"][0]
            val = config["_target_"]
        if val == "hydra.utils.get_class":
            val = config["path"]
        summary_dict[key] = val.split(".")[-1]

    for pl_logger in trainer.loggers:
        pl_logger.log_hyperparams(
            {
                "lr": cfg.training.lr,
                "weight_decay": cfg.training.weight_decay,
                "max_epochs": cfg.training.max_epochs,
                "batch_size": cfg.training.batch_size,
                "config": config_dict,
                "summary": summary_dict,
            }
        )

    trainer.fit(
        model=model,
        train_dataloaders=train_dataloader,
        val_dataloaders=val_dataloader,
        ckpt_path=resume_from_checkpoint,
    )

    if cfg.save_model_path:
        save_model_path = Path(output_dir, cfg.save_model_path).absolute()
        logger.info(f"Saving state dict to {save_model_path}")
        torch.save(model.state_dict(), save_model_path)

    if cfg.plot_histogram:
        plotter = HistogramPlotter()
        plotter.plot_histogram(trainer, model, val_dataloader, output_dir / "hist")

    if trainer.interrupted:
        raise KeyboardInterrupt

    return trainer.callback_metrics

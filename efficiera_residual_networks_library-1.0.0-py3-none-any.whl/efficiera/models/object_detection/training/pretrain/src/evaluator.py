from __future__ import annotations

from logging import getLogger

import hydra
from omegaconf import DictConfig
import pytorch_lightning as pl
import torch.nn
from torchvision import transforms

from efficiera.ndk.pth.experiments.classification.src.datasets.datasets import get_dataset, get_dataset_numclasses

logger = getLogger(__name__)


def evaluate(cfg: DictConfig) -> dict[str, torch.Tensor]:
    """Core function for training
    Args:
        cfg (DictConfig): A dicts defining parameter for training
    """
    pl.seed_everything(42, workers=True)

    pre_processor = hydra.utils.instantiate(cfg.pre_processor, _convert_="all")
    pre_processor_val = hydra.utils.instantiate(cfg.get("pre_processor_val", []), _convert_="all")

    val_dataset = get_dataset(cfg.dataset, transform=transforms.Compose(pre_processor_val + pre_processor), train=False)

    val_dataloader = hydra.utils.instantiate(cfg.dataloader, dataset=val_dataset, shuffle=False, _convert_="all")
    backbone = hydra.utils.instantiate(cfg.network.backbone, _convert_="all")
    model = hydra.utils.instantiate(
        cfg.pl_module,
        network=hydra.utils.instantiate(
            cfg.network,
            backbone=backbone,
            num_classes=get_dataset_numclasses(cfg.dataset),
            _recursive_=False,
        ),
        _recursive_=False,
        _convert_="none",
    )

    # Trainer, precision, parallel training
    precision = 16 if cfg.amp else 32
    strategy = None if cfg.gpus <= 1 else "ddp"

    trainer = hydra.utils.instantiate(
        cfg.trainer,
        strategy=strategy,
        precision=precision,
        deterministic=True,
        _convert_="all",
    )
    result = trainer.validate(model=model, dataloaders=val_dataloader, ckpt_path=cfg.checkpoint_filepath, verbose=False)
    logger.info(f"top1 accuracy: {result[0]['val_acc_top1']}")
    logger.info(f"top5 accuracy: {result[0]['val_acc_top5']}")

    if trainer.interrupted:
        raise KeyboardInterrupt

    return trainer.callback_metrics

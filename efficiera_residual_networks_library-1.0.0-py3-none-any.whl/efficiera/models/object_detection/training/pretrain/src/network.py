import torch
import torch.nn as nn

from efficiera.ndk.pth.layers import QuantizableConv2d
from efficiera.ndk.pth.operators import PixelEmbeddingV3
from efficiera.ndk.pth.quantizers import (
    BinaryChannelWiseMeanScaling,
    BinaryMeanScaling,
    BinaryPower2Scaling,
    HalfWaveGaussianQuantization,
    IntervalEWGSBinaryWeightScaling,
    LearnedStepSizeBinaryWeightScaling,
    LearnedStepSizeQuantization,
)


class PretrainNetwork(nn.Module):
    def __init__(
        self,
        backbone: nn.Module,
        backbone_output_channel: int = 2048,
        num_classes: int = 1000,
        quantize_last_conv: bool = True,
        weight_quantizer: str = "BinaryChannelWiseMeanScaling",
        pev3_expansion: int = 10,
        ewgs_delta: float = 0.0,
    ) -> None:
        super(PretrainNetwork, self).__init__()
        if weight_quantizer == "BinaryChannelWiseMeanScaling":
            self.weight_quantizer = BinaryChannelWiseMeanScaling
        elif weight_quantizer == "BinaryMeanScaling":
            self.weight_quantizer = BinaryMeanScaling
        elif weight_quantizer == "BinaryPower2Scaling":
            self.weight_quantizer = BinaryPower2Scaling
        elif weight_quantizer == "IntervalEWGSBinaryWeightScaling":
            self.weight_quantizer = IntervalEWGSBinaryWeightScaling
        elif weight_quantizer == "LearnedStepSizeBinaryWeightScaling":
            self.weight_quantizer =LearnedStepSizeBinaryWeightScaling
        else:
            raise ValueError("Invalid weight_quantizer.")

        self.pixel_embedding = PixelEmbeddingV3(in_channels=3, expansion=pev3_expansion)
        self.backbone = backbone
        self.avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.flatten = nn.Flatten()
        self.conv = QuantizableConv2d(
            in_channels=backbone_output_channel,
            out_channels=num_classes,
            kernel_size=1,
            weight_quantizer=self.weight_quantizer(delta=ewgs_delta) if quantize_last_conv else None,
            bias=False,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pixel_embedding(x)
        x = self.backbone(x)
        x = self.conv(x)
        x = self.avg_pool(x)
        x = self.flatten(x)
        return x
